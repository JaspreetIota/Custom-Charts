import os
import uuid
import json
import base64
import secrets
from concurrent.futures import ThreadPoolExecutor, as_completed
from io import BytesIO
from typing import Any

import pandas as pd
from fastapi import FastAPI, File, Query, Request, UploadFile
from fastapi.responses import FileResponse
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from app.core.config import (
    API_AUTH_ENABLED,
    API_PASSWORD,
    API_USERNAME,
    ENABLE_LOGOS,
    FILE_ENRICH_WORKERS
)
from app.db.redis_client import redis_client
from app.orchestration.orchestrator import Orchestrator
from app.services.company_cache_service import CompanyCacheService
from app.services.qwen_service import QwenService
from app.services.logo_service import LogoService
from app.services.translation_service import TranslationService

app = FastAPI(title="Company Enrichment API")

orchestrator = Orchestrator()
qwen_fallback = QwenService()
translator = TranslationService()
logo_service = LogoService()
company_cache = CompanyCacheService()
executor = ThreadPoolExecutor(max_workers=4)
file_executor = ThreadPoolExecutor(max_workers=FILE_ENRICH_WORKERS)

SINGLE_RESULT_EXPORT_COLUMNS = [
    "input_company_name",
    "database_cache_hit",
    "database_cached",
    "database_record_id",
    "database_query_name",
    "database_cache_error",
    "original_company_name",
    "translated_company_name",
    "detected_language",
    "translation_used",
    "translation_error",
    "company_name",
    "wikipedia_title",
    "match_status",
    "match_confidence",
    "description",
    "summary",
    "website",
    "official_website",
    "logo_url",
    "logo_source",
    "logo_domain",
    "logo_file_url",
    "logo_local_path",
    "logo_status",
    "logo_error",
    "industry",
    "headquarters",
    "founded_year",
    "company_age",
    "startup_flag",
    "ownership_type",
    "ownership_status",
    "parent_company",
    "ultimate_parent",
    "joint_venture_flag",
    "employees_raw",
    "employees",
    "revenue_raw",
    "revenue",
    "country",
    "ticker",
    "exchange",
    "sec_url",
    "core_business",
    "ceo",
    "entity_type",
    "wikidata_id",
    "wikidata_description",
    "openalex_id",
    "ror_id",
    "crossref_id",
    "cik",
    "legal_name",
    "quote_type",
    "yahoo_ticker",
    "yahoo_exchange",
    "yahoo_legal_name",
    "yahoo_match_status",
    "yahoo_match_confidence",
    "yahoo_sector",
    "yahoo_industry",
    "yahoo_website",
    "yahoo_employees",
    "yahoo_total_revenue",
    "market_cap",
    "currency",
    "share_price",
    "previous_close",
    "day_low",
    "day_high",
    "fifty_two_week_low",
    "fifty_two_week_high",
    "market_volume",
    "pe_ratio",
    "beta",
    "dividend_yield",
    "yahoo_market_cap",
    "yahoo_currency",
    "yahoo_regular_market_price",
    "yahoo_previous_close",
    "yahoo_day_low",
    "yahoo_day_high",
    "yahoo_52_week_low",
    "yahoo_52_week_high",
    "yahoo_regular_market_volume",
    "yahoo_trailing_pe",
    "yahoo_forward_pe",
    "yahoo_dividend_yield",
    "yahoo_beta",
    "yahoo_gross_profit",
    "yahoo_ebitda",
    "yahoo_profit_margin",
    "yahoo_revenue_growth",
    "yahoo_earnings_growth",
    "yahoo_recommendation",
    "yahoo_target_mean_price",
    "source_summary",
    "field_completion_used",
    "field_completion_missing",
    "source",
    "confidence_score",
    "sources",
    "data_sources",
    "website_content",
    "news_articles",
    "news_error",
    "ai_used",
    "ai_fallback_used",
    "ai_confidence",
    "enrichment_status",
    "selection_rule",
    "lead_over_next",
    "candidates",
    "error"
]


def _serialize_excel_value(value):
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False)
    return value


def _is_missing(value):
    return value in [None, "", [], {}] or (
        isinstance(value, str)
        and value.strip().lower() in ["unknown", "nan", "none", "null"]
    )


def _source_summary(result):
    data_sources = result.get("data_sources") or {}
    sources = []
    for source_name, used in data_sources.items():
        if used:
            sources.append(source_name)

    raw_source = result.get("source")
    if isinstance(raw_source, str) and raw_source and raw_source not in sources:
        sources.append(raw_source)
    elif isinstance(raw_source, list):
        for item in raw_source:
            if item and item not in sources:
                sources.append(item)

    return ", ".join(sources)


def _ownership_from_entity_type(entity_type):
    mapping = {
        "Company": "Company",
        "University": "Educational Institution",
        "Hospital": "Healthcare Institution",
        "Research Institute": "Research Institute",
        "Government Agency": "Government Agency",
        "Non-profit": "Non-profit",
        "Organization": "Organization"
    }
    return mapping.get(entity_type)


def _complete_missing_core_fields(result, fallback_name=None):
    result = result or {}

    entity_type = result.get("entity_type")
    ownership_type = result.get("ownership_type")
    if (
        entity_type in [
            "University",
            "Hospital",
            "Research Institute",
            "Government Agency",
            "Non-profit"
        ]
        and ownership_type in [
            "Public Company",
            "Private Company",
            "Company",
            None,
            "",
            "Unknown"
        ]
    ):
        result["ownership_type"] = _ownership_from_entity_type(entity_type)

    if _is_missing(result.get("official_website")) and result.get("website"):
        result["official_website"] = result.get("website")

    if _is_missing(result.get("website")) and result.get("official_website"):
        result["website"] = result.get("official_website")

    if _is_missing(result.get("core_business")):
        result["core_business"] = (
            result.get("industry")
            or result.get("yahoo_industry")
            or result.get("yahoo_sector")
            or result.get("wikidata_description")
            or result.get("description")
        )

    if _is_missing(result.get("core_business")):
        entity_type = result.get("entity_type")
        if entity_type == "University":
            result["core_business"] = "Higher education and research"
        elif entity_type == "Hospital":
            result["core_business"] = "Healthcare services"
        elif entity_type == "Research Institute":
            result["core_business"] = "Scientific research"
        elif entity_type == "Non-profit":
            result["core_business"] = "Non-profit organization"
        elif entity_type == "Government Agency":
            result["core_business"] = "Government agency"
        elif entity_type == "Company":
            result["core_business"] = "Company"

    if _is_missing(result.get("revenue")):
        result["revenue"] = result.get("yahoo_total_revenue") or result.get("revenue_raw")

    if _is_missing(result.get("employees")):
        result["employees"] = result.get("yahoo_employees")

    if _is_missing(result.get("ownership_type")):
        result["ownership_type"] = _ownership_from_entity_type(
            result.get("entity_type")
        )

    key_fields = [
        "core_business",
        "revenue",
        "founded_year",
        "website",
        "ownership_type"
    ]
    missing_before_ai = [
        key for key in key_fields
        if _is_missing(result.get(key))
    ]

    should_try_ai = (
        bool(missing_before_ai)
        and not result.get("ai_fallback_used")
        and result.get("field_completion_used") not in [
            "qwen_minimal_fallback",
            "qwen_unavailable"
        ]
        and result.get("enrichment_status") in [
            None,
            "",
            "auto_accepted",
            "not_found",
            "needs_review"
        ]
        and result.get("enrichment_status") not in [
            "skipped_blank",
            "failed"
        ]
    )

    if should_try_ai:
        fallback = qwen_fallback.infer_minimal_company_details(
            fallback_name
            or result.get("company_name")
            or result.get("input_company_name")
            or ""
        )
        if fallback.get("ai_suggested"):
            fill_map = {
                "company_name": "ai_name",
                "core_business": "ai_core_business",
                "revenue": "ai_revenue",
                "founded_year": "ai_founding_year",
                "website": "ai_website",
                "ownership_type": "ai_ownership_details"
            }
            for target, source in fill_map.items():
                value = fallback.get(source)
                if _is_missing(result.get(target)) and not _is_missing(value):
                    result[target] = value

            result["ai_fallback_used"] = True
            result["ai_confidence"] = fallback.get("ai_confidence")
            result["field_completion_used"] = "qwen_minimal_fallback"
        else:
            result["field_completion_used"] = "qwen_unavailable"

    result["source_summary"] = _source_summary(result)
    result["field_completion_missing"] = [
        key for key in key_fields
        if _is_missing(result.get(key))
    ]
    if not result.get("field_completion_used"):
        result["field_completion_used"] = "api_merge"

    return result


def _attach_logo(result):
    result = result or {}
    if not ENABLE_LOGOS or result.get("logo_status"):
        return result

    if result.get("enrichment_status") in ["skipped_blank", "failed"]:
        return result

    logo_data = logo_service.enrich(
        result,
        orchestrator.wikidata
    )
    result.update(logo_data)
    data_sources = result.get("data_sources") or {}
    data_sources["logo"] = bool(result.get("logo_url"))
    result["data_sources"] = data_sources
    result["source_summary"] = _source_summary(result)
    return result


def _get_cached_result(company_name):
    try:
        record = company_cache.get_by_query(company_name)
    except Exception as e:
        return None, str(e)

    if not record:
        return None, None

    result = record.get("result") or {}
    result = {
        **result,
        "database_cache_hit": True,
        "database_record_id": record.get("id"),
        "database_query_name": record.get("query_name")
    }
    return result, None


def _save_cached_result(query_name, result):
    try:
        company_cache.save_result(query_name, result)
    except Exception:
        return None
    return result


def _single_response_excel_row(result, decision=None):
    result = _complete_missing_core_fields(result)
    result = _attach_logo(result)
    row = {
        key: _serialize_excel_value(result.get(key))
        for key in SINGLE_RESULT_EXPORT_COLUMNS
    }

    if decision:
        row["selection_rule"] = decision.get("selection_rule")
        row["lead_over_next"] = decision.get("lead_over_next")

    return row


def _translation_aware_decision(original_name, search_name, translation):
    decision = orchestrator.choose_candidate_for_excel(search_name)
    if decision.get("decision") == "auto_accept":
        return decision
    if not translation.get("translation_used"):
        return decision

    original_candidates = orchestrator.search_candidates(original_name, limit=3)
    for original_candidate in original_candidates:
        canonical_name = (original_candidate.get("name") or "").strip()
        original_id = original_candidate.get("wikidata_id")
        if (
            not canonical_name
            or not canonical_name.isascii()
            or not original_id
            or not original_candidate.get("is_entity")
        ):
            continue

        canonical_decision = orchestrator.choose_candidate_for_excel(
            canonical_name
        )
        confirmed = canonical_decision.get("candidate") or {}
        if (
            canonical_decision.get("decision") == "auto_accept"
            and confirmed.get("wikidata_id") == original_id
        ):
            canonical_decision["selection_rule"] = (
                "translated_wikidata_canonical_retry"
            )
            canonical_decision["translation_candidate_name"] = canonical_name
            return canonical_decision

    return decision


def _auth_failed_response():
    return JSONResponse(
        status_code=401,
        content={"detail": "Authentication required"},
        headers={"WWW-Authenticate": "Basic"}
    )


@app.middleware("http")
async def require_basic_auth(request: Request, call_next):
    if not API_AUTH_ENABLED:
        return await call_next(request)

    authorization = request.headers.get("Authorization", "")

    if not authorization.startswith("Basic "):
        return _auth_failed_response()

    try:
        decoded = base64.b64decode(
            authorization.split(" ", 1)[1]
        ).decode("utf-8")
        username, password = decoded.split(":", 1)
    except Exception:
        return _auth_failed_response()

    valid_username = secrets.compare_digest(
        username,
        API_USERNAME
    )
    valid_password = secrets.compare_digest(
        password,
        API_PASSWORD
    )

    if not (valid_username and valid_password):
        return _auth_failed_response()

    return await call_next(request)


def _file_job_key(job_id):
    return f"file_job:{job_id}"


def _set_file_progress(
    job_id,
    status,
    total=0,
    processed=0,
    output_path=None,
    error=None
):
    percentage = (
        round((processed / total) * 100, 2)
        if total
        else 0
    )
    redis_client.set(
        _file_job_key(job_id),
        json.dumps({
            "job_id": job_id,
            "status": status,
            "total": total,
            "processed": processed,
            "percentage": percentage,
            "output_path": output_path,
            "error": error
        })
    )


def _enrich_row(
    row_dict,
    company_column,
    translate_mode=False,
    include_news=True
):
    company_name = str(row_dict[company_column]).strip()

    if not company_name or company_name.lower() == "nan":
        return _single_response_excel_row({
            "input_company_name": company_name,
            "company_name": company_name,
            "enrichment_status": "skipped_blank"
        })

    search_name, translation = translator.translate_company_name(
        company_name,
        enabled=translate_mode
    )

    cached_result, cache_error = _get_cached_result(search_name)
    if cached_result:
        cached_result["input_company_name"] = company_name
        cached_result.update(translation)
        cached_result.setdefault("enrichment_status", "database_cached")
        cached_result["database_cache_error"] = None
        return _single_response_excel_row(cached_result)

    decision = _translation_aware_decision(
        company_name,
        search_name,
        translation
    )

    if decision["decision"] != "auto_accept":
        if decision.get("candidates"):
            candidate = decision.get("candidates", [None])[0]
            result = _enrich_candidate_result(
                search_name,
                candidate,
                include_news=include_news
            )
            result["input_company_name"] = company_name
            result.update(translation)
            result.update({
                "enrichment_status": decision["decision"],
                "match_status": decision["decision"],
                "selection_rule": decision.get("selection_rule"),
                "match_confidence": decision["confidence"],
                "lead_over_next": decision.get("lead_over_next"),
                "candidates": decision.get("candidates", []),
                "ai_fallback_used": False,
                "database_cache_error": cache_error
            })
            _save_cached_result(search_name, result)
            return _single_response_excel_row(result, decision)

        fallback = (
            qwen_fallback.infer_minimal_company_details(
                search_name
            )
            if not decision.get("candidates")
            else {"ai_suggested": False}
        )

        result = {
            "company_name": (
                fallback.get("ai_name")
                if fallback.get("ai_suggested")
                else search_name
            ),
            "input_company_name": company_name,
            **translation,
            "enrichment_status": (
                "needs_review_ai_suggested"
                if fallback.get("ai_suggested")
                else decision["decision"]
            ),
            "match_status": (
                "needs_review_ai_suggested"
                if fallback.get("ai_suggested")
                else decision["decision"]
            ),
            "selection_rule": decision.get("selection_rule"),
            "match_confidence": decision["confidence"],
            "lead_over_next": decision.get("lead_over_next"),
            "candidates": decision.get("candidates", []),
            "ai_fallback_used": bool(fallback.get("ai_suggested")),
            "database_cache_error": cache_error
        }

        if fallback.get("ai_suggested"):
            result.update({
                "core_business": fallback.get("ai_core_business"),
                "revenue": fallback.get("ai_revenue"),
                "founded_year": fallback.get("ai_founding_year"),
                "website": fallback.get("ai_website"),
                "ownership_type": fallback.get("ai_ownership_details"),
                "ai_confidence": fallback.get("ai_confidence")
            })

        _save_cached_result(search_name, result)
        return _single_response_excel_row(result, decision)

    candidate = decision["candidate"]
    if (
        not candidate.get("wikipedia_title")
        and not candidate.get("ticker")
    ):
        job_id = None
        result = _known_entity_result(
            search_name,
            candidate
        )
        result = _merge_direct_wikidata(result, candidate)
        result = _merge_public_market_data(result, search_name)
    else:
        job_id = orchestrator.create_job()
        result = orchestrator.run_full_pipeline(
            job_id,
            search_name,
            selected_title=candidate.get("wikipedia_title"),
            selected_confidence=candidate.get("confidence"),
            include_news=include_news
        ) or {}
        result = _merge_candidate_metadata(result, candidate)

    result["input_company_name"] = company_name
    result.update(translation)
    if (
        candidate.get("name")
        and (
            translation.get("translation_used")
            or decision.get("selection_rule") == "canonical_name_retry"
            or not result.get("company_name")
        )
    ):
        result["company_name"] = candidate["name"]

    result.update({
        "enrichment_status": "auto_accepted",
        "selection_rule": decision.get("selection_rule"),
        "lead_over_next": decision.get("lead_over_next"),
        "database_cache_error": cache_error
    })

    _save_cached_result(search_name, result)
    return _single_response_excel_row(result, decision)


def _enrich_dataframe(
    dataframe,
    company_column,
    file_job_id=None,
    translate_mode=False,
    include_news=True
):
    row_dicts = dataframe.to_dict("records")
    enriched_rows = [None] * len(row_dicts)
    total = len(row_dicts)

    if file_job_id:
        _set_file_progress(
            file_job_id,
            "processing",
            total=total,
            processed=0
        )

    future_map = {
        file_executor.submit(
            _enrich_row,
            row_dict,
            company_column,
            translate_mode,
            include_news
        ): index
        for index, row_dict in enumerate(row_dicts)
    }

    processed = 0
    for future in as_completed(future_map):
        index = future_map[future]
        try:
            enriched_rows[index] = future.result()
        except Exception as e:
            company_name = str(row_dicts[index][company_column]).strip()
            enriched_rows[index] = _single_response_excel_row({
                "input_company_name": company_name,
                "company_name": company_name,
                "enrichment_status": "failed",
                "match_status": "failed",
                "error": str(e)
            })
        processed += 1

        if file_job_id:
            _set_file_progress(
                file_job_id,
                "processing",
                total=total,
                processed=processed
            )

    return enriched_rows


def _write_enriched_excel(enriched_rows):
    output_dir = os.path.join(
        os.getcwd(),
        "outputs"
    )
    os.makedirs(output_dir, exist_ok=True)

    output_path = os.path.join(
        output_dir,
        f"enriched_companies_{uuid.uuid4().hex}.xlsx"
    )

    pd.DataFrame(enriched_rows).to_excel(
        output_path,
        index=False
    )

    return output_path


def _process_file_job(
    job_id,
    body,
    company_column,
    translate_mode=False,
    include_news=True
):
    try:
        dataframe = pd.read_excel(BytesIO(body))

        if company_column not in dataframe.columns:
            _set_file_progress(
                job_id,
                "failed",
                error=(
                    f"Column '{company_column}' was not found. "
                    f"Available columns: {list(dataframe.columns)}"
                )
            )
            return

        enriched_rows = _enrich_dataframe(
            dataframe,
            company_column,
            file_job_id=job_id,
            translate_mode=translate_mode,
            include_news=include_news
        )
        output_path = _write_enriched_excel(enriched_rows)
        _set_file_progress(
            job_id,
            "done",
            total=len(dataframe),
            processed=len(dataframe),
            output_path=output_path
        )

    except Exception as e:
        _set_file_progress(
            job_id,
            "failed",
            error=str(e)
        )


def _known_entity_result(company_name, candidate):
    sources = candidate.get("source") or ["Known Entity"]
    source_flags = {
        "known_entity": "Known Entity" in sources,
        "openalex": "OpenAlex" in sources,
        "ror": "ROR" in sources,
        "crossref": "Crossref" in sources,
        "wikipedia": "Wikipedia" in sources,
        "wikidata": "Wikidata" in sources or bool(candidate.get("wikidata_id")),
        "sec": False,
        "yahoo": "Yahoo Finance" in sources
    }

    return {
        "company_name": candidate.get("name"),
        "input_company_name": company_name,
        "entity_type": candidate.get("entity_type"),
        "description": candidate.get("description"),
        "core_business": candidate.get("description"),
        "website": candidate.get("website"),
        "official_website": candidate.get("website"),
        "country": candidate.get("country"),
        "openalex_id": candidate.get("openalex_id"),
        "ror_id": candidate.get("ror_id"),
        "crossref_id": candidate.get("crossref_id"),
        "wikidata_id": candidate.get("wikidata_id"),
        "founded_year": candidate.get("founded_year"),
        "ownership_type": _ownership_from_entity_type(
            candidate.get("entity_type")
        ),
        "match_status": (
            "matched_known_entity"
            if source_flags["known_entity"]
            else "matched_external_entity"
        ),
        "match_confidence": candidate.get("confidence"),
        "sources": sources,
        "data_sources": source_flags
    }


def _merge_direct_wikidata(result, candidate):
    wikidata_id = candidate.get("wikidata_id")
    if not wikidata_id:
        return result

    wikidata = orchestrator.wikidata.enrich_by_id(wikidata_id)
    for key, value in wikidata.items():
        if _is_missing(result.get(key)) and not _is_missing(value):
            result[key] = value

    sources = result.get("sources")
    if not isinstance(sources, dict):
        sources = {}
    sources["wikidata"] = "Wikidata"
    result["sources"] = sources

    data_sources = result.get("data_sources") or {}
    data_sources["wikidata"] = bool(wikidata.get("wikidata_id"))
    result["data_sources"] = data_sources

    return result


def _merge_public_market_data(result, company_name):
    if result.get("entity_type") != "Company":
        return result

    sec = orchestrator.sec.enrich(company_name)
    yahoo = orchestrator.yahoo.enrich(
        sec.get("legal_name")
        or result.get("company_name")
        or company_name
    )

    for source_data in [sec, yahoo]:
        for key, value in source_data.items():
            if _is_missing(result.get(key)) and not _is_missing(value):
                result[key] = value

    yahoo_fill_map = {
        "revenue": "yahoo_total_revenue",
        "employees": "yahoo_employees",
        "market_cap": "yahoo_market_cap",
        "currency": "yahoo_currency",
        "share_price": "yahoo_regular_market_price",
        "previous_close": "yahoo_previous_close",
        "day_low": "yahoo_day_low",
        "day_high": "yahoo_day_high",
        "fifty_two_week_low": "yahoo_52_week_low",
        "fifty_two_week_high": "yahoo_52_week_high",
        "market_volume": "yahoo_regular_market_volume",
        "pe_ratio": "yahoo_trailing_pe",
        "beta": "yahoo_beta",
        "dividend_yield": "yahoo_dividend_yield"
    }
    for target_key, yahoo_key in yahoo_fill_map.items():
        if (
            _is_missing(result.get(target_key))
            and not _is_missing(yahoo.get(yahoo_key))
        ):
            result[target_key] = yahoo.get(yahoo_key)

    data_sources = result.get("data_sources") or {}
    data_sources.update({
        "sec": bool(sec.get("ticker")),
        "yahoo": bool(yahoo.get("ticker") or yahoo.get("yahoo_ticker"))
    })
    result["data_sources"] = data_sources

    if sec.get("ticker"):
        result["ownership_type"] = "Public Company"

    return result


def _merge_candidate_metadata(result, candidate):
    sources = candidate.get("source") or []

    for key in [
        "openalex_id",
        "ror_id",
        "crossref_id",
        "wikidata_id",
        "founded_year",
        "country",
        "website",
        "official_website"
    ]:
        if not result.get(key) and candidate.get(key):
            result[key] = candidate.get(key)

    if not result.get("description") and candidate.get("description"):
        result["description"] = candidate.get("description")

    if not result.get("core_business") and candidate.get("description"):
        result["core_business"] = candidate.get("description")

    if result.get("entity_type") in [None, "", "Unknown"]:
        result["entity_type"] = candidate.get("entity_type")

    if not result.get("ownership_type"):
        result["ownership_type"] = _ownership_from_entity_type(
            result.get("entity_type")
        )

    result_sources = result.get("sources")
    if not isinstance(result_sources, dict):
        result_sources = {}

    for source in sources:
        source_key = source.lower().replace(" ", "_")
        if source_key in ["openalex", "ror", "crossref"]:
            result_sources[source_key] = source

    result["sources"] = result_sources

    data_sources = result.get("data_sources") or {}
    data_sources.update({
        "openalex": bool(candidate.get("openalex_id")),
        "ror": bool(candidate.get("ror_id")),
        "crossref": bool(candidate.get("crossref_id")),
        "wikidata": bool(
            data_sources.get("wikidata")
            or candidate.get("wikidata_id")
            or result.get("wikidata_id")
        )
    })
    result["data_sources"] = data_sources

    result = _merge_direct_wikidata(result, candidate)

    return result


def _enrich_candidate_result(company_name, candidate, include_news=True):
    if not candidate:
        return {}

    if (
        not candidate.get("wikipedia_title")
        and not candidate.get("ticker")
    ):
        result = _known_entity_result(
            company_name,
            candidate
        )
        result = _merge_direct_wikidata(result, candidate)
        result = _merge_public_market_data(result, company_name)
        return result

    job_id = orchestrator.create_job()
    result = orchestrator.run_full_pipeline(
        job_id,
        company_name,
        selected_title=candidate.get("wikipedia_title"),
        selected_confidence=candidate.get("confidence"),
        include_news=include_news
    ) or {}
    return _merge_candidate_metadata(result, candidate)


def _ai_fallback_result(company_name, decision, include_news=True):
    if decision.get("candidates"):
        candidate = decision.get("candidates", [None])[0]
        result = _enrich_candidate_result(
            company_name,
            candidate,
            include_news=include_news
        )
        result.update({
            "input_company_name": company_name,
            "enrichment_status": decision.get("decision", "needs_review"),
            "match_status": decision.get("decision", "needs_review"),
            "match_confidence": decision.get("confidence", 0),
            "selection_rule": decision.get("selection_rule"),
            "lead_over_next": decision.get("lead_over_next"),
            "ai_fallback_used": False,
            "candidates": decision.get("candidates", [])
        })
        result = _complete_missing_core_fields(result, company_name)
        return _attach_logo(result)

    if decision.get("candidates"):
        return {
            "company_name": company_name,
            "input_company_name": company_name,
            "enrichment_status": decision.get("decision", "needs_review"),
            "match_status": decision.get("decision", "needs_review"),
            "match_confidence": decision.get("confidence", 0),
            "selection_rule": decision.get("selection_rule"),
            "lead_over_next": decision.get("lead_over_next"),
            "ai_fallback_used": False,
            "candidates": decision.get("candidates", [])
        }

    fallback = qwen_fallback.infer_minimal_company_details(
        company_name
    )

    if fallback.get("ai_suggested"):
        return {
            "company_name": fallback.get("ai_name") or company_name,
            "input_company_name": company_name,
            "core_business": fallback.get("ai_core_business"),
            "revenue": fallback.get("ai_revenue"),
            "founded_year": fallback.get("ai_founding_year"),
            "website": fallback.get("ai_website"),
            "ownership_type": fallback.get("ai_ownership_details"),
            "enrichment_status": "needs_review_ai_suggested",
            "match_status": "needs_review_ai_suggested",
            "match_confidence": decision.get("confidence", 0),
            "ai_fallback_used": True,
            "ai_confidence": fallback.get("ai_confidence"),
            "candidates": decision.get("candidates", [])
        }

    return {
        "company_name": company_name,
        "input_company_name": company_name,
        "enrichment_status": decision.get("decision", "not_found"),
        "match_status": decision.get("decision", "not_found"),
        "match_confidence": decision.get("confidence", 0),
        "ai_fallback_used": False,
        "candidates": decision.get("candidates", [])
    }


def _run_safe_enrich_job(
    job_id,
    company_name,
    taxonomy_list=None,
    translate_mode=False
):
    try:
        search_name, translation = translator.translate_company_name(
            company_name,
            enabled=translate_mode
        )

        cached_result, cache_error = _get_cached_result(search_name)
        if cached_result:
            cached_result["input_company_name"] = company_name
            cached_result.update(translation)
            cached_result.setdefault("enrichment_status", "database_cached")
            cached_result["database_cache_error"] = None
            cached_result = _complete_missing_core_fields(
                cached_result,
                search_name
            )
            cached_result = _attach_logo(cached_result)
            redis_client.set(f"job:{job_id}:status", "done")
            redis_client.set(
                f"job:{job_id}:result",
                json.dumps(cached_result)
            )
            return cached_result

        decision = _translation_aware_decision(
            company_name,
            search_name,
            translation
        )

        if decision["decision"] != "auto_accept":
            result = _ai_fallback_result(
                search_name,
                decision
            )
            result["input_company_name"] = company_name
            result.update(translation)
            result["database_cache_error"] = cache_error
            result = _complete_missing_core_fields(result, search_name)
            result = _attach_logo(result)
            _save_cached_result(search_name, result)
            redis_client.set(
                f"job:{job_id}:status",
                result.get("enrichment_status", "needs_review")
            )
            redis_client.set(
                f"job:{job_id}:result",
                json.dumps(result)
            )
            return result

        candidate = decision["candidate"]

        if (
            not candidate.get("wikipedia_title")
            and not candidate.get("ticker")
        ):
            result = _known_entity_result(
                search_name,
                candidate
            )
            result = _merge_direct_wikidata(result, candidate)
            result = _merge_public_market_data(result, search_name)
            result["input_company_name"] = company_name
            result.update(translation)
            result["enrichment_status"] = "auto_accepted"
            result["selection_rule"] = decision.get("selection_rule")
            result["lead_over_next"] = decision.get("lead_over_next")
            result["database_cache_error"] = cache_error
            result = _complete_missing_core_fields(result, search_name)
            result = _attach_logo(result)
            _save_cached_result(search_name, result)
            redis_client.set(f"job:{job_id}:status", "done")
            redis_client.set(
                f"job:{job_id}:result",
                json.dumps(result)
            )
            return result

        pipeline_job_id = orchestrator.create_job()
        result = orchestrator.run_full_pipeline(
            pipeline_job_id,
            search_name,
            taxonomy_list or [],
            candidate.get("wikipedia_title"),
            candidate.get("confidence")
        )
        result = _merge_candidate_metadata(result or {}, candidate)
        result["input_company_name"] = company_name
        result.update(translation)
        if (
            candidate.get("name")
            and (
                translation.get("translation_used")
                or decision.get("selection_rule") == "canonical_name_retry"
                or not result.get("company_name")
            )
        ):
            result["company_name"] = candidate["name"]
        result.update({
            "enrichment_status": "auto_accepted",
            "selection_rule": decision.get("selection_rule"),
            "lead_over_next": decision.get("lead_over_next"),
            "database_cache_error": cache_error
        })
        result = _complete_missing_core_fields(result, search_name)
        result = _attach_logo(result)
        _save_cached_result(search_name, result)
        redis_client.set(f"job:{job_id}:status", "done")
        redis_client.set(
            f"job:{job_id}:result",
            json.dumps(result)
        )
        return result

    except Exception as e:
        result = {
            "company_name": company_name,
            "status": "failed",
            "error": str(e)
        }
        redis_client.set(f"job:{job_id}:status", "failed")
        redis_client.set(f"job:{job_id}:result", json.dumps(result))
        return result

# =========================
# HEALTH CHECK
# =========================

@app.get("/ui", include_in_schema=False)
def user_interface():
    return FileResponse(
        os.path.join(
            os.path.dirname(__file__),
            "static",
            "company_enrichment_ui.html"
        )
    )


@app.get("/")
def home():
    return {"status": "running"}

# =========================
# START ENRICHMENT
# =========================

@app.post("/enrich")
def enrich(
    company_name: str,
    taxonomy_list: list[str] = Query(default=[]),
    translate_mode: bool = False
):
    job_id = orchestrator.create_job()
    executor.submit(
        _run_safe_enrich_job,
        job_id,
        company_name,
        taxonomy_list,
        translate_mode
    )
    return {"job_id": job_id, "status": "queued"}


class BulkEnrichmentRequest(BaseModel):
    company_names: list[str] = Field(min_length=1)
    taxonomy_list: list[str] = []
    translate_mode: bool = False


class SelectedCandidateRequest(BaseModel):
    company_name: str
    wikipedia_title: str
    confidence: int = 100
    taxonomy_list: list[str] = []


class SavedCompanyRequest(BaseModel):
    query_name: str
    company_name: str | None = None
    result: dict[str, Any]
    reviewed: bool = False
    notes: str | None = None


class SavedCompanyUpdateRequest(BaseModel):
    query_name: str | None = None
    company_name: str | None = None
    result: dict[str, Any] | None = None
    reviewed: bool | None = None
    notes: str | None = None


@app.get("/search-candidates")
def search_candidates(
    query: str,
    limit: int = Query(default=8, ge=1, le=20),
    translate_mode: bool = False
):
    search_query, translation = translator.translate_company_name(
        query,
        enabled=translate_mode
    )
    candidates = orchestrator.search_candidates(
        search_query,
        limit=limit
    )
    return {
        "query": query,
        "search_query": search_query,
        **translation,
        "total": len(candidates),
        "candidates": candidates
    }


@app.get("/source-evidence")
def source_evidence(
    query: str,
    limit: int = Query(default=8, ge=1, le=20),
    translate_mode: bool = False
):
    search_query, translation = translator.translate_company_name(
        query,
        enabled=translate_mode
    )
    evidence = orchestrator.collect_source_evidence(
        search_query,
        limit=limit
    )
    evidence.pop("query", None)
    return {
        "query": query,
        "search_query": search_query,
        **translation,
        **evidence
    }


@app.get("/saved-companies")
def saved_companies(
    query: str | None = None,
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0)
):
    records = company_cache.list_records(
        query=query,
        limit=limit,
        offset=offset
    )
    return {
        "total": len(records),
        "limit": limit,
        "offset": offset,
        "records": records
    }


@app.get("/saved-companies/{record_id}")
def saved_company(record_id: int):
    record = company_cache.get_record(record_id)
    if not record:
        return JSONResponse(
            status_code=404,
            content={"detail": "Saved company record not found"}
        )
    return record


@app.post("/saved-companies")
def create_saved_company(request: SavedCompanyRequest):
    result = {
        **request.result
    }
    if request.company_name:
        result["company_name"] = request.company_name

    record = company_cache.create_manual_record(
        request.query_name,
        result,
        reviewed=request.reviewed,
        notes=request.notes
    )
    if not record:
        return JSONResponse(
            status_code=400,
            content={"detail": "Record could not be saved"}
        )
    return record


@app.put("/saved-companies/{record_id}")
def update_saved_company(
    record_id: int,
    request: SavedCompanyUpdateRequest
):
    record = company_cache.update_record(
        record_id,
        query_name=request.query_name,
        company_name=request.company_name,
        result=request.result,
        reviewed=request.reviewed,
        notes=request.notes
    )
    if not record:
        return JSONResponse(
            status_code=404,
            content={"detail": "Saved company record not found"}
        )
    return record


@app.delete("/saved-companies/{record_id}")
def delete_saved_company(record_id: int):
    deleted = company_cache.delete_record(record_id)
    if not deleted:
        return JSONResponse(
            status_code=404,
            content={"detail": "Saved company record not found"}
        )
    return {
        "status": "deleted",
        "id": record_id
    }


@app.post("/enrich-selected")
def enrich_selected(request: SelectedCandidateRequest):
    job_id = orchestrator.create_job()
    executor.submit(
        orchestrator.run_full_pipeline,
        job_id,
        request.company_name,
        request.taxonomy_list,
        request.wikipedia_title,
        request.confidence
    )
    return {
        "job_id": job_id,
        "status": "queued",
        "selected_title": request.wikipedia_title
    }


@app.post("/enrich/bulk")
def enrich_bulk(
    request: BulkEnrichmentRequest
):
    jobs = []

    for company_name in request.company_names:
        job_id = orchestrator.create_job()
        executor.submit(
            _run_safe_enrich_job,
            job_id,
            company_name,
            request.taxonomy_list,
            request.translate_mode
        )
        jobs.append({
            "company_name": company_name,
            "job_id": job_id,
            "status": "queued"
        })

    return {
        "status": "queued",
        "total": len(jobs),
        "jobs": jobs
    }


@app.post("/enrich-file")
async def enrich_file(
    company_column: str = "company_name",
    translate_mode: bool = False,
    include_news: bool = True,
    file: UploadFile = File(...)
):
    body = await file.read()

    if not body:
        return {
            "status": "error",
            "message": "Upload an Excel file."
        }

    dataframe = pd.read_excel(BytesIO(body))

    if company_column not in dataframe.columns:
        return {
            "status": "error",
            "message": f"Column '{company_column}' was not found.",
            "available_columns": list(dataframe.columns)
        }

    enriched_rows = _enrich_dataframe(
        dataframe,
        company_column,
        translate_mode=translate_mode,
        include_news=include_news
    )
    output_path = _write_enriched_excel(enriched_rows)

    return FileResponse(
        output_path,
        media_type=(
            "application/vnd.openxmlformats-officedocument."
            "spreadsheetml.sheet"
        ),
        filename=os.path.basename(output_path)
    )


@app.post("/enrich-file/start")
async def start_enrich_file(
    company_column: str = "company_name",
    translate_mode: bool = False,
    include_news: bool = True,
    file: UploadFile = File(...)
):
    body = await file.read()

    if not body:
        return {
            "status": "error",
            "message": "Upload an Excel file."
        }

    job_id = str(uuid.uuid4())
    _set_file_progress(
        job_id,
        "queued",
        total=0,
        processed=0
    )
    executor.submit(
        _process_file_job,
        job_id,
        body,
        company_column,
        translate_mode,
        include_news
    )

    return {
        "file_job_id": job_id,
        "status": "queued",
        "status_url": f"/file-status/{job_id}",
        "download_url": f"/file-result/{job_id}"
    }


@app.get("/file-status/{job_id}")
def file_status(job_id: str):
    data = redis_client.get(_file_job_key(job_id))

    if not data:
        return {
            "job_id": job_id,
            "status": "not_found",
            "total": 0,
            "processed": 0,
            "percentage": 0
        }

    return json.loads(data)


@app.get("/file-result/{job_id}")
def file_result(job_id: str):
    data = redis_client.get(_file_job_key(job_id))

    if not data:
        return {
            "job_id": job_id,
            "status": "not_found"
        }

    status_data = json.loads(data)

    if status_data.get("status") != "done":
        return status_data

    output_path = status_data.get("output_path")

    if not output_path or not os.path.exists(output_path):
        return {
            **status_data,
            "status": "missing_output"
        }

    return FileResponse(
        output_path,
        media_type=(
            "application/vnd.openxmlformats-officedocument."
            "spreadsheetml.sheet"
        ),
        filename=os.path.basename(output_path)
    )


@app.get("/logo-file/{filename}")
def logo_file(filename: str):
    safe_name = os.path.basename(filename)
    logo_dir = os.path.join(os.getcwd(), "outputs", "logos")
    logo_path = os.path.join(logo_dir, safe_name)

    if not os.path.exists(logo_path):
        return {
            "status": "not_found",
            "filename": safe_name
        }

    return FileResponse(
        logo_path,
        filename=safe_name
    )

# =========================
# STATUS
# =========================

@app.get("/status/{job_id}")
def status(job_id: str):
    try:
        job_status = orchestrator.get_status(job_id)
        return {
            "job_id": job_id,
            "status": job_status or "not_found"
        }
    except Exception as e:
        return {
            "job_id": job_id,
            "status": "error",
            "error": str(e)
        }

# =========================
# RESULT
# =========================

@app.get("/result/{job_id}")
def result(job_id: str):
    try:
        data = orchestrator.get_result(job_id)
        if data is None:
            return {
                "job_id": job_id,
                "status": "not_found",
                "result": None
            }
        completed = _complete_missing_core_fields(data)
        completed = _attach_logo(completed)
        redis_client.set(
            f"job:{job_id}:result",
            json.dumps(completed)
        )
        return completed
    except Exception as e:
        return {
            "job_id": job_id,
            "status": "error",
            "error": str(e)
        }
