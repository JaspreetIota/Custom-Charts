from pipeline import Pipeline

pipeline = Pipeline()

def enrich_company_task(company_name, taxonomy_list):
    return pipeline.run(company_name, taxonomy_list)