from app.orchestration.orchestrator import Orchestrator

class Pipeline:
    def __init__(self):
        self.orchestrator = Orchestrator()

    def run(self, company_name, taxonomy_list):
        job_id = self.orchestrator.submit(
            company_name,
            taxonomy_list or []
        )
        return self.orchestrator.get_result(job_id)
