import json
import uuid

from app.db.redis_client import redis_client, get_cache, set_cache
from app.core.config import (
    CACHE_TTL_SECONDS,
    ENABLE_NEWS,
    ENABLE_WEBSITE,
    ENABLE_YAHOO
)

from app.services.wikipedia_service import WikipediaService
from app.services.wikidata_service import WikidataService
from app.services.sec_service import SECService
from app.services.yahoo_finance_service import YahooFinanceService
from app.services.google_news_service import GoogleNewsService
from app.services.website_service import WebsiteService
from app.services.ownership_service import OwnershipService
from app.services.merger_service import MergerService
from app.services.candidate_resolver_service import CandidateResolverService
from app.ai.scoring import ConfidenceScorer
from app.utils.company_name import normalize_company_name


class Orchestrator:

    def __init__(self):
        self.wiki = WikipediaService()
        self.wikidata = WikidataService()
        self.sec = SECService()
        self.yahoo = YahooFinanceService()
        self.news = GoogleNewsService()
        self.website = WebsiteService()
        self.ownership = OwnershipService()
        self.merger = MergerService()
        self.candidate_resolver = CandidateResolverService()
        self.scorer = ConfidenceScorer()

    # =========================
    # SUBMIT JOB
    # =========================

    def submit(self, company_name: str, taxonomy_list=None):

        job_id = str(uuid.uuid4())

        redis_client.set(f"job:{job_id}:status", "queued")

        # enqueue simulation (we will attach celery later)
        self.run_full_pipeline(
            job_id,
            company_name,
            taxonomy_list or []
        )

        return job_id

    def create_job(self):
        job_id = str(uuid.uuid4())
        redis_client.set(f"job:{job_id}:status", "queued")
        return job_id

    def search_candidates(self, query, limit=8):
        return self.candidate_resolver.search_candidates(
            query,
            limit=limit
        )

    def collect_source_evidence(self, query, limit=8):
        return self.candidate_resolver.collect_source_evidence(
            query,
            limit=limit
        )

    def choose_candidate_for_excel(self, query):
        return self.candidate_resolver.choose_for_excel(query)

    # =========================
    # STATUS
    # =========================

    def get_status(self, job_id):
        return redis_client.get(f"job:{job_id}:status")

    # =========================
    # RESULT
    # =========================

    def get_result(self, job_id):
        data = redis_client.get(f"job:{job_id}:result")
        return json.loads(data) if data else None

    # =========================
    # MAIN PIPELINE
    # =========================

    def run_full_pipeline(
        self,
        job_id,
        company_name,
        taxonomy_list=None,
        selected_title=None,
        selected_confidence=None,
        include_news=True
    ):
        try:
            return self._run_full_pipeline(
                job_id,
                company_name,
                taxonomy_list,
                selected_title=selected_title,
                selected_confidence=selected_confidence,
                include_news=include_news
            )
        except Exception as e:
            result = {
                "company_name": company_name,
                "status": "failed",
                "error": str(e)
            }
            redis_client.set(f"job:{job_id}:status", "failed")
            redis_client.set(f"job:{job_id}:result", json.dumps(result))
            return result

    def _run_full_pipeline(
        self,
        job_id,
        company_name,
        taxonomy_list=None,
        selected_title=None,
        selected_confidence=None,
        include_news=True
    ):

        taxonomy_list = taxonomy_list or []
        normalized_name = normalize_company_name(company_name)
        cache_key = (
            f"company:v5:{normalized_name}:"
            f"{normalize_company_name(selected_title or '')}:"
            f"news:{bool(include_news)}"
        )

        cached = get_cache(cache_key)
        if cached:
            redis_client.set(f"job:{job_id}:status", "done")
            redis_client.set(f"job:{job_id}:result", cached)
            return json.loads(cached)

        redis_client.set(f"job:{job_id}:status", "processing")

        # 1. SEC first. It is a strong identifier for listed companies.
        sec = self.sec.enrich(company_name)

        yahoo = (
            self.yahoo.enrich(
                sec.get("legal_name") or company_name
            )
            if ENABLE_YAHOO
            else {}
        )

        search_name = (
            sec.get("legal_name")
            or yahoo.get("legal_name")
            or company_name
        )

        # 2. Wikipedia with safer entity resolution
        wiki = self.wiki.enrich(
            search_name,
            selected_title=selected_title,
            selected_confidence=selected_confidence
        )
        wiki["input_company_name"] = company_name

        if wiki.get("error"):
            result = {
                **wiki,
                **{
                    key: value
                    for key, value in yahoo.items()
                    if value not in [None, "", [], {}]
                },
                "sec": sec,
                "yahoo": yahoo,
                "data_sources": {
                    "wikipedia": False,
                    "wikidata": False,
                    "sec": bool(sec.get("ticker")),
                    "yahoo": bool(yahoo.get("ticker")),
                    "website": False
                },
                "confidence_score": 20 if (
                    sec.get("ticker")
                    or yahoo.get("ticker")
                ) else 0
            }

            set_cache(cache_key, json.dumps(result), CACHE_TTL_SECONDS)
            redis_client.set(
                f"job:{job_id}:status",
                "done" if yahoo.get("ticker") else "needs_review"
            )
            redis_client.set(f"job:{job_id}:result", json.dumps(result))
            return result

        # 3. Wikidata from verified Wikipedia page
        wikidata = self.wikidata.enrich(
            wiki.get("wikipedia_title")
        )

        # 4. Recent news context
        news = (
            self.news.enrich(
                wiki.get("wikipedia_title") or company_name
            )
            if ENABLE_NEWS and include_news
            else {
                "articles": []
            }
        )

        # 5. Website
        website_url = (
            wikidata.get("official_website")
            or wiki.get("website")
        )
        website = (
            self.website.enrich(website_url)
            if ENABLE_WEBSITE
            else {
                "about_page": website_url,
                "website_content": ""
            }
        )

        # 6. Ownership
        ownership = self.ownership.enrich(
            wiki,
            wikidata,
            sec
        )

        # 7. Merge
        result = self.merger.enrich(
            wiki,
            wikidata,
            sec,
            ownership,
            website,
            taxonomy_list=taxonomy_list,
            yahoo_data=yahoo,
            news_data=news
        )

        result["input_company_name"] = company_name
        result["confidence_score"] = self.scorer.calculate(
            wiki,
            wikidata,
            sec,
            yahoo_data=yahoo,
            news_data=news
        )

        # cache result
        set_cache(cache_key, json.dumps(result), CACHE_TTL_SECONDS)

        # job store
        redis_client.set(f"job:{job_id}:status", "done")
        redis_client.set(f"job:{job_id}:result", json.dumps(result))

        return result
