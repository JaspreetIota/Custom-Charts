import re
from datetime import datetime

import requests
from bs4 import BeautifulSoup
from rapidfuzz import fuzz

from app.services.entity_resolver_service import EntityResolverService
from app.utils.company_name import normalize_company_name


class WikipediaService:

    def __init__(self):

        self.session = requests.Session()

        self.session.headers.update({
            "User-Agent": "CompanyEnrichmentBot/1.0"
        })

        self.resolver = EntityResolverService()

    def title_match_score(self, company_name, page_title):
        return max(
            fuzz.token_set_ratio(
                normalize_company_name(company_name),
                normalize_company_name(page_title)
            ),
            fuzz.partial_ratio(
                normalize_company_name(company_name),
                normalize_company_name(page_title)
            )
        )

    def search_company(self, company_name):

        try:

            url = "https://en.wikipedia.org/w/api.php"

            params = {
                "action": "query",
                "list": "search",
                "srsearch": company_name,
                "format": "json"
            }

            response = self.session.get(
                url,
                params=params,
                timeout=30
            )

            response.raise_for_status()

            results = (
                response.json()
                .get("query", {})
                .get("search", [])
            )

            if not results:
                return None

            query = normalize_company_name(company_name)

            best_title = None
            best_score = 0

            for item in results[:10]:

                title = item["title"]

                normalized_title = normalize_company_name(title)

                score = self.title_match_score(
                    query,
                    normalized_title
                )

                if score > best_score:
                    best_score = score
                    best_title = title

            if best_score < 70:
                return None

            return best_title

        except Exception:
            return None

    def validate_title(self, company_name, page_title):

        try:
            score = self.title_match_score(
                company_name,
                page_title
            )

            return score >= 75

        except Exception:
            return True

    def get_summary(self, page_title):

        try:

            url = (
                f"https://en.wikipedia.org/"
                f"api/rest_v1/page/summary/"
                f"{page_title}"
            )

            response = self.session.get(
                url,
                timeout=30
            )

            if response.status_code != 200:
                return {}

            data = response.json()

            return {
                "description": data.get("description"),
                "summary": data.get("extract")
            }

        except Exception:
            return {}

    def get_infobox(self, page_title):

        try:

            page_url = (
                "https://en.wikipedia.org/wiki/"
                + page_title.replace(" ", "_")
            )

            html = self.session.get(
                page_url,
                timeout=30
            ).text

            soup = BeautifulSoup(html, "lxml")

            infobox = soup.find(
                "table",
                class_="infobox"
            )

            if not infobox:
                return {}

            result = {}

            for row in infobox.find_all("tr"):

                header = row.find("th")
                value = row.find("td")

                if not header or not value:
                    continue

                result[header.get_text(" ", strip=True)] = (
                    value.get_text(" ", strip=True)
                )

            return result

        except Exception:
            return {}

    def extract_founded_year(self, infobox):

        founded = infobox.get("Founded")

        if not founded:
            return None

        match = re.search(
            r"(18|19|20)\d{2}",
            founded
        )

        if match:
            return int(match.group())

        return None

    def extract_website(self, infobox):

        for key in ["Website", "website", "Web site"]:

            if key in infobox:

                website = (
                    infobox[key]
                    .replace(" ", "")
                    .strip()
                )

                if not website:
                    return None

                if not website.startswith(
                    ("http://", "https://")
                ):
                    website = "https://" + website

                return website

        return None

    def detect_ownership(self, infobox):

        result = {
            "ownership_type": "Unknown",
            "ownership_status": "Active",
            "parent_company": None
        }

        parent = (
            infobox.get("Parent")
            or infobox.get("Owner")
        )

        if parent:

            result["ownership_type"] = "Subsidiary"
            result["parent_company"] = parent

            return result

        company_type = (
            infobox.get("Type")
            or ""
        ).lower()

        if "public" in company_type:
            result["ownership_type"] = "Public Company"
        elif "private" in company_type:
            result["ownership_type"] = "Private Company"
        elif "joint venture" in company_type:
            result["ownership_type"] = "Joint Venture"

        return result

    def calculate_startup_flag(self, founded_year):

        if not founded_year:
            return False

        return (
            datetime.now().year
            - founded_year
        ) <= 10

    def calculate_company_age(self, founded_year):

        if not founded_year:
            return None

        return (
            datetime.now().year
            - founded_year
        )

    def enrich(
        self,
        company_name,
        selected_title=None,
        selected_confidence=None
    ):

        # ----------------------------------
        # Resolve entity
        # ----------------------------------

        if selected_title:
            resolved_result = {
                "resolved_title": selected_title,
                "confidence": selected_confidence or 100,
                "status": "selected"
            }
            resolved_name = selected_title
        else:
            resolved_result = self.resolver.resolve(
                company_name
            )

            resolved_name = resolved_result.get(
                "resolved_title",
                company_name
            )

            if resolved_result.get("status") == "needs_review":
                return {
                    "company_name": company_name,
                    "error": "Company match needs manual review",
                    "match_status": "needs_review",
                    "match_confidence": resolved_result.get("confidence", 0),
                    "match_candidates": resolved_result.get("candidates", [])
                }

        print("=" * 50)
        print(f"Original: {company_name}")
        print(f"Resolved Result: {resolved_result}")
        print(f"Resolved Name: {resolved_name}")
        print("=" * 50)

        # ----------------------------------
        # Search Wikipedia
        # ----------------------------------

        page_title = (
            selected_title
            or self.search_company(
                resolved_name
            )
        )

        print(
            f"Wikipedia Title: {page_title}"
        )

        if not page_title:

            return {
                "company_name": company_name,
                "error": "Company not found"
            }

        # ----------------------------------
        # Validate match
        # ----------------------------------

        if not self.validate_title(
            resolved_name,
            page_title
        ):

            return {
                "company_name": company_name,
                "error": "No close Wikipedia match found"
            }

        title_confidence = self.title_match_score(
            resolved_name,
            page_title
        )

        match_confidence = max(
            int(resolved_result.get("confidence", 0) or 0),
            int(title_confidence)
        )

        # ----------------------------------
        # Summary
        # ----------------------------------

        summary = self.get_summary(
            page_title
        )

        description = (
            summary.get(
                "description",
                ""
            ).lower()
        )

        blocked_keywords = [
            "actor",
            "actress",
            "footballer",
            "cricketer",
            "politician",
            "singer",
            "youtuber",
            "animator",
            "film",
            "album",
            "song"
        ]

        if any(
            keyword in description
            for keyword in blocked_keywords
        ):

            return {
                "company_name": company_name,
                "error": "Not a supported entity type"
            }

        # ----------------------------------
        # Infobox
        # ----------------------------------

        infobox = self.get_infobox(
            page_title
        )

        founded_year = (
            self.extract_founded_year(
                infobox
            )
        )

        ownership = (
            self.detect_ownership(
                infobox
            )
        )

        # ----------------------------------
        # Final Response
        # ----------------------------------

        return {

            "company_name": company_name,

            "wikipedia_title": page_title,

            "match_status": resolved_result.get(
                "status",
                "matched"
            ),

            "match_confidence": match_confidence,

            "description": summary.get(
                "description"
            ),

            "summary": summary.get(
                "summary"
            ),

            "website": self.extract_website(
                infobox
            ),

            "industry": infobox.get(
                "Industry"
            ),

            "headquarters": infobox.get(
                "Headquarters"
            ),

            "founded_year": founded_year,

            "company_age": self.calculate_company_age(
                founded_year
            ),

            "startup_flag": self.calculate_startup_flag(
                founded_year
            ),

            "ownership_type": ownership.get(
                "ownership_type"
            ),

            "ownership_status": ownership.get(
                "ownership_status"
            ),

            "parent_company": ownership.get(
                "parent_company"
            ),

            "ultimate_parent": None,

            "joint_venture_flag":
                ownership.get(
                    "ownership_type"
                ) == "Joint Venture",

            "employees_raw":
                infobox.get(
                    "Number of employees"
                ),

            "employees": None,

            "revenue_raw":
                infobox.get(
                    "Revenue"
                ),

            "revenue": None,

            "country": None,

            "ticker": None,

            "exchange": None,

            "core_business": None,

            "ceo": None,

            "wikidata_id": None,

            "confidence_score": 30,

            "sources": {
                "description": "Wikipedia",
                "summary": "Wikipedia",
                "industry": "Wikipedia",
                "headquarters": "Wikipedia",
                "founded_year": "Wikipedia",
                "website": "Wikipedia",
                "employees": "Wikipedia",
                "revenue": "Wikipedia"
            }
        }
