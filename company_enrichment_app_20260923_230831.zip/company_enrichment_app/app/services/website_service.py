import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin


class WebsiteService:

    def __init__(self):

        self.session = requests.Session()

        self.session.headers.update({
            "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        })

    # ==================================================
    # FIND ABOUT PAGE
    # ==================================================

    def find_about_page(
        self,
        website
    ):

        try:

            print(f"Opening website: {website}")

            response = self.session.get(
                website,
                timeout=(5, 15),
                allow_redirects=True
            )

            print(
                f"Website Response: {response.status_code}"
            )

            soup = BeautifulSoup(
                response.text,
                "html.parser"
            )

            keywords = [

                "about",
                "about us",
                "company",
                "corporate",
                "who we are",
                "our story",
                "our company"
                "company info",
                "company information",
                "overview",
                "investor relations"

            ]

            for link in soup.find_all("a"):

                text = (
                    link.get_text(
                        strip=True
                    )
                    .lower()
                )

                href = link.get("href")

                if not href:
                    continue

                for keyword in keywords:

                    if keyword in text:

                        about_page = urljoin(
                            response.url,
                            href
                        )

                        print(
                            f"Found About Page: {about_page}"
                        )

                        return about_page

            print(
                "About page not found, using homepage"
            )

            return response.url

        except Exception as e:

            print(
                f"About Page Error: {e}"
            )

            return website

    # ==================================================
    # EXTRACT TEXT
    # ==================================================

    def extract_text(
        self,
        url
    ):

        try:

            print(
                f"Extracting content from: {url}"
            )

            response = self.session.get(
                url,
                timeout=(5, 15),
                allow_redirects=True
            )

            print(
                f"Content Response: {response.status_code}"
            )

            soup = BeautifulSoup(
                response.text,
                "html.parser"
            )

            for tag in soup([
                "script",
                "style",
                "noscript",
                "svg"
            ]):
                tag.decompose()

            text = soup.get_text(
                separator=" ",
                strip=True
            )

            text = " ".join(
                text.split()
            )

            print(
                f"Characters Extracted: {len(text)}"
            )

            return text[:3000]

        except Exception as e:

            print(
                f"Content Extraction Error: {e}"
            )

            return ""

    # ==================================================
    # MAIN
    # ==================================================

    def enrich(
        self,
        website
    ):

        if not website:

            return {
                "about_page": None,
                "website_content": ""
            }

        print("\nStarting Website Crawl\n")

        about_page = (
            self.find_about_page(
                website
            )
        )

        content = (
            self.extract_text(
                about_page
            )
        )

        return {

            "about_page":
                about_page,

            "website_content":
                content
        }