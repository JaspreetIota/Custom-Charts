import json
from datetime import datetime

from psycopg2 import pool
from psycopg2.extras import Json, RealDictCursor

from app.core.config import POSTGRES_URL
from app.utils.company_name import normalize_company_name


class CompanyCacheService:
    def __init__(self):
        self._pool = None
        self._initialized = False

    def _connect_pool(self):
        if self._pool is None:
            self._pool = pool.SimpleConnectionPool(
                1,
                6,
                POSTGRES_URL
            )
        return self._pool

    def _connection(self):
        return self._connect_pool().getconn()

    def _release(self, conn):
        self._connect_pool().putconn(conn)

    def _ensure_table(self):
        if self._initialized:
            return

        conn = self._connection()
        try:
            with conn.cursor() as cursor:
                cursor.execute(
                    """
                    CREATE TABLE IF NOT EXISTS saved_company_results (
                        id SERIAL PRIMARY KEY,
                        query_name TEXT NOT NULL,
                        normalized_query TEXT NOT NULL UNIQUE,
                        company_name TEXT,
                        normalized_company_name TEXT,
                        result JSONB NOT NULL,
                        reviewed BOOLEAN NOT NULL DEFAULT FALSE,
                        notes TEXT,
                        hit_count INTEGER NOT NULL DEFAULT 0,
                        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                        last_accessed_at TIMESTAMPTZ
                    )
                    """
                )
                cursor.execute(
                    """
                    CREATE INDEX IF NOT EXISTS idx_saved_company_name
                    ON saved_company_results (normalized_company_name)
                    """
                )
                cursor.execute(
                    """
                    CREATE INDEX IF NOT EXISTS idx_saved_company_updated
                    ON saved_company_results (updated_at DESC)
                    """
                )
            conn.commit()
            self._initialized = True
        finally:
            self._release(conn)

    def _normalize(self, value):
        return normalize_company_name(value or "")

    def is_cacheable(self, result):
        if not result:
            return False

        status = (
            result.get("enrichment_status")
            or result.get("match_status")
            or result.get("status")
        )
        if status in ["failed", "skipped_blank", "not_found"]:
            return False

        return bool(
            result.get("company_name")
            or result.get("official_website")
            or result.get("website")
            or result.get("wikidata_id")
            or result.get("ticker")
        )

    def get_by_query(self, query_name):
        normalized = self._normalize(query_name)
        if not normalized:
            return None

        self._ensure_table()
        conn = self._connection()
        try:
            with conn.cursor(cursor_factory=RealDictCursor) as cursor:
                cursor.execute(
                    """
                    SELECT *
                    FROM saved_company_results
                    WHERE normalized_query = %s
                       OR normalized_company_name = %s
                    ORDER BY
                        CASE WHEN normalized_query = %s THEN 0 ELSE 1 END,
                        reviewed DESC,
                        updated_at DESC
                    LIMIT 1
                    """,
                    (normalized, normalized, normalized)
                )
                row = cursor.fetchone()
                if not row:
                    return None

                cursor.execute(
                    """
                    UPDATE saved_company_results
                    SET hit_count = hit_count + 1,
                        last_accessed_at = NOW()
                    WHERE id = %s
                    """,
                    (row["id"],)
                )
                conn.commit()
                return self._format_row(row)
        finally:
            self._release(conn)

    def save_result(self, query_name, result):
        if not self.is_cacheable(result):
            return None

        normalized_query = self._normalize(query_name)
        if not normalized_query:
            return None

        company_name = result.get("company_name") or query_name
        normalized_company = self._normalize(company_name)
        result = {
            **result,
            "database_cached": True,
            "database_query_name": query_name
        }

        self._ensure_table()
        conn = self._connection()
        try:
            with conn.cursor(cursor_factory=RealDictCursor) as cursor:
                cursor.execute(
                    """
                    INSERT INTO saved_company_results (
                        query_name,
                        normalized_query,
                        company_name,
                        normalized_company_name,
                        result
                    )
                    VALUES (%s, %s, %s, %s, %s)
                    ON CONFLICT (normalized_query)
                    DO UPDATE SET
                        query_name = EXCLUDED.query_name,
                        company_name = EXCLUDED.company_name,
                        normalized_company_name = EXCLUDED.normalized_company_name,
                        result = EXCLUDED.result,
                        updated_at = NOW()
                    RETURNING *
                    """,
                    (
                        query_name,
                        normalized_query,
                        company_name,
                        normalized_company,
                        Json(result)
                    )
                )
                row = cursor.fetchone()
            conn.commit()
            return self._format_row(row)
        finally:
            self._release(conn)

    def list_records(self, query=None, limit=50, offset=0):
        self._ensure_table()
        limit = max(1, min(int(limit or 50), 200))
        offset = max(0, int(offset or 0))
        normalized = self._normalize(query)
        like_query = f"%{(query or '').strip()}%"

        conn = self._connection()
        try:
            with conn.cursor(cursor_factory=RealDictCursor) as cursor:
                if query:
                    cursor.execute(
                        """
                        SELECT *
                        FROM saved_company_results
                        WHERE normalized_query LIKE %s
                           OR normalized_company_name LIKE %s
                           OR query_name ILIKE %s
                           OR company_name ILIKE %s
                        ORDER BY updated_at DESC
                        LIMIT %s OFFSET %s
                        """,
                        (
                            f"%{normalized}%",
                            f"%{normalized}%",
                            like_query,
                            like_query,
                            limit,
                            offset
                        )
                    )
                else:
                    cursor.execute(
                        """
                        SELECT *
                        FROM saved_company_results
                        ORDER BY updated_at DESC
                        LIMIT %s OFFSET %s
                        """,
                        (limit, offset)
                    )
                return [self._format_row(row) for row in cursor.fetchall()]
        finally:
            self._release(conn)

    def get_record(self, record_id):
        self._ensure_table()
        conn = self._connection()
        try:
            with conn.cursor(cursor_factory=RealDictCursor) as cursor:
                cursor.execute(
                    """
                    SELECT *
                    FROM saved_company_results
                    WHERE id = %s
                    """,
                    (record_id,)
                )
                row = cursor.fetchone()
                return self._format_row(row) if row else None
        finally:
            self._release(conn)

    def create_manual_record(
        self,
        query_name,
        result,
        reviewed=False,
        notes=None
    ):
        result = result or {}
        result.setdefault("company_name", query_name)
        saved = self.save_result(query_name, result)
        if not saved:
            return None
        return self.update_record(
            saved["id"],
            query_name=query_name,
            result=result,
            reviewed=reviewed,
            notes=notes
        )

    def update_record(
        self,
        record_id,
        query_name=None,
        company_name=None,
        result=None,
        reviewed=None,
        notes=None
    ):
        existing = self.get_record(record_id)
        if not existing:
            return None

        next_result = result if result is not None else existing["result"]
        next_query = query_name or existing["query_name"]
        next_company = (
            company_name
            or next_result.get("company_name")
            or existing.get("company_name")
            or next_query
        )
        next_reviewed = (
            reviewed
            if reviewed is not None
            else existing.get("reviewed", False)
        )
        next_notes = notes if notes is not None else existing.get("notes")

        self._ensure_table()
        conn = self._connection()
        try:
            with conn.cursor(cursor_factory=RealDictCursor) as cursor:
                cursor.execute(
                    """
                    UPDATE saved_company_results
                    SET query_name = %s,
                        normalized_query = %s,
                        company_name = %s,
                        normalized_company_name = %s,
                        result = %s,
                        reviewed = %s,
                        notes = %s,
                        updated_at = NOW()
                    WHERE id = %s
                    RETURNING *
                    """,
                    (
                        next_query,
                        self._normalize(next_query),
                        next_company,
                        self._normalize(next_company),
                        Json(next_result),
                        next_reviewed,
                        next_notes,
                        record_id
                    )
                )
                row = cursor.fetchone()
            conn.commit()
            return self._format_row(row)
        finally:
            self._release(conn)

    def delete_record(self, record_id):
        self._ensure_table()
        conn = self._connection()
        try:
            with conn.cursor() as cursor:
                cursor.execute(
                    """
                    DELETE FROM saved_company_results
                    WHERE id = %s
                    """,
                    (record_id,)
                )
                deleted = cursor.rowcount > 0
            conn.commit()
            return deleted
        finally:
            self._release(conn)

    def _format_row(self, row):
        if not row:
            return None

        data = dict(row)
        result = data.get("result")
        if isinstance(result, str):
            result = json.loads(result)
        data["result"] = result

        for key, value in list(data.items()):
            if isinstance(value, datetime):
                data[key] = value.isoformat()

        return data
