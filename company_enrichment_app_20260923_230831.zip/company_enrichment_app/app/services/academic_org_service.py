import requests


class AcademicOrgService:
    """Search specialist organization registries for non-company entities."""

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "CompanyEnrichmentBot/1.0"
        })

    def search_openalex(self, query, limit=5):
        try:
            response = self.session.get(
                "https://api.openalex.org/institutions",
                params={
                    "search": query,
                    "per-page": limit
                },
                timeout=(1.5, 5)
            )
            response.raise_for_status()
            return response.json().get("results", [])
        except Exception:
            return []

    def search_ror(self, query, limit=5):
        try:
            response = self.session.get(
                "https://api.ror.org/organizations",
                params={
                    "query": query,
                    "page": 1
                },
                timeout=(1.5, 5)
            )
            response.raise_for_status()
            items = response.json().get("items", [])
            return items[:limit]
        except Exception:
            return []

    def search_crossref_funders(self, query, limit=5):
        try:
            response = self.session.get(
                "https://api.crossref.org/funders",
                params={
                    "query": query,
                    "rows": limit
                },
                timeout=(1.5, 5)
            )
            response.raise_for_status()
            return (
                response.json()
                .get("message", {})
                .get("items", [])
            )
        except Exception:
            return []
