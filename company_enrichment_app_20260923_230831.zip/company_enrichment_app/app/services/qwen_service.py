import json

import requests

from app.core.config import (
    QWEN_ENABLED,
    QWEN_BASE_URL,
    QWEN_MODEL,
    QWEN_TIMEOUT_SECONDS
)


class QwenService:
    def __init__(self):
        self.base_urls = [
            QWEN_BASE_URL.rstrip("/"),
            "http://localhost:11434"
        ]
        self.url = None
        self.tags_url = None
        self._available = None

    def is_available(self):
        if not QWEN_ENABLED:
            self._available = False
            return self._available

        if self._available is not None:
            return self._available

        for base_url in self.base_urls:
            try:
                response = requests.get(
                    f"{base_url}/api/tags",
                    timeout=(0.5, 1)
                )
                if response.status_code == 200:
                    self.url = f"{base_url}/api/generate"
                    self.tags_url = f"{base_url}/api/tags"
                    self._available = True
                    return self._available
            except Exception:
                continue

        self._available = False

        return self._available

    def _extract_json(self, output):
        start = output.find("{")
        end = output.rfind("}")

        if start == -1 or end == -1:
            return {}

        try:
            return json.loads(output[start:end + 1])
        except Exception:
            return {}

    def _generate(self, prompt):
        try:
            if not self.is_available():
                return ""

            response = requests.post(
                self.url,
                json={
                    "model": QWEN_MODEL,
                    "prompt": prompt,
                    "stream": False
                },
                timeout=QWEN_TIMEOUT_SECONDS
            )
            response.raise_for_status()

            return response.json().get(
                "response",
                ""
            ).strip()

        except Exception as e:
            print(f"Qwen Error: {e}")
            return ""

    def classify_core_business(self, context, taxonomy_list):
        try:
            prompt = f"""
You are a company classification expert.

Company Information:
{context}

Available Taxonomy Categories:
{taxonomy_list}

Select the SINGLE best matching taxonomy.
Return ONLY valid JSON.

Example:

{{
    "core_business": "Cloud Software",
    "confidence": 92
}}
"""

            result = self._extract_json(
                self._generate(prompt)
            )

            if not result:
                return {
                    "core_business": None,
                    "confidence": 0
                }

            return {
                "core_business": result.get("core_business"),
                "confidence": result.get("confidence", 0)
            }

        except Exception as e:
            print(f"Core Business Error: {e}")
            return {
                "core_business": None,
                "confidence": 0
            }

    def classify_entity_type(self, description):
        if not description:
            return {
                "entity_type": "Unknown"
            }

        try:
            prompt = f"""
You are an entity classification expert.

Classify the entity into EXACTLY ONE of:

- Company
- University
- Organization
- Government Agency
- Research Institute
- Non-profit

Description:

{description}

Return ONLY valid JSON.

Example:

{{
    "entity_type": "University"
}}
"""

            result = self._extract_json(
                self._generate(prompt)
            )

            if not result:
                return {
                    "entity_type": "Unknown"
                }

            entity_type = result.get(
                "entity_type",
                "Unknown"
            )

            allowed = [
                "Company",
                "University",
                "Organization",
                "Government Agency",
                "Research Institute",
                "Non-profit"
            ]

            if entity_type not in allowed:
                entity_type = "Unknown"

            return {
                "entity_type": entity_type
            }

        except Exception as e:
            print(f"Entity Type Classification Error: {e}")
            return {
                "entity_type": "Unknown"
            }

    def generate_company_insights(self, context):
        try:
            prompt = f"""
You are a company enrichment analyst.

Use the company information below to infer practical business metadata.
Do not invent exact financial numbers. Prefer "Unknown" when evidence is weak.

Company Information:
{context}

Return ONLY valid JSON with this schema:

{{
    "ai_company_overview": "one concise sentence",
    "ai_core_business": "specific core business",
    "ai_business_tags": ["tag 1", "tag 2", "tag 3"],
    "ai_recent_news_summary": "one concise sentence or Unknown",
    "ai_risk_signals": ["signal 1"],
    "ai_confidence": 0
}}
"""

            result = self._extract_json(
                self._generate(prompt)
            )

            if not result:
                return {
                    "ai_insights_used": False
                }

            tags = result.get("ai_business_tags") or []
            risks = result.get("ai_risk_signals") or []

            return {
                "ai_company_overview":
                    result.get("ai_company_overview"),
                "ai_core_business":
                    result.get("ai_core_business"),
                "ai_business_tags":
                    tags if isinstance(tags, list) else [],
                "ai_recent_news_summary":
                    result.get("ai_recent_news_summary"),
                "ai_risk_signals":
                    risks if isinstance(risks, list) else [],
                "ai_confidence":
                    int(result.get("ai_confidence", 0) or 0),
                "ai_insights_used":
                    True
            }

        except Exception as e:
            print(f"Company Insights Error: {e}")
            return {
                "ai_insights_used": False
            }

    def infer_minimal_company_details(self, company_name):
        try:
            prompt = f"""
You are helping with company enrichment only when public data sources failed.

Company/entity name:
{company_name}

Return ONLY valid JSON. Do not include any explanation.
Only include these fields:

{{
    "name": "official or most likely company/entity name, or Unknown",
    "core_business": "short business description, or Unknown",
    "revenue": "publicly known revenue with year, or Unknown",
    "founding_year": "year only, or Unknown",
    "website": "official website URL, or Unknown",
    "ownership_details": "private/public/parent/group details, or Unknown",
    "ai_confidence": 0
}}

Rules:
- Prefer Unknown over guessing.
- Do not invent exact revenue.
- ai_confidence must be 0-70 because this is unverified fallback data.
"""

            result = self._extract_json(
                self._generate(prompt)
            )

            if not result:
                return {
                    "ai_suggested": False
                }

            confidence = int(result.get("ai_confidence", 0) or 0)

            return {
                "ai_suggested": True,
                "ai_name": result.get("name"),
                "ai_core_business": result.get("core_business"),
                "ai_revenue": result.get("revenue"),
                "ai_founding_year": result.get("founding_year"),
                "ai_website": result.get("website"),
                "ai_ownership_details": result.get("ownership_details"),
                "ai_confidence": min(confidence, 70)
            }

        except Exception as e:
            print(f"Qwen Minimal Fallback Error: {e}")
            return {
                "ai_suggested": False
            }
