import re

import requests
from rapidfuzz import fuzz

from app.services.academic_org_service import AcademicOrgService
from app.utils.company_name import normalize_company_name, name_tokens


class CandidateResolverService:
    AUTO_ACCEPT_SCORE = 95
    CONDITIONAL_ACCEPT_SCORE = 88
    REVIEW_SCORE = 70
    FIRST_CANDIDATE_SCORE = 88
    MIN_FIRST_CANDIDATE_LEAD = 8

    ENTITY_KEYWORDS = {
        "Hospital": [
            "hospital",
            "medical center",
            "healthcare",
            "clinic",
            "health system"
        ],
        "University": [
            "university",
            "college",
            "school"
        ],
        "Government Agency": [
            "government",
            "ministry",
            "agency",
            "department"
        ],
        "Research Institute": [
            "research institute",
            "research center",
            "laboratory"
        ],
        "Non-profit": [
            "non-profit",
            "nonprofit",
            "charity",
            "foundation"
        ],
        "Company": [
            "company",
            "corporation",
            "manufacturer",
            "business",
            "enterprise",
            "multinational",
            "conglomerate",
            "subsidiary",
            "automotive",
            "software",
            "pharmaceutical",
            "financial"
        ],
        "Organization": [
            "organization",
            "organisation",
            "association",
            "federation"
        ]
    }

    REJECT_KEYWORDS = [
        "song",
        "album",
        "film",
        "movie",
        "television series",
        "video game",
        "novel",
        "book",
        "character",
        "fictional",
        "species",
        "plant",
        "tree",
        "cultivar",
        "fruit",
        "food",
        "line of smartphones",
        "smartphone",
        "tablet computer",
        "laptop",
        "operating system",
        "software release",
        "mobile app",
        "application software",
        "device",
        "product",
        "model",
        "brand of"
    ]

    KNOWN_ENTITIES = {
        "100pro": {
            "name": "100Pro Corp",
            "entity_type": "Company",
            "description": "Healthcare and diabetes technology company.",
            "website": None,
            "country": None
        },
        "1drop diagnostics": {
            "name": "1Drop Diagnostics",
            "entity_type": "Company",
            "description": "Diagnostics company focused on point-of-care testing.",
            "website": None,
            "country": None
        },
        "aaruy medical electronics": {
            "name": "AARUY Medical Electronics",
            "entity_type": "Company",
            "description": "Medical electronics company.",
            "website": None,
            "country": None
        },
        "acme beijing technology": {
            "name": "ACME (Beijing) Technology Co.",
            "entity_type": "Company",
            "description": "Beijing-based technology company.",
            "website": None,
            "country": "China"
        },
        "acon diabetes care": {
            "name": "ACON Diabetes Care",
            "entity_type": "Company",
            "description": "Diabetes care company focused on glucose monitoring products.",
            "website": "https://www.aconlabs.com",
            "country": "United States"
        },
        "acon laboratories": {
            "name": "ACON Laboratories, Inc.",
            "entity_type": "Company",
            "description": "Diagnostics and medical device company.",
            "website": "https://www.aconlabs.com",
            "country": "United States"
        },
        "adin research": {
            "name": "AdIn Research",
            "entity_type": "Company",
            "description": "Healthcare research and medical technology company.",
            "website": None,
            "country": None
        },
        "aimmed": {
            "name": "AIMMED Co., Ltd.",
            "entity_type": "Company",
            "description": "Digital healthcare company.",
            "website": "https://www.aimmed.com",
            "country": "South Korea"
        },
        "akili": {
            "name": "Akili, Inc.",
            "entity_type": "Company",
            "description": "Digital therapeutics company.",
            "website": "https://www.akiliinteractive.com",
            "country": "United States"
        },
        "ascensia diabetes care": {
            "name": "Ascensia Diabetes Care",
            "entity_type": "Company",
            "description": "Diabetes care company focused on blood glucose monitoring products.",
            "website": "https://www.ascensia.com",
            "country": "Switzerland"
        },
        "lifescan ip": {
            "name": "LifeScan",
            "entity_type": "Company",
            "description": "Medical device company focused on blood glucose monitoring.",
            "website": "https://www.lifescan.com",
            "country": "United States"
        },
        "lifescan": {
            "name": "LifeScan",
            "entity_type": "Company",
            "description": "Medical device company focused on blood glucose monitoring.",
            "website": "https://www.lifescan.com",
            "country": "United States"
        },
        "agamatrix": {
            "name": "AgaMatrix",
            "entity_type": "Company",
            "description": "Diabetes technology company focused on blood glucose monitoring systems.",
            "website": "https://agamatrix.com",
            "country": "United States"
        },
        "arkray": {
            "name": "ARKRAY",
            "entity_type": "Company",
            "description": "Japanese medical diagnostics company manufacturing diabetes testing systems.",
            "website": "https://www.arkray.co.jp",
            "country": "Japan"
        }
    }

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "CompanyEnrichmentBot/1.0"
        })
        self.academic_orgs = AcademicOrgService()

    def _strip_html(self, value):
        if not value:
            return ""
        return re.sub(r"<[^>]+>", " ", value)

    def _detect_entity_type(self, text):
        lowered = (text or "").lower()

        for entity_type, keywords in self.ENTITY_KEYWORDS.items():
            if any(keyword in lowered for keyword in keywords):
                return entity_type

        return "Unknown"

    def _is_non_entity(self, text):
        lowered = (text or "").lower()

        if "record label" in lowered:
            return False

        if any(keyword in lowered for keyword in self.REJECT_KEYWORDS):
            return True

        return False

    def _search_wikipedia(self, query, limit=10):
        try:
            response = self.session.get(
                "https://en.wikipedia.org/w/api.php",
                params={
                    "action": "query",
                    "list": "search",
                    "srsearch": query,
                    "srlimit": limit,
                    "format": "json"
                },
                timeout=(1.5, 5)
            )
            response.raise_for_status()

            return (
                response.json()
                .get("query", {})
                .get("search", [])
            )
        except Exception:
            return []

    def _search_yahoo(self, query, limit=10):
        try:
            response = self.session.get(
                "https://query2.finance.yahoo.com/v1/finance/search",
                params={
                    "q": query,
                    "quotesCount": limit,
                    "newsCount": 0
                },
                timeout=(1.5, 5)
            )
            response.raise_for_status()

            return [
                quote
                for quote in response.json().get("quotes", [])
                if quote.get("symbol")
                and quote.get("quoteType") in ["EQUITY", "ETF"]
            ]
        except Exception:
            return []

    def _search_wikidata(self, query, limit=10):
        try:
            response = self.session.get(
                "https://www.wikidata.org/w/api.php",
                params={
                    "action": "wbsearchentities",
                    "search": query,
                    "language": "en",
                    "format": "json",
                    "limit": limit
                },
                timeout=(1.5, 5)
            )
            response.raise_for_status()
            return response.json().get("search", [])
        except Exception:
            return []

    def _score_name(self, query, title):
        comparable_query = re.sub(
            r"^\s*The\s+Trustees\s+of\s+",
            "",
            query,
            flags=re.IGNORECASE
        )
        comparable_query = re.sub(
            r"^\s*Trustees\s+of\s+",
            "",
            comparable_query,
            flags=re.IGNORECASE
        )
        normalized_query = normalize_company_name(comparable_query)
        title_without_parentheses = re.sub(
            r"\([^)]*\)",
            "",
            title
        )
        normalized_title = normalize_company_name(
            title_without_parentheses
        )

        if not normalized_query or not normalized_title:
            return 0, "No comparable name"

        if normalized_query == normalized_title:
            return 100, "Exact normalized name match"

        query_tokens = name_tokens(comparable_query)
        title_tokens = name_tokens(title)

        if normalized_query.replace(" ", "") == normalized_title.replace(" ", ""):
            return 96, "Exact compact name match"

        token_score = fuzz.token_sort_ratio(
            normalized_query,
            normalized_title
        )
        set_score = fuzz.token_set_ratio(
            normalized_query,
            normalized_title
        )
        score = max(token_score, set_score)

        if query_tokens and query_tokens.issubset(title_tokens):
            extra_tokens = len(title_tokens - query_tokens)
            score -= extra_tokens * 6
            return max(0, score), "Contains query terms with extra words"

        if title_tokens and title_tokens.issubset(query_tokens):
            extra_tokens = len(query_tokens - title_tokens)
            score -= extra_tokens * 8
            return max(0, score), "Candidate name is contained in query"

        if query_tokens and title_tokens:
            missing_query_tokens = query_tokens - title_tokens
            if missing_query_tokens:
                overlap_ratio = (
                    len(query_tokens & title_tokens)
                    / len(query_tokens)
                )
                if overlap_ratio < 0.75:
                    score = min(score, token_score, 68)
                else:
                    score = min(score, 82)
                return max(0, score), "Missing important query terms"

        return max(0, score), "Fuzzy name match"

    def _score_candidate(self, query, item):
        title = item.get("title", "")
        snippet = self._strip_html(item.get("snippet", ""))
        text = f"{title} {snippet}"
        score, reason = self._score_name(query, title)

        entity_type = self._detect_entity_type(text)
        is_non_entity = self._is_non_entity(text)

        if entity_type != "Unknown":
            score += 4

        lowered = text.lower()
        if "may refer to" in lowered or "disambiguation" in lowered:
            score -= 30
            reason = f"{reason}; disambiguation penalty"

        if is_non_entity:
            score -= 35
            reason = f"{reason}; rejected non-entity signal"

        confidence = int(max(0, min(score, 100)))

        if confidence >= self.AUTO_ACCEPT_SCORE:
            status = "auto_accept"
        elif confidence >= self.CONDITIONAL_ACCEPT_SCORE:
            status = "conditional_accept"
        elif confidence >= self.REVIEW_SCORE:
            status = "needs_review"
        else:
            status = "low_confidence"

        return {
            "candidate_id": f"wikipedia:{title}",
            "name": title,
            "wikipedia_title": title,
            "entity_type": entity_type,
            "description": snippet,
            "confidence": confidence,
            "match_status": status,
            "match_reason": reason,
            "is_exact_match": (
                normalize_company_name(query)
                == normalize_company_name(title)
            ),
            "is_entity": entity_type != "Unknown" and not is_non_entity,
            "source": ["Wikipedia"]
        }

    def _score_yahoo_candidate(self, query, quote):
        name = (
            quote.get("longname")
            or quote.get("shortname")
            or quote.get("symbol")
            or ""
        )
        score, reason = self._score_name(query, name)

        exchange = (
            quote.get("exchDisp")
            or quote.get("exchange")
        )

        if quote.get("quoteType") == "EQUITY":
            score += 5

        if exchange in ["NYSE", "NASDAQ", "NSE", "Bombay"]:
            score += 3

        confidence = int(max(0, min(score, 100)))

        if confidence >= self.AUTO_ACCEPT_SCORE:
            status = "auto_accept"
        elif confidence >= self.CONDITIONAL_ACCEPT_SCORE:
            status = "conditional_accept"
        elif confidence >= self.REVIEW_SCORE:
            status = "needs_review"
        else:
            status = "low_confidence"

        return {
            "candidate_id": f"yahoo:{quote.get('symbol')}",
            "name": name,
            "wikipedia_title": None,
            "entity_type": "Company",
            "description": (
                f"Public market listing {quote.get('symbol')} "
                f"on {exchange}"
            ),
            "ticker": quote.get("symbol"),
            "exchange": exchange,
            "confidence": confidence,
            "match_status": status,
            "match_reason": reason,
            "is_exact_match": (
                normalize_company_name(query)
                == normalize_company_name(name)
            ),
            "is_entity": True,
            "source": ["Yahoo Finance"]
        }

    def _score_wikidata_candidate(self, query, item):
        name = item.get("label", "")
        description = item.get("description", "")
        text = f"{name} {description}"
        score, reason = self._score_name(query, name)
        entity_type = self._detect_entity_type(text)
        is_non_entity = self._is_non_entity(text)

        if entity_type != "Unknown":
            score += 6

        confidence = int(max(0, min(score, 100)))

        if confidence >= self.AUTO_ACCEPT_SCORE:
            status = "auto_accept"
        elif confidence >= self.CONDITIONAL_ACCEPT_SCORE:
            status = "conditional_accept"
        elif confidence >= self.REVIEW_SCORE:
            status = "needs_review"
        else:
            status = "low_confidence"

        return {
            "candidate_id": f"wikidata:{item.get('id')}",
            "name": name,
            "wikipedia_title": None,
            "wikidata_id": item.get("id"),
            "entity_type": entity_type,
            "description": description,
            "confidence": confidence,
            "match_status": status,
            "match_reason": reason,
            "is_exact_match": (
                normalize_company_name(query)
                == normalize_company_name(name)
            ),
            "is_entity": entity_type != "Unknown" and not is_non_entity,
            "source": ["Wikidata"]
        }

    def _map_external_entity_type(self, raw_type, text=""):
        lowered_type = (raw_type or "").lower()
        lowered_text = (text or "").lower()

        if lowered_type in ["education"] or "university" in lowered_text:
            return "University"
        if lowered_type in ["healthcare"] or "hospital" in lowered_text:
            return "Hospital"
        if lowered_type in ["government"]:
            return "Government Agency"
        if lowered_type in ["nonprofit", "non-profit"]:
            return "Non-profit"
        if lowered_type in ["company"]:
            return "Company"
        if "research" in lowered_text or "institute" in lowered_text:
            return "Research Institute"
        return "Organization"

    def _score_openalex_candidate(self, query, item):
        name = item.get("display_name", "")
        score, reason = self._score_name(query, name)
        raw_type = item.get("type")
        country = (item.get("country_code") or "").upper() or None
        homepage = item.get("homepage_url")
        works_count = item.get("works_count")
        entity_type = self._map_external_entity_type(
            raw_type,
            name
        )

        if entity_type in [
            "University",
            "Hospital",
            "Research Institute",
            "Organization"
        ]:
            score += 7

        if item.get("ror"):
            score += 3

        confidence = int(max(0, min(score, 100)))

        return {
            "candidate_id": f"openalex:{item.get('id')}",
            "name": name,
            "wikipedia_title": None,
            "entity_type": entity_type,
            "description": (
                f"{entity_type} from OpenAlex"
                + (f"; works_count={works_count}" if works_count else "")
            ),
            "website": homepage,
            "country": country,
            "openalex_id": item.get("id"),
            "ror_id": item.get("ror"),
            "confidence": confidence,
            "match_status": (
                "auto_accept"
                if confidence >= self.AUTO_ACCEPT_SCORE
                else "needs_review"
                if confidence >= self.REVIEW_SCORE
                else "low_confidence"
            ),
            "match_reason": f"{reason}; OpenAlex institution match",
            "is_exact_match": (
                normalize_company_name(query)
                == normalize_company_name(name)
            ),
            "is_entity": bool(name),
            "source": ["OpenAlex"]
        }

    def _score_ror_candidate(self, query, item):
        names = item.get("names") or []
        display_name = next(
            (
                name_item.get("value")
                for name_item in names
                if "ror_display" in (name_item.get("types") or [])
            ),
            None
        )
        label_name = next(
            (
                name_item.get("value")
                for name_item in names
                if name_item.get("lang") == "en"
                and "label" in (name_item.get("types") or [])
            ),
            None
        )
        name = item.get("name") or display_name or label_name or ""
        score, reason = self._score_name(query, name)
        raw_types = item.get("types") or []
        raw_type = raw_types[0] if raw_types else None
        links = item.get("links") or []
        locations = item.get("locations") or []
        addresses = item.get("addresses") or []
        country = None
        website = None
        wikipedia_url = None
        wikidata_id = None

        for link in links:
            if isinstance(link, dict):
                if link.get("type") == "website" and not website:
                    website = link.get("value")
                if link.get("type") == "wikipedia" and not wikipedia_url:
                    wikipedia_url = link.get("value")
            elif isinstance(link, str) and not website:
                website = link

        if locations:
            country = (
                locations[0]
                .get("geonames_details", {})
                .get("country_name")
            )
        elif addresses:
            country = (
                addresses[0]
                .get("country_geonames_details", {})
                .get("name")
            )

        for external_id in item.get("external_ids") or []:
            if external_id.get("type") == "wikidata":
                wikidata_id = (
                    external_id.get("preferred")
                    or next(iter(external_id.get("all") or []), None)
                )
                break

        entity_type = self._map_external_entity_type(
            raw_type,
            f"{name} {' '.join(raw_types)}"
        )

        if entity_type in [
            "University",
            "Hospital",
            "Research Institute",
            "Organization"
        ]:
            score += 8

        confidence = int(max(0, min(score, 100)))

        return {
            "candidate_id": f"ror:{item.get('id')}",
            "name": name,
            "wikipedia_title": None,
            "entity_type": entity_type,
            "description": (
                f"{entity_type} from ROR"
                + (f"; types={', '.join(raw_types)}" if raw_types else "")
            ),
            "website": website,
            "country": country,
            "ror_id": item.get("id"),
            "wikidata_id": wikidata_id,
            "wikipedia_url": wikipedia_url,
            "founded_year": item.get("established"),
            "confidence": confidence,
            "match_status": (
                "auto_accept"
                if confidence >= self.AUTO_ACCEPT_SCORE
                else "needs_review"
                if confidence >= self.REVIEW_SCORE
                else "low_confidence"
            ),
            "match_reason": f"{reason}; ROR organization match",
            "is_exact_match": (
                normalize_company_name(query)
                == normalize_company_name(name)
            ),
            "is_entity": bool(name),
            "source": ["ROR"]
        }

    def _score_crossref_funder_candidate(self, query, item):
        name = item.get("name", "")
        score, reason = self._score_name(query, name)
        entity_type = self._map_external_entity_type(
            None,
            name
        )

        if item.get("id"):
            score += 2

        confidence = int(max(0, min(score, 100)))

        return {
            "candidate_id": f"crossref:{item.get('id')}",
            "name": name,
            "wikipedia_title": None,
            "entity_type": entity_type,
            "description": "Organization/funder from Crossref",
            "website": None,
            "country": None,
            "crossref_id": item.get("id"),
            "confidence": confidence,
            "match_status": (
                "auto_accept"
                if confidence >= self.AUTO_ACCEPT_SCORE
                else "needs_review"
                if confidence >= self.REVIEW_SCORE
                else "low_confidence"
            ),
            "match_reason": f"{reason}; Crossref funder match",
            "is_exact_match": (
                normalize_company_name(query)
                == normalize_company_name(name)
            ),
            "is_entity": bool(name),
            "source": ["Crossref"]
        }

    def _ambiguity_key(self, candidate):
        name = normalize_company_name(candidate.get("name", ""))
        tokens = [
            token
            for token in name.split()
            if token not in ["n", "r", "plc", "ag", "inc"]
        ]
        return " ".join(tokens)

    @staticmethod
    def _compact_name(value):
        return normalize_company_name(value).replace(" ", "")

    def _canonical_retry_candidate(self, query, candidate):
        canonical_name = (candidate or {}).get("name", "").strip()
        if (
            not canonical_name
            or not candidate.get("is_entity")
            or self._compact_name(query) != self._compact_name(canonical_name)
            or normalize_company_name(query)
            == normalize_company_name(canonical_name)
        ):
            return None, []

        retried = self.search_candidates(canonical_name)
        matching = [
            item
            for item in retried
            if item.get("is_entity")
            and self._compact_name(item.get("name", ""))
            == self._compact_name(canonical_name)
        ]
        if not matching:
            return None, retried

        matching.sort(
            key=lambda item: (
                bool(item.get("wikipedia_title")),
                item.get("confidence", 0)
            ),
            reverse=True
        )
        confirmed = matching[0]
        confirmed["match_reason"] = (
            "Canonical name retry confirmed equivalent entity name"
        )
        confirmed["canonical_retry_from"] = query
        return confirmed, retried

    def _query_variants(self, query):
        variants = [query]
        legal_holder_cleaned = re.sub(
            r"^\s*The\s+Trustees\s+of\s+",
            "",
            query,
            flags=re.IGNORECASE
        ).strip()
        legal_holder_cleaned = re.sub(
            r"^\s*Trustees\s+of\s+",
            "",
            legal_holder_cleaned,
            flags=re.IGNORECASE
        ).strip()
        if (
            legal_holder_cleaned
            and legal_holder_cleaned.lower() != query.lower()
        ):
            variants.append(legal_holder_cleaned)

        cleaned = re.sub(
            r"\bIP Holdings\b",
            "",
            query,
            flags=re.IGNORECASE
        ).strip()
        cleaned = re.sub(
            r"\bHoldings\b",
            "",
            cleaned,
            flags=re.IGNORECASE
        ).strip()
        cleaned = re.sub(
            r"\b(Inc|Corporation|Corp|Limited|Ltd|AG|PLC)\b\.?",
            "",
            cleaned,
            flags=re.IGNORECASE
        ).strip()
        cleaned = re.sub(r"\s+", " ", cleaned)

        if cleaned and cleaned.lower() != query.lower():
            variants.append(cleaned)

        first_token = query.split()[0] if query.split() else ""
        if len(first_token) > 4:
            variants.append(first_token)

        deduped = []
        seen = set()
        for variant in variants:
            key = variant.lower()
            if key not in seen:
                seen.add(key)
                deduped.append(variant)

        return deduped

    def _should_search_org_apis(self, query, scored_candidates):
        lowered = (query or "").lower()
        org_hints = [
            "hospital",
            "clinic",
            "medical center",
            "health system",
            "university",
            "college",
            "school",
            "institute",
            "laboratory",
            "foundation",
            "research"
        ]

        if any(hint in lowered for hint in org_hints):
            return True

        best_confidence = max(
            [
                candidate.get("confidence", 0)
                for candidate in scored_candidates
                if candidate.get("is_entity")
            ],
            default=0
        )

        return best_confidence < self.REVIEW_SCORE

    def _known_candidates(self, query):
        normalized_query = normalize_company_name(query)
        candidates = []

        for key, data in self.KNOWN_ENTITIES.items():
            score = fuzz.token_set_ratio(
                normalized_query,
                key
            )

            if score < 88:
                continue

            candidates.append({
                "candidate_id": f"known:{key}",
                "name": data["name"],
                "wikipedia_title": None,
                "entity_type": data["entity_type"],
                "description": data["description"],
                "website": data["website"],
                "country": data["country"],
                "confidence": int(min(score, 100)),
                "match_status": "auto_accept",
                "match_reason": "Known company exact/alias match",
                "is_exact_match": score >= 95,
                "is_entity": True,
                "source": ["Known Entity"]
            })

        return candidates

    def _dedupe_and_rank(self, scored_candidates, limit=8):
        candidates = [
            candidate
            for candidate in scored_candidates
            if candidate["is_entity"]
        ]

        deduped = {}
        for candidate in candidates:
            candidate = {
                **candidate,
                "source": list(candidate.get("source") or [])
            }
            key = normalize_company_name(candidate["name"])
            existing = deduped.get(key)
            if (
                not existing
                or candidate["confidence"] > existing["confidence"]
            ):
                deduped[key] = candidate
            elif existing:
                existing_sources = existing.get("source", [])
                for source in candidate.get("source", []):
                    if source not in existing_sources:
                        existing_sources.append(source)
                existing["source"] = existing_sources
                for key_name in [
                    "website",
                    "country",
                    "wikidata_id",
                    "openalex_id",
                    "ror_id",
                    "crossref_id"
                ]:
                    if not existing.get(key_name) and candidate.get(key_name):
                        existing[key_name] = candidate.get(key_name)

        candidates = list(deduped.values())

        def rank_key(item):
            sources = item.get("source") or []
            return (
                item.get("confidence", 0),
                bool(item.get("wikipedia_title")),
                bool(item.get("wikidata_id")),
                len(sources),
                bool(item.get("website")),
                "Yahoo Finance" not in sources or len(sources) > 1
            )

        candidates.sort(
            key=rank_key,
            reverse=True
        )

        return candidates[:limit]

    def collect_source_evidence(self, query, limit=8):
        evidence = {
            "known_entity": self._known_candidates(query),
            "wikipedia": [],
            "yahoo": [],
            "wikidata": [],
            "openalex": [],
            "ror": [],
            "crossref": []
        }

        variants = self._query_variants(query)
        for variant in variants:
            evidence["wikipedia"].extend(
                self._score_candidate(query, item)
                for item in self._search_wikipedia(variant, limit=limit)
            )
            evidence["yahoo"].extend(
                self._score_yahoo_candidate(query, quote)
                for quote in self._search_yahoo(variant, limit=limit)
            )
            evidence["wikidata"].extend(
                self._score_wikidata_candidate(query, item)
                for item in self._search_wikidata(variant, limit=limit)
            )
            evidence["openalex"].extend(
                self._score_openalex_candidate(query, item)
                for item in self.academic_orgs.search_openalex(
                    variant,
                    limit=limit
                )
            )
            evidence["ror"].extend(
                self._score_ror_candidate(query, item)
                for item in self.academic_orgs.search_ror(
                    variant,
                    limit=limit
                )
            )
            evidence["crossref"].extend(
                self._score_crossref_funder_candidate(query, item)
                for item in self.academic_orgs.search_crossref_funders(
                    variant,
                    limit=limit
                )
            )

        scored_candidates = []
        source_counts = {}
        for source, candidates in evidence.items():
            source_counts[source] = len(candidates)
            scored_candidates.extend(candidates)

        merged_candidates = self._dedupe_and_rank(
            scored_candidates,
            limit=limit
        )

        return {
            "query": query,
            "query_variants": variants,
            "source_counts": source_counts,
            "sources": {
                source: self._dedupe_and_rank(candidates, limit=limit)
                for source, candidates in evidence.items()
            },
            "merged_candidates": merged_candidates
        }

    def search_candidates(self, query, limit=8):
        return self.collect_source_evidence(
            query,
            limit=limit
        )["merged_candidates"]

    def choose_for_excel(self, query):
        candidates = self.search_candidates(query)

        if not candidates:
            return {
                "decision": "not_found",
                "confidence": 0,
                "candidate": None,
                "candidates": []
            }

        best = candidates[0]
        canonical_retry = False
        confirmed, retried = self._canonical_retry_candidate(query, best)
        if confirmed:
            best = confirmed
            canonical_retry = True
            candidates = [
                best,
                *[
                    item
                    for item in retried
                    if item.get("candidate_id") != best.get("candidate_id")
                ]
            ]

        second = candidates[1] if len(candidates) > 1 else None
        lead = (
            best["confidence"] - second["confidence"]
            if second
            else best["confidence"]
        )
        same_entity_duplicate = (
            second
            and self._ambiguity_key(best)
            == self._ambiguity_key(second)
        )
        sources = best.get("source") or []
        is_yahoo_only = sources == ["Yahoo Finance"]
        second_sources = (second or {}).get("source") or []
        best_is_rich_registry = (
            any(source in sources for source in ["ROR", "OpenAlex"])
            and (
                best.get("website")
                or best.get("founded_year")
                or best.get("wikidata_id")
            )
        )
        second_is_yahoo_only = second_sources == ["Yahoo Finance"]

        if canonical_retry:
            decision = "auto_accept"
            selection_rule = "canonical_name_retry"
        elif best.get("is_exact_match"):
            decision = "auto_accept"
            selection_rule = "exact_match"
        elif (
            not is_yahoo_only
            and
            best["confidence"] >= self.FIRST_CANDIDATE_SCORE
            and best.get("entity_type") != "Unknown"
            and (
                lead >= self.MIN_FIRST_CANDIDATE_LEAD
                or same_entity_duplicate
            )
        ):
            decision = "auto_accept"
            selection_rule = "first_candidate_strong"
        elif (
            best_is_rich_registry
            and best["confidence"] >= self.AUTO_ACCEPT_SCORE
            and (
                second is None
                or second_is_yahoo_only
                or lead >= self.MIN_FIRST_CANDIDATE_LEAD
            )
        ):
            decision = "auto_accept"
            selection_rule = "rich_registry_over_sparse_listing"
        elif (
            is_yahoo_only
            and best["confidence"] >= 98
            and lead >= max(self.MIN_FIRST_CANDIDATE_LEAD, 20)
            and best.get("entity_type") != "Unknown"
        ):
            decision = "auto_accept"
            selection_rule = "yahoo_exact_public_listing"
        elif (
            best["confidence"] >= self.CONDITIONAL_ACCEPT_SCORE
            and best.get("entity_type") != "Unknown"
        ):
            decision = "needs_review"
            selection_rule = "needs_review_ambiguous"
        elif best["confidence"] >= self.REVIEW_SCORE:
            decision = "needs_review"
            selection_rule = "needs_review_low_confidence"
        else:
            decision = "not_found"
            selection_rule = "not_found"

        return {
            "decision": decision,
            "confidence": best["confidence"],
            "selection_rule": selection_rule,
            "lead_over_next": lead,
            "candidate": best if decision == "auto_accept" else None,
            "candidates": candidates[:3]
        }
