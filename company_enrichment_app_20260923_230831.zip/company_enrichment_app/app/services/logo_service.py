import os
import re
import uuid
from urllib.parse import quote, urlparse

import requests

from app.core.config import LOGO_DEV_TOKEN


class LogoService:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "CompanyEnrichmentBot/1.0"
        })

    def _clean_name(self, value):
        cleaned = re.sub(r"\([^)]*\)", " ", value or "")
        cleaned = re.sub(
            r"\b(incorporated|inc|corporation|corp|company|co|limited|ltd|plc|ag|llc|pvt|private)\b\.?",
            " ",
            cleaned,
            flags=re.IGNORECASE
        )
        cleaned = re.sub(r"[^A-Za-z0-9]+", " ", cleaned)
        return re.sub(r"\s+", " ", cleaned).strip()

    def _domain_from_url(self, value):
        if not value:
            return None

        url = str(value).strip()
        if not url:
            return None

        if not re.match(r"^https?://", url, flags=re.IGNORECASE):
            url = f"https://{url}"

        try:
            host = urlparse(url).hostname or ""
        except Exception:
            return None

        host = host.lower()
        if host.startswith("www."):
            host = host[4:]

        return host or None

    def _domain_candidates(self, result):
        domains = []
        for key in ["official_website", "website", "yahoo_website"]:
            domain = self._domain_from_url(result.get(key))
            if domain and domain not in domains:
                domains.append(domain)

        if not domains:
            name = (
                result.get("company_name")
                or result.get("input_company_name")
                or ""
            )
            cleaned = self._clean_name(name)
            if cleaned:
                domain = cleaned.lower().replace(" ", "") + ".com"
                domains.append(domain)

        return domains

    def _wikidata_logo_filename(self, wikidata_service, wikidata_id):
        if not wikidata_id:
            return None

        entity = wikidata_service.get_entity(wikidata_id)
        if not entity:
            return None

        value = wikidata_service.get_property(entity, "P154")
        if isinstance(value, str):
            return value

        return None

    def _commons_url(self, filename):
        return (
            "https://commons.wikimedia.org/wiki/Special:Redirect/file/"
            f"{quote(filename)}?width=256"
        )

    def _logo_dev_url(self, domain):
        if not domain or not LOGO_DEV_TOKEN:
            return None

        return (
            f"https://img.logo.dev/{quote(domain)}"
            f"?token={quote(LOGO_DEV_TOKEN)}"
            "&size=256&format=png&retina=true&fallback=404"
        )

    def _download_logo(self, logo_url, output_dir):
        if not logo_url:
            return None, None

        try:
            response = self.session.get(
                logo_url,
                timeout=(3, 12)
            )
            if response.status_code != 200:
                return None, f"http_{response.status_code}"

            content_type = response.headers.get("content-type", "").lower()
            if not content_type.startswith("image/"):
                return None, "not_image"

            extension = "png"
            if "svg" in content_type:
                extension = "svg"
            elif "jpeg" in content_type or "jpg" in content_type:
                extension = "jpg"
            elif "webp" in content_type:
                extension = "webp"

            os.makedirs(output_dir, exist_ok=True)
            filename = f"{uuid.uuid4().hex}.{extension}"
            path = os.path.join(output_dir, filename)
            with open(path, "wb") as file:
                file.write(response.content)

            return path, None

        except Exception as e:
            return None, str(e)

    def enrich(self, result, wikidata_service, output_dir=None):
        result = result or {}
        output_dir = output_dir or os.path.join(os.getcwd(), "outputs", "logos")

        for domain in self._domain_candidates(result):
            logo_url = self._logo_dev_url(domain)
            local_path, error = self._download_logo(logo_url, output_dir)
            if local_path:
                filename = os.path.basename(local_path)
                return {
                    "logo_url": logo_url,
                    "logo_source": "Logo.dev",
                    "logo_domain": domain,
                    "logo_local_path": local_path,
                    "logo_file_url": f"/logo-file/{filename}",
                    "logo_status": "downloaded"
                }

        logo_filename = self._wikidata_logo_filename(
            wikidata_service,
            result.get("wikidata_id")
        )
        if logo_filename:
            logo_url = self._commons_url(logo_filename)
            local_path, error = self._download_logo(logo_url, output_dir)
            if local_path:
                filename = os.path.basename(local_path)
                return {
                    "logo_url": logo_url,
                    "logo_source": "Wikimedia Commons",
                    "logo_domain": None,
                    "logo_local_path": local_path,
                    "logo_file_url": f"/logo-file/{filename}",
                    "logo_status": "downloaded"
                }
            return {
                "logo_url": logo_url,
                "logo_source": "Wikimedia Commons",
                "logo_domain": None,
                "logo_local_path": None,
                "logo_file_url": None,
                "logo_status": "url_only",
                "logo_error": error
            }

        return {
            "logo_url": None,
            "logo_source": None,
            "logo_domain": None,
            "logo_local_path": None,
            "logo_file_url": None,
            "logo_status": "not_found"
        }
