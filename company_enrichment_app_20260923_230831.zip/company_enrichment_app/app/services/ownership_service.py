from datetime import datetime


class OwnershipService:

    def __init__(self):
        pass

    # ==========================================
    # STARTUP FLAG
    # ==========================================

    def calculate_startup_flag(
        self,
        founded_year
    ):

        if not founded_year:
            return False

        current_year = datetime.now().year

        age = current_year - founded_year

        return age <= 10

    # ==========================================
    # OWNERSHIP STATUS
    # ==========================================

    def determine_status(
        self,
        wiki_data
    ):

        summary = (
            str(
                wiki_data.get(
                    "summary"
                )
                or ""
            ).lower()
        )

        keywords = [
            "defunct",
            "dissolved",
            "liquidated",
            "ceased operations",
            "former company"
        ]

        if any(
            keyword in summary
            for keyword in keywords
        ):
            return "Defunct"

        return "Active"

    # ==========================================
    # OWNERSHIP TYPE
    # ==========================================

    def determine_type(
        self,
        wiki_data,
        wikidata_data,
        sec_data
    ):

        # SEC = strongest source

        if sec_data.get("ticker"):

            return "Public Company"

        # Parent company exists

        if (
            wiki_data.get("parent_company")
            or wikidata_data.get("parent_company")
        ):

            return "Subsidiary"

        company_type = str(
            wiki_data.get(
                "ownership_type",
                ""
            )
        ).lower()

        if "joint venture" in company_type:

            return "Joint Venture"

        if "private" in company_type:

            return "Private Company"

        # Startup fallback

        founded_year = (
            wiki_data.get("founded_year")
            or wikidata_data.get(
                "founded_year"
            )
        )

        if self.calculate_startup_flag(
            founded_year
        ):
            return "Startup"

        return "Unknown"

    # ==========================================
    # ULTIMATE PARENT
    # ==========================================

    def determine_parent(
        self,
        wiki_data,
        wikidata_data
    ):

        parent = (
            wiki_data.get(
                "parent_company"
            )
            or wikidata_data.get(
                "parent_company"
            )
        )

        return parent

    # ==========================================
    # MAIN FUNCTION
    # ==========================================

    def enrich(
        self,
        wiki_data,
        wikidata_data,
        sec_data
    ):

        founded_year = (
            wiki_data.get(
                "founded_year"
            )
            or wikidata_data.get(
                "founded_year"
            )
        )

        return {

            "ownership_type":
                self.determine_type(
                    wiki_data,
                    wikidata_data,
                    sec_data
                ),

            "ownership_status":
                self.determine_status(
                    wiki_data
                ),

            "parent_company":
                self.determine_parent(
                    wiki_data,
                    wikidata_data
                ),

            "ultimate_parent":
                self.determine_parent(
                    wiki_data,
                    wikidata_data
                ),

            "startup_flag":
                self.calculate_startup_flag(
                    founded_year
                )
        }
