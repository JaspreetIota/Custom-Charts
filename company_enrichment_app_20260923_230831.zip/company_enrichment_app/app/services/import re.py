import re
from playwright.sync_api import Playwright, sync_playwright, expect


def run(playwright: Playwright) -> None:
    browser = playwright.chromium.launch(headless=False)
    context = browser.new_context()
    page = context.new_page()
    page.goto("https://www.noetherip.com/login")
    page.get_by_role("textbox", name="Email").click()
    page.get_by_role("textbox", name="Email").fill("noether.sysadmin@iotaanalytics.com")
    page.get_by_role("textbox", name="Password").click()
    page.get_by_role("textbox", name="Password").fill("Target@2021?26!!")
    page.get_by_role("button", name="Login").click()
    page.locator("#mat-select-value-1").click()
    page.get_by_text("Diabetes (C)").click()
    page.get_by_role("button", name="Submit").click()
    page.get_by_text("Skip").click()
    page.get_by_role("link", name="Data Update").click()
    page.get_by_role("button", name="Add / Update an Organisation").click()
    page.get_by_placeholder("Search Company").click()
    page.get_by_text("Skip").click()
    page.get_by_placeholder("Search Company").click()
    page.get_by_placeholder("Search Company").fill("abbott")
    page.get_by_placeholder("Search Company").press("Enter")
    page.get_by_role("option", name="Abbott Verified").locator("app-company-verified-badge").click()
    page.get_by_placeholder("Search Application Areas").click()
    page.get_by_role("option", name="Internet of Life").get_by_label("", exact=True).check()
    page.get_by_role("button", name="Save").click()
    page.get_by_placeholder("Search Company").dblclick()
    page.get_by_placeholder("Search Company").fill("medtronic")
    page.get_by_text("Medtronic", exact=True).click()
    page.get_by_placeholder("Search Application Areas").click()
    page.get_by_role("option", name="Sample Processing").get_by_label("", exact=True).check()
    page.get_by_role("button", name="Save").click()

    # ---------------------
    context.close()
    browser.close()


with sync_playwright() as playwright:
    run(playwright)
