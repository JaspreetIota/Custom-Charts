import requests


class WikidataService:

    def __init__(self):

        self.session = requests.Session()

        self.session.headers.update({
            "User-Agent": "CompanyEnrichmentBot/1.0"
        })

    # ==================================================
    # GET WIKIDATA ID FROM WIKIPEDIA PAGE
    # ==================================================

    def get_wikidata_id_from_wikipedia(
        self,
        wikipedia_title
    ):

        try:

            url = "https://en.wikipedia.org/w/api.php"

            params = {
                "action": "query",
                "titles": wikipedia_title,
                "prop": "pageprops",
                "format": "json"
            }

            response = self.session.get(
                url,
                params=params,
                timeout=30
            )

            response.raise_for_status()

            pages = (
                response.json()
                .get("query", {})
                .get("pages", {})
            )

            for page in pages.values():

                pageprops = page.get(
                    "pageprops",
                    {}
                )

                wikidata_id = pageprops.get(
                    "wikibase_item"
                )

                if wikidata_id:
                    return wikidata_id

            return None

        except Exception as e:

            print(
                f"Wikidata ID Error: {e}"
            )

            return None

    # ==================================================
    # GET ENTITY JSON
    # ==================================================

    def get_entity(
        self,
        entity_id
    ):

        try:

            url = (
                f"https://www.wikidata.org/wiki/"
                f"Special:EntityData/{entity_id}.json"
            )

            response = self.session.get(
                url,
                timeout=30
            )

            response.raise_for_status()

            data = response.json()

            return (
                data["entities"]
                .get(entity_id)
            )

        except Exception as e:

            print(
                f"Wikidata Entity Error: {e}"
            )

            return None

    # ==================================================
    # PROPERTY EXTRACTOR
    # ==================================================

    def get_property(
        self,
        entity,
        property_id
    ):

        try:

            claims = (
                entity["claims"]
                .get(property_id)
            )

            if not claims:
                return None

            claim = claims[0]

            mainsnak = claim["mainsnak"]

            datavalue = mainsnak.get(
                "datavalue"
            )

            if not datavalue:
                return None

            return datavalue["value"]

        except Exception:
            return None

    # ==================================================
    # RESOLVE Q-ID TO HUMAN NAME
    # ==================================================

    def resolve_entity_name(
        self,
        entity_id
    ):

        try:

            if not entity_id:
                return None

            entity = self.get_entity(
                entity_id
            )

            if not entity:
                return None

            return (
                entity
                .get("labels", {})
                .get("en", {})
                .get("value")
            )

        except Exception:
            return None

    # ==================================================
    # WEBSITE (P856)
    # ==================================================

    def get_website(
        self,
        entity
    ):

        return self.get_property(
            entity,
            "P856"
        )

    # ==================================================
    # COUNTRY (P17)
    # ==================================================

    def get_country(
        self,
        entity
    ):

        value = self.get_property(
            entity,
            "P17"
        )

        if isinstance(value, dict):

            return self.resolve_entity_name(
                value.get("id")
            )

        return None

    # ==================================================
    # HEADQUARTERS (P159)
    # ==================================================

    def get_headquarters(
        self,
        entity
    ):

        value = self.get_property(
            entity,
            "P159"
        )

        if isinstance(value, dict):

            return self.resolve_entity_name(
                value.get("id")
            )

        return None

    # ==================================================
    # PARENT COMPANY (P749)
    # ==================================================

    def get_parent_company(
        self,
        entity
    ):

        value = self.get_property(
            entity,
            "P749"
        )

        if isinstance(value, dict):

            return self.resolve_entity_name(
                value.get("id")
            )

        return None

    # ==================================================
    # FOUNDED YEAR (P571)
    # ==================================================

    def get_founded_year(
        self,
        entity
    ):

        value = self.get_property(
            entity,
            "P571"
        )

        try:

            return int(
                value["time"][1:5]
            )

        except Exception:
            return None

    # ==================================================
    # DESCRIPTION
    # ==================================================

    def get_description(
        self,
        entity
    ):

        try:

            return (
                entity
                .get("descriptions", {})
                .get("en", {})
                .get("value")
            )

        except Exception:
            return None

    # ==================================================
    # ENTITY TYPE DETECTION
    # ==================================================

    def detect_entity_type(
        self,
        description
    ):

        if not description:
            return "Unknown"

        text = description.lower()

        government_keywords = [
            "government",
            "federal",
            "national agency",
            "space agency",
            "aeronautics agency",
            "ministry"
        ]

        university_keywords = [
            "university",
            "college",
            "educational institution"
        ]

        research_keywords = [
            "research institute",
            "research center",
            "research organisation",
            "research organization",
            "laboratory",
            "physics laboratory",
            "scientific research"
        ]

        nonprofit_keywords = [
            "non-profit",
            "nonprofit",
            "charitable"
        ]

        company_keywords = [
            "company",
            "corporation",
            "business",
            "manufacturer",
            "enterprise",
            "multinational",
            "conglomerate"
        ]

        organization_keywords = [
            "organization",
            "organisation",
            "association",
            "foundation",
            "intergovernmental"
        ]

        if any(x in text for x in government_keywords):
            return "Government Agency"

        if any(x in text for x in university_keywords):
            return "University"

        if any(x in text for x in research_keywords):
            return "Research Institute"

        if any(x in text for x in nonprofit_keywords):
            return "Non-profit"

        if any(x in text for x in company_keywords):
            return "Company"

        if any(x in text for x in organization_keywords):
            return "Organization"

        return "Unknown"

    # ==================================================
    # MAIN ENRICHMENT
    # ==================================================

    def enrich_by_id(
        self,
        wikidata_id
    ):

        if not wikidata_id:

            return {
                "wikidata_id": None
            }

        entity = self.get_entity(
            wikidata_id
        )

        if not entity:

            return {
                "wikidata_id": wikidata_id
            }

        description = self.get_description(
            entity
        )

        entity_type = self.detect_entity_type(
            description
        )

        parent_company = self.get_parent_company(
            entity
        )

        ownership_type = "Unknown"

        if (
            entity_type == "Company"
            and parent_company
        ):
            ownership_type = "Subsidiary"

        elif entity_type == "Company":
            ownership_type = "Company"

        elif entity_type == "Government Agency":
            ownership_type = "Government Agency"

        elif entity_type == "University":
            ownership_type = "Educational Institution"

        elif entity_type == "Research Institute":
            ownership_type = "Research Institute"

        elif entity_type == "Non-profit":
            ownership_type = "Non-profit"

        elif entity_type == "Organization":
            ownership_type = "Organization"

        return {

            "wikidata_id":
                wikidata_id,

            "entity_type":
                entity_type,

            "country":
                self.get_country(
                    entity
                ),

            "official_website":
                self.get_website(
                    entity
                ),

            "headquarters":
                self.get_headquarters(
                    entity
                ),

            "founded_year":
                self.get_founded_year(
                    entity
                ),

            "parent_company":
                parent_company,

            "ownership_type":
                ownership_type,

            "wikidata_description":
                description,

            "source":
                "Wikidata"
        }

    def enrich(
        self,
        wikipedia_title
    ):

        wikidata_id = (
            self.get_wikidata_id_from_wikipedia(
                wikipedia_title
            )
        )

        if not wikidata_id:

            return {
                "wikidata_id": None
            }

        return self.enrich_by_id(
            wikidata_id
        )
