def build_fast_context(
    wiki_data,
    wikidata_data,
    sec_data,
    yahoo_data=None,
    news_data=None,
    website_data=None
):
    yahoo_data = yahoo_data or {}
    news_data = news_data or {}
    website_data = website_data or {}
    articles = news_data.get("articles", [])
    article_titles = [
        article.get("title")
        for article in articles[:5]
        if article.get("title")
    ]

    return f"""
Company Name: {wiki_data.get("company_name")}

Description: {wiki_data.get("description")}

Summary: {str(wiki_data.get("summary", ""))[:800]}

Industry: {wiki_data.get("industry")}

Headquarters: {wiki_data.get("headquarters")}

Ownership: {sec_data.get("ownership_type")}

Ticker: {sec_data.get("ticker") or yahoo_data.get("ticker")}

Exchange: {sec_data.get("exchange") or yahoo_data.get("exchange")}

Wikidata: {wikidata_data.get("wikidata_description")}

Yahoo Legal Name: {yahoo_data.get("legal_name")}

Yahoo Sector: {yahoo_data.get("yahoo_sector")}

Yahoo Industry: {yahoo_data.get("yahoo_industry")}

Yahoo Market Cap: {yahoo_data.get("yahoo_market_cap")}

Yahoo Currency: {yahoo_data.get("yahoo_currency")}

Yahoo Total Revenue: {yahoo_data.get("yahoo_total_revenue")}

Yahoo Employees: {yahoo_data.get("yahoo_employees")}

Website Content: {str(website_data.get("website_content", ""))[:1200]}

Recent News Headlines: {article_titles}
"""
