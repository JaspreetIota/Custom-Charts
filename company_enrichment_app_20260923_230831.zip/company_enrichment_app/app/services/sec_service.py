import requests
from rapidfuzz import fuzz

from app.utils.company_name import normalize_company_name


class SECService:
    _company_cache = None

    def __init__(self):

        self.session = requests.Session()

        self.session.headers.update({
            "User-Agent": "CompanyEnrichmentBot/1.0 admin@example.com"
        })

        self.company_tickers_url = (
            "https://www.sec.gov/files/company_tickers.json"
        )

    # ==================================================
    # LOAD SEC COMPANY LIST
    # ==================================================

    def load_companies(self):

        try:
            if SECService._company_cache is not None:
                return SECService._company_cache

            response = self.session.get(
                self.company_tickers_url,
                timeout=(3, 15)
            )

            response.raise_for_status()

            SECService._company_cache = response.json()
            return SECService._company_cache

        except Exception as e:

            print(
                f"SEC Load Error: {e}"
            )

            return {}

    # ==================================================
    # FIND COMPANY
    # ==================================================

    def find_company(
        self,
        company_name
    ):
        companies = self.load_companies()
        if not companies:
            return None
        company_name_lower = normalize_company_name(company_name)
        
        # Exact Match
        for record in companies.values():
            title = (
                normalize_company_name(
                    record.get("title", "")
                )
            )
            
            if title == company_name_lower:
                return record
        # Fuzzy Match
        best_match = None
        best_score = 0
        
        for record in companies.values():
            title = (
                normalize_company_name(
                    record.get("title", "")
                )
            )
            
            score = fuzz.token_set_ratio(
                company_name_lower,
                title
            ) / 100
            
            if score > best_score:
                best_score = score
                best_match = record
        
        # Require strong confidence
        if best_score >= 0.85:
            return best_match
        return None

    # ==================================================
    # ENRICH
    # ==================================================

    def enrich(
        self,
        company_name
    ):

        company = self.find_company(
            company_name
        )

        if not company:

            return {
                "ticker": None,
                "exchange": None,
                "ownership_type": None,
                "cik": None,
                "legal_name": None,
                "source": "SEC"
            }

        cik = str(
            company.get("cik_str")
        ).zfill(10)

        ticker = company.get(
            "ticker"
        )

        legal_name = company.get(
            "title"
        )

        return {

            "ticker":
                ticker,

            "exchange":
                "NASDAQ/NYSE (SEC Listed)",

            "ownership_type":
                "Public Company",

            "cik":
                cik,

            "legal_name":
                legal_name,

            "sec_url":
                (
                    "https://www.sec.gov/"
                    "edgar/browse/"
                    f"?CIK={cik}"
                ),

            "source":
                "SEC EDGAR"
        }
