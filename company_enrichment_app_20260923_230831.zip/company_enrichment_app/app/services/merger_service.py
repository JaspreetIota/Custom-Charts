from datetime import datetime

from app.core.config import (
    QWEN_ENABLED,
    QWEN_ENTITY_CLASSIFICATION,
    QWEN_GENERAL_INSIGHTS
)
from app.services.context_builder import build_fast_context
from app.services.qwen_service import QwenService


class MergerService:

    def __init__(self):
        self.qwen = QwenService()

    # ==================================================
    # MAIN PIPELINE
    # ==================================================

    def enrich(
        self,
        wiki_data,
        wikidata_data,
        sec_data,
        ownership_data,
        website_data,
        taxonomy_list,
        yahoo_data=None,
        news_data=None
    ):
        yahoo_data = yahoo_data or {}
        news_data = news_data or {}

        # --------------------------
        # STEP 1: FAST CONTEXT
        # --------------------------

        context = build_fast_context(
            wiki_data,
            wikidata_data,
            sec_data,
            yahoo_data=yahoo_data,
            news_data=news_data,
            website_data=website_data
        )

        # --------------------------
        # STEP 2: MERGE
        # --------------------------

        result = {}

        # Wikipedia base
        result.update(wiki_data)

        # Fill missing values from Wikidata
        for key, value in wikidata_data.items():

            if (
                key not in result
                or result.get(key) in [None, "", [], {}]
            ):
                result[key] = value

        # Fill missing values from SEC
        for key, value in sec_data.items():

            if (
                key not in result
                or result.get(key) in [None, "", [], {}]
            ):
                result[key] = value

        # Fill missing values from Yahoo Finance for global markets.
        for key, value in yahoo_data.items():

            if (
                key not in result
                or result.get(key) in [None, "", [], {}]
            ):
                result[key] = value

        yahoo_fill_map = {
            "industry": "yahoo_industry",
            "employees": "yahoo_employees",
            "website": "yahoo_website",
            "revenue": "yahoo_total_revenue",
            "market_cap": "yahoo_market_cap",
            "currency": "yahoo_currency",
            "share_price": "yahoo_regular_market_price",
            "previous_close": "yahoo_previous_close",
            "day_low": "yahoo_day_low",
            "day_high": "yahoo_day_high",
            "fifty_two_week_low": "yahoo_52_week_low",
            "fifty_two_week_high": "yahoo_52_week_high",
            "market_volume": "yahoo_regular_market_volume",
            "pe_ratio": "yahoo_trailing_pe",
            "beta": "yahoo_beta",
            "dividend_yield": "yahoo_dividend_yield"
        }

        for target_key, yahoo_key in yahoo_fill_map.items():
            if (
                result.get(target_key) in [None, "", [], {}]
                and yahoo_data.get(yahoo_key) not in [None, "", [], {}]
            ):
                result[target_key] = yahoo_data[yahoo_key]

        # Fill missing values from Ownership
        for key, value in ownership_data.items():

            if (
                key not in result
                or result.get(key) in [None, "", [], {}]
            ):
                result[key] = value

        # --------------------------
        # HEADQUARTERS PRIORITY
        # --------------------------

        result["headquarters"] = (
            wiki_data.get("headquarters")
            or wikidata_data.get("headquarters")
        )

        if (
            yahoo_data.get("ticker")
            and not sec_data.get("ticker")
            and result.get("ownership_type") in [
                None,
                "",
                "Unknown",
                "Subsidiary"
            ]
        ):
            result["ownership_type"] = "Public Company"
            if result.get("parent_company"):
                result["group_company"] = result.get("parent_company")

        # --------------------------
        # WEBSITE CONTENT
        # --------------------------

        result["website_content"] = (
            website_data.get(
                "website_content",
                ""
            )
        )

        result["news_articles"] = news_data.get(
            "articles",
            []
        )

        result["news_error"] = news_data.get(
            "news_error"
        )

        # --------------------------
        # COMPANY AGE
        # --------------------------

        founded_year = result.get(
            "founded_year"
        )

        if founded_year:

            try:

                result["company_age"] = (
                    datetime.now().year
                    - int(founded_year)
                )

            except Exception:
                pass

        # --------------------------
        # DEFAULT CORE BUSINESS
        # --------------------------

        result["core_business"] = (
            yahoo_data.get("yahoo_industry")
            or yahoo_data.get("yahoo_sector")
            or
            sec_data.get("industry")
            or wiki_data.get("industry")
            or wikidata_data.get(
                "wikidata_description"
            )
        )

        result["ai_used"] = False

        # --------------------------
        # DATA SOURCES
        # --------------------------

        result["data_sources"] = {

            "wikipedia":
                bool(
                    wiki_data.get(
                        "wikipedia_title"
                    )
                ),

            "wikidata":
                bool(
                    wikidata_data.get(
                        "wikidata_id"
                    )
                ),

            "sec":
                bool(
                    sec_data.get(
                        "ticker"
                    )
                ),

            "yahoo":
                bool(
                    yahoo_data.get("ticker")
                    or yahoo_data.get("yahoo_ticker")
                ),

            "news":
                bool(
                    news_data.get(
                        "articles"
                    )
                ),

                "website":
                bool(
                    website_data.get(
                        "website_content"
                    )
                ),

            "openalex": False,
            "ror": False,
            "crossref": False
        }

        # --------------------------
        # ENTITY TYPE FALLBACK
        # ONLY WHEN UNKNOWN
        # --------------------------

        if (
            QWEN_ENABLED
            and QWEN_ENTITY_CLASSIFICATION
            and result.get("entity_type") == "Unknown"
            and result.get("wikidata_description")
        ):

            print(
                "\nUnknown entity type -> Qwen classification"
            )

            try:

                entity_result = (
                    self.qwen.classify_entity_type(
                        result.get(
                            "wikidata_description"
                        )
                    )
                )

                result["entity_type"] = (
                    entity_result.get(
                        "entity_type",
                        "Unknown"
                    )
                )

            except Exception as e:

                print(
                    f"Entity Type Error: {e}"
                )

        # --------------------------
        # GENERAL AI INSIGHTS
        # --------------------------

        if QWEN_ENABLED and QWEN_GENERAL_INSIGHTS:
            insights = self.qwen.generate_company_insights(
                context
            )
            result.update(insights)

            if insights.get("ai_core_business"):
                result["core_business"] = insights[
                    "ai_core_business"
                ]

            if insights.get("ai_insights_used"):
                result["ai_used"] = True

        # --------------------------
        # OPTIONAL CORE BUSINESS AI
        # --------------------------

        if (
            QWEN_ENABLED
            and taxonomy_list
        ):

            print(
                "\nQWEN ENABLED -> Running Core Business Classification..."
            )

            qwen_result = (
                self.qwen.classify_core_business(
                    context,
                    taxonomy_list
                )
            )

            if qwen_result.get(
                "core_business"
            ):

                result["core_business"] = (
                    qwen_result.get(
                        "core_business"
                    )
                )

                result[
                    "core_business_confidence"
                ] = (
                    qwen_result.get(
                        "confidence"
                    )
                )

                result["ai_used"] = True

        elif not QWEN_ENABLED:

            print(
                "\nQWEN DISABLED -> Skipping AI step"
            )

        return result
