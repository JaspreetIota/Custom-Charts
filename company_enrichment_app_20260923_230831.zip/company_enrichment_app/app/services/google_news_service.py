import html
import urllib.parse
import xml.etree.ElementTree as ET

import requests


class GoogleNewsService:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "CompanyEnrichmentBot/1.0"
        })

    def enrich(
        self,
        company_name,
        max_articles=5
    ):

        try:

            encoded = urllib.parse.quote(
                company_name
            )

            url = (
                "https://news.google.com/rss/search"
                f"?q={encoded}&hl=en-IN&gl=IN&ceid=IN:en"
            )

            response = self.session.get(
                url,
                timeout=(3, 8)
            )
            response.raise_for_status()

            root = ET.fromstring(response.content)

            articles = []

            for item in root.findall(".//item")[:max_articles]:
                source = item.find("source")

                articles.append({

                    "title":
                        html.unescape(
                            item.findtext("title", "")
                        ),

                    "link":
                        item.findtext("link"),

                    "published":
                        item.findtext("pubDate"),

                    "source":
                        source.text if source is not None else None
                })

            return {
                "articles": articles,
                "source": "Google News RSS"
            }

        except Exception as e:

            return {
                "articles": [],
                "news_error": str(e),
                "source": "Google News RSS"
            }

    def run(self, company_name, max_articles=5):
        return self.enrich(company_name, max_articles)
