import os
import threading

import requests


class TranslationService:
    API_LANGUAGE_CODES = {
        "zh": "zh-Hans",
        "zh-cn": "zh-Hans",
        "zh-tw": "zh-Hans"
    }
    SCRIPT_LANGUAGES = [
        (0x0400, 0x04FF, "ru"),
        (0x0600, 0x06FF, "ar"),
        (0x0900, 0x097F, "hi"),
        (0x3040, 0x30FF, "ja"),
        (0x4E00, 0x9FFF, "zh"),
        (0xAC00, 0xD7AF, "ko")
    ]

    def __init__(self):
        self._lock = threading.Lock()
        self._installed_attempts = set()
        self.api_url = os.getenv(
            "ARGOS_TRANSLATE_API_URL",
            "http://translate:5000/translate"
        ).strip()
        self.api_key = os.getenv("ARGOS_TRANSLATE_API_KEY", "").strip()

    @classmethod
    def detect_language(cls, text):
        value = (text or "").strip()
        if not value:
            return "unknown"

        for start, end, language in cls.SCRIPT_LANGUAGES:
            if any(start <= ord(character) <= end for character in value):
                return language

        try:
            from langdetect import DetectorFactory, detect

            DetectorFactory.seed = 0
            return detect(value)
        except (ImportError, Exception):
            return "en" if value.isascii() else "unknown"

    def _get_local_translation(self, source_code):
        try:
            import argostranslate.package
            import argostranslate.translate
        except ImportError:
            return None

        translation = argostranslate.translate.get_translation_from_codes(
            source_code,
            "en"
        )
        if translation or source_code in self._installed_attempts:
            return translation

        with self._lock:
            translation = argostranslate.translate.get_translation_from_codes(
                source_code,
                "en"
            )
            if translation:
                return translation

            self._installed_attempts.add(source_code)
            argostranslate.package.update_package_index()
            package = next(
                (
                    item
                    for item in argostranslate.package.get_available_packages()
                    if item.from_code == source_code and item.to_code == "en"
                ),
                None
            )
            if not package:
                return None
            argostranslate.package.install_from_path(package.download())
            return argostranslate.translate.get_translation_from_codes(
                source_code,
                "en"
            )

    def _translate_with_api(self, text, source_code):
        if not self.api_url:
            return None, source_code
        payload = {
            "q": text,
            "source": (
                self.API_LANGUAGE_CODES.get(source_code, source_code)
                if source_code != "unknown"
                else "auto"
            ),
            "target": "en",
            "format": "text"
        }
        if self.api_key:
            payload["api_key"] = self.api_key
        response = requests.post(self.api_url, json=payload, timeout=(2, 12))
        response.raise_for_status()
        data = response.json()
        detected = data.get("detectedLanguage") or {}
        return data.get("translatedText"), detected.get("language", source_code)

    def translate_company_name(self, company_name, enabled=False):
        original = (company_name or "").strip()
        metadata = {
            "original_company_name": original,
            "translated_company_name": None,
            "detected_language": "en",
            "translation_used": False,
            "translation_error": None
        }
        if not enabled or not original:
            return original, metadata

        source_code = self.detect_language(original)
        metadata["detected_language"] = source_code
        if source_code == "en":
            return original, metadata

        try:
            try:
                local_translation = self._get_local_translation(source_code)
            except Exception:
                local_translation = None
            if local_translation:
                translated = local_translation.translate(original).strip()
            else:
                translated, detected = self._translate_with_api(
                    original,
                    source_code
                )
                metadata["detected_language"] = detected
                translated = (translated or "").strip()

            if not translated:
                metadata["translation_error"] = (
                    "No Argos model or ARGOS_TRANSLATE_API_URL is available"
                )
                return original, metadata
            if translated.casefold() == original.casefold():
                return original, metadata

            metadata["translated_company_name"] = translated
            metadata["translation_used"] = True
            return translated, metadata
        except Exception as exc:
            metadata["translation_error"] = str(exc)
            return original, metadata
