import requests
from rapidfuzz import fuzz

from app.utils.company_name import normalize_company_name, name_tokens


class EntityResolverService:

    ALLOWED_KEYWORDS = [
        "company",
        "corporation",
        "organization",
        "university",
        "institute",
        "research",
        "agency",
        "foundation",
        "non-profit",
        "government",
        "college",
        "association"
    ]

    REJECT_KEYWORDS = [
        "fruit",
        "food",
        "song",
        "album",
        "film",
        "movie",
        "species",
        "character",
        "fictional"
    ]

    def __init__(self):
        self.session = requests.Session()

    def search_candidates(self, query):

        try:

            url = "https://en.wikipedia.org/w/api.php"

            params = {
                "action": "query",
                "list": "search",
                "srsearch": query,
                "format": "json"
            }

            response = self.session.get(
                url,
                params=params,
                timeout=10
            )

            if response.status_code != 200:

                print(
                    f"Wikipedia Search Error: "
                    f"{response.status_code}"
                )

                return []

            try:

                data = response.json()

            except Exception as e:

                print(
                    f"Wikipedia JSON Error: {e}"
                )

                print(
                    f"Response: "
                    f"{response.text[:500]}"
                )

                return []

            return (
                data.get("query", {})
                .get("search", [])
            )[:5]

        except Exception as e:

            print(
                f"Entity Resolver Error: {e}"
            )

            return []

    def score_candidate(self, entity_name, candidate):

        text = (
            candidate.get("title", "")
            + " "
            + candidate.get("snippet", "")
        ).lower()

        title = candidate.get("title", "")
        normalized_query = normalize_company_name(entity_name)
        normalized_title = normalize_company_name(title)

        score = max(
            fuzz.token_set_ratio(normalized_query, normalized_title),
            fuzz.partial_ratio(normalized_query, normalized_title)
        )

        query_tokens = name_tokens(entity_name)
        title_tokens = name_tokens(title)

        if query_tokens and query_tokens.issubset(title_tokens):
            score += 8

        for word in self.ALLOWED_KEYWORDS:
            if word in text:
                score += 4

        for word in self.REJECT_KEYWORDS:
            if word in text:
                score -= 35

        if "may refer to" in text or "disambiguation" in text:
            score -= 25

        return max(0, min(int(score), 100))

    def resolve(self, entity_name):

        candidates = self.search_candidates(entity_name)

        if not candidates:
            return {
                "resolved_title": entity_name,
                "confidence": 0
            }

        scored_candidates = [
            {
                "title": candidate.get("title"),
                "snippet": candidate.get("snippet"),
                "score": self.score_candidate(
                    entity_name,
                    candidate
                )
            }
            for candidate in candidates
        ]

        scored_candidates.sort(
            key=lambda item: item["score"],
            reverse=True
        )

        best = scored_candidates[0]

        if best["score"] < 70:
            return {
                "resolved_title": entity_name,
                "confidence": best["score"],
                "status": "needs_review",
                "candidates": scored_candidates[:5]
            }

        return {
            "resolved_title": best["title"],
            "confidence": best["score"],
            "status": "matched",
            "candidates": scored_candidates[:5]
        }
