import requests
from rapidfuzz import fuzz

from app.utils.company_name import normalize_company_name


class YahooFinanceService:
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36"
            )
        })

    def _score_quote(self, company_name, quote):
        query = normalize_company_name(company_name)
        long_name = normalize_company_name(
            quote.get("longname")
            or quote.get("shortname")
            or ""
        )

        if not query or not long_name:
            return 0

        query_tokens = set(query.split())
        candidate_tokens = set(long_name.split())
        extra_tokens = max(
            0,
            len(candidate_tokens - query_tokens)
        )

        score = max(
            fuzz.ratio(query, long_name),
            fuzz.token_sort_ratio(query, long_name)
        )

        if query == long_name:
            score += 15

        score -= extra_tokens * 8

        exchange = (
            quote.get("exchange")
            or quote.get("exchDisp")
            or ""
        ).upper()

        if exchange in ["NSI", "NSE", "NMS", "NYQ", "NASDAQ", "NYSE"]:
            score += 3
        elif exchange in ["BSE", "BOMBAY"]:
            score += 2

        return max(0, score)

    def _raw_value(self, data, key):
        value = data.get(key)

        if isinstance(value, dict):
            return value.get("raw") or value.get("fmt")

        return value

    def get_financial_details(self, symbol):
        if not symbol:
            return {}

        try:
            response = self.session.get(
                f"https://query2.finance.yahoo.com/v10/finance/quoteSummary/{symbol}",
                params={
                    "modules": ",".join([
                        "price",
                        "assetProfile",
                        "summaryDetail",
                        "financialData",
                        "defaultKeyStatistics"
                    ])
                },
                timeout=(3, 10)
            )
            response.raise_for_status()

            result = (
                response.json()
                .get("quoteSummary", {})
                .get("result", [])
            )

            if not result:
                return {}

            data = result[0]
            price = data.get("price", {})
            profile = data.get("assetProfile", {})
            summary = data.get("summaryDetail", {})
            financial = data.get("financialData", {})
            stats = data.get("defaultKeyStatistics", {})

            return {
                "yahoo_currency":
                    self._raw_value(price, "currency"),
                "yahoo_market_cap":
                    self._raw_value(price, "marketCap")
                    or self._raw_value(summary, "marketCap"),
                "yahoo_regular_market_price":
                    self._raw_value(price, "regularMarketPrice"),
                "yahoo_previous_close":
                    self._raw_value(summary, "previousClose"),
                "yahoo_day_low":
                    self._raw_value(summary, "dayLow"),
                "yahoo_day_high":
                    self._raw_value(summary, "dayHigh"),
                "yahoo_52_week_low":
                    self._raw_value(summary, "fiftyTwoWeekLow"),
                "yahoo_52_week_high":
                    self._raw_value(summary, "fiftyTwoWeekHigh"),
                "yahoo_trailing_pe":
                    self._raw_value(summary, "trailingPE"),
                "yahoo_forward_pe":
                    self._raw_value(summary, "forwardPE"),
                "yahoo_dividend_yield":
                    self._raw_value(summary, "dividendYield"),
                "yahoo_beta":
                    self._raw_value(summary, "beta")
                    or self._raw_value(stats, "beta"),
                "yahoo_sector":
                    profile.get("sector"),
                "yahoo_industry":
                    profile.get("industry"),
                "yahoo_website":
                    profile.get("website"),
                "yahoo_employees":
                    profile.get("fullTimeEmployees"),
                "yahoo_total_revenue":
                    self._raw_value(financial, "totalRevenue"),
                "yahoo_gross_profit":
                    self._raw_value(financial, "grossProfits"),
                "yahoo_ebitda":
                    self._raw_value(financial, "ebitda"),
                "yahoo_profit_margin":
                    self._raw_value(financial, "profitMargins"),
                "yahoo_revenue_growth":
                    self._raw_value(financial, "revenueGrowth"),
                "yahoo_earnings_growth":
                    self._raw_value(financial, "earningsGrowth"),
                "yahoo_recommendation":
                    financial.get("recommendationKey"),
                "yahoo_target_mean_price":
                    self._raw_value(financial, "targetMeanPrice")
            }

        except Exception as e:
            chart_details = self.get_chart_details(symbol)
            if chart_details:
                chart_details["yahoo_financial_fallback"] = "chart"
                return chart_details

            return {
                "yahoo_financial_error": str(e)
            }

    def get_chart_details(self, symbol):
        try:
            response = self.session.get(
                f"https://query1.finance.yahoo.com/v8/finance/chart/{symbol}",
                params={
                    "range": "1d",
                    "interval": "1d"
                },
                timeout=(3, 10)
            )
            response.raise_for_status()

            result = (
                response.json()
                .get("chart", {})
                .get("result", [])
            )

            if not result:
                return {}

            meta = result[0].get("meta", {})

            return {
                "yahoo_currency":
                    meta.get("currency"),
                "yahoo_regular_market_price":
                    meta.get("regularMarketPrice"),
                "yahoo_previous_close":
                    meta.get("chartPreviousClose"),
                "yahoo_day_low":
                    meta.get("regularMarketDayLow"),
                "yahoo_day_high":
                    meta.get("regularMarketDayHigh"),
                "yahoo_52_week_low":
                    meta.get("fiftyTwoWeekLow"),
                "yahoo_52_week_high":
                    meta.get("fiftyTwoWeekHigh"),
                "yahoo_regular_market_volume":
                    meta.get("regularMarketVolume"),
                "yahoo_full_exchange_name":
                    meta.get("fullExchangeName"),
                "yahoo_instrument_type":
                    meta.get("instrumentType"),
                "yahoo_timezone":
                    meta.get("timezone")
            }

        except Exception:
            return {}

    def search_symbol(self, company_name):
        try:
            response = self.session.get(
                "https://query2.finance.yahoo.com/v1/finance/search",
                params={
                    "q": company_name,
                    "quotesCount": 10,
                    "newsCount": 0
                },
                timeout=(3, 8)
            )
            response.raise_for_status()

            quotes = response.json().get("quotes", [])
            equity_quotes = [
                quote
                for quote in quotes
                if quote.get("symbol")
                and quote.get("quoteType") in ["EQUITY", "ETF"]
            ]

            if not equity_quotes:
                return {}

            scored = [
                {
                    **quote,
                    "match_score": self._score_quote(
                        company_name,
                        quote
                    )
                }
                for quote in equity_quotes
            ]
            scored.sort(
                key=lambda quote: quote["match_score"],
                reverse=True
            )

            best = scored[0]

            if best["match_score"] < 65:
                return {
                    "yahoo_match_status": "needs_review",
                    "yahoo_match_confidence": best["match_score"],
                    "yahoo_candidates": scored[:5],
                    "source": "Yahoo Finance"
                }

            symbol = best.get("symbol")
            financial_details = self.get_financial_details(symbol)

            return {
                "ticker": symbol,
                "yahoo_ticker": symbol,
                "exchange": best.get("exchDisp") or best.get("exchange"),
                "yahoo_exchange": best.get("exchDisp") or best.get("exchange"),
                "legal_name": best.get("longname") or best.get("shortname"),
                "yahoo_legal_name": best.get("longname") or best.get("shortname"),
                "yahoo_match_status": "matched",
                "yahoo_match_confidence": min(best["match_score"], 100),
                "quote_type": best.get("quoteType"),
                "source": "Yahoo Finance",
                **{
                    key: value
                    for key, value in financial_details.items()
                    if value not in [None, "", [], {}]
                }
            }

        except Exception as e:
            return {
                "ticker": None,
                "exchange": None,
                "legal_name": None,
                "yahoo_error": str(e),
                "source": "Yahoo Finance"
            }

    def run(self, company_name):
        return self.enrich(company_name)

    def enrich(self, company_name):
        return self.search_symbol(company_name)
