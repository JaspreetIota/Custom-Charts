class ConfidenceScorer:

    def calculate(
        self,
        wiki_data,
        wikidata_data,
        sec_data,
        yahoo_data=None,
        news_data=None
    ):
        yahoo_data = yahoo_data or {}
        news_data = news_data or {}
        score = 0

        if wiki_data.get("description"):
            score += 20

        if wiki_data.get("industry"):
            score += 15

        if wikidata_data.get("wikidata_description"):
            score += 20

        if sec_data.get("ticker"):
            score += 30
        elif yahoo_data.get("ticker"):
            score += 25

        if wiki_data.get("website"):
            score += 10

        if wiki_data.get("headquarters"):
            score += 5

        if news_data.get("articles"):
            score += 5

        return min(score, 100)
