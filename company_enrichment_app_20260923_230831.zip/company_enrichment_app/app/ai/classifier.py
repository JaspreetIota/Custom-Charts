class CompanyClassifier:

    def classify_industry(self, wiki_data, wikidata_data):
        industry = (
            wiki_data.get("industry")
            or wikidata_data.get("wikidata_description")
        )

        if not industry:
            return "Unknown"

        industry = industry.lower()

        if "software" in industry or "saas" in industry:
            return "Technology"

        if "bank" in industry or "financial" in industry:
            return "Finance"

        if "health" in industry or "pharma" in industry:
            return "Healthcare"

        if "retail" in industry:
            return "Retail"

        return "Other"