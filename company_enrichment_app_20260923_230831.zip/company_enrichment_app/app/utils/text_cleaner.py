import re


class TextCleaner:

    @staticmethod
    def clean(text: str) -> str:

        if not text:
            return ""

        # remove multiple spaces
        text = re.sub(r"\s+", " ", text)

        # remove special characters (keep basic punctuation)
        text = re.sub(r"[^a-zA-Z0-9.,&()\- ]", "", text)

        return text.strip()

    @staticmethod
    def truncate(text: str, limit: int = 15000) -> str:

        if not text:
            return ""

        return text[:limit]