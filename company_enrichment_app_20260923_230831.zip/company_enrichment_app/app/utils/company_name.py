import re


LEGAL_SUFFIXES = [
    "incorporated",
    "corporation",
    "corp",
    "company",
    "co",
    "limited",
    "ltd",
    "private limited",
    "pvt ltd",
    "pvt",
    "llc",
    "llp",
    "plc",
    "ag",
    "gmbh",
    "sa",
    "s a",
    "spa",
    "bv",
    "nv",
]


def normalize_company_name(name: str) -> str:
    if not name:
        return ""

    value = name.lower()
    value = value.replace("&", " and ")
    value = re.sub(r"[^a-z0-9\s]", " ", value)
    value = re.sub(r"\s+", " ", value).strip()

    for suffix in sorted(LEGAL_SUFFIXES, key=len, reverse=True):
        value = re.sub(
            rf"\b{re.escape(suffix)}\b\.?$",
            "",
            value
        ).strip()

    return re.sub(r"\s+", " ", value).strip()


def name_tokens(name: str) -> set[str]:
    normalized = normalize_company_name(name)
    return {
        token
        for token in normalized.split()
        if len(token) > 1
    }
