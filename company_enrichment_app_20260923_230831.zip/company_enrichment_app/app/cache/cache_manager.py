import json
import redis
from app.core.config import REDIS_HOST, REDIS_PORT, CACHE_TTL_SECONDS
from app.core.logging import LoggerFactory

logger = LoggerFactory.get_logger("cache")


class CacheManager:

    def __init__(self):

        self.client = redis.Redis(
            host=REDIS_HOST,
            port=REDIS_PORT,
            decode_responses=True
        )

    # --------------------------
    # GET CACHE
    # --------------------------
    def get(self, key: str):

        try:
            data = self.client.get(key)

            if data:
                logger.info(f"Cache HIT: {key}")
                return json.loads(data)

            logger.info(f"Cache MISS: {key}")
            return None

        except Exception as e:
            logger.error(f"Cache GET error: {e}")
            return None

    # --------------------------
    # SET CACHE
    # --------------------------
    def set(self, key: str, value: dict):

        try:
            self.client.setex(
                key,
                CACHE_TTL_SECONDS,
                json.dumps(value)
            )

            logger.info(f"Cache SET: {key}")

        except Exception as e:
            logger.error(f"Cache SET error: {e}")