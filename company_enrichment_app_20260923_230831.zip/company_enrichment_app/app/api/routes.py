from fastapi import APIRouter
from pydantic import BaseModel

from tasks import enrich_company_task

router = APIRouter()

class CompanyRequest(BaseModel):
    company_name: str
    taxonomy_list: list[str]

@router.post("/enrich")
def enrich_company(request: CompanyRequest):

    result = enrich_company_task(
        request.company_name,
        request.taxonomy_list
    )

    return {
        "status": "success",
        "data": result
    }