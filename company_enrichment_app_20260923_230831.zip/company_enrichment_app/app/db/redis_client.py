import time

import redis
from app.core.config import REDIS_HOST, REDIS_PORT, USE_REDIS


class SafeRedisClient:
    def __init__(self):
        self.client = None
        if USE_REDIS:
            self.client = redis.Redis(
                host=REDIS_HOST,
                port=REDIS_PORT,
                decode_responses=True,
                socket_connect_timeout=0.2,
                socket_timeout=0.2
            )
        self.memory_store = {}

    def _cleanup_expired(self, key):
        record = self.memory_store.get(key)
        if not record:
            return

        _, expires_at = record
        if expires_at and expires_at < time.time():
            self.memory_store.pop(key, None)

    def get(self, key):
        if not self.client:
            self._cleanup_expired(key)
            record = self.memory_store.get(key)
            return record[0] if record else None

        try:
            return self.client.get(key)
        except redis.RedisError:
            self._cleanup_expired(key)
            record = self.memory_store.get(key)
            return record[0] if record else None

    def set(self, key, value):
        if not self.client:
            self.memory_store[key] = (value, None)
            return True

        try:
            return self.client.set(key, value)
        except redis.RedisError:
            self.memory_store[key] = (value, None)
            return True

    def setex(self, key, ttl, value):
        if not self.client:
            self.memory_store[key] = (value, time.time() + ttl)
            return True

        try:
            return self.client.setex(key, ttl, value)
        except redis.RedisError:
            self.memory_store[key] = (value, time.time() + ttl)
            return True


redis_client = SafeRedisClient()

# =========================
# BASIC CACHE HELPERS
# =========================

def get_cache(key: str):
    return redis_client.get(key)


def set_cache(key: str, value: str, ttl: int):
    redis_client.setex(key, ttl, value)
