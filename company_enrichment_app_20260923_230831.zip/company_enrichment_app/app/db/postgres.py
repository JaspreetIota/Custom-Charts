import psycopg2
from psycopg2.extras import RealDictCursor
from app.core.config import POSTGRES_URL
from app.core.logging import LoggerFactory

logger = LoggerFactory.get_logger("postgres")


class PostgresClient:

    def __init__(self):

        self.conn = psycopg2.connect(POSTGRES_URL)

    # --------------------------
    # INSERT COMPANY
    # --------------------------
    def insert_company(self, table: str, data: dict):

        try:
            columns = ", ".join(data.keys())
            values_placeholders = ", ".join(["%s"] * len(data))

            query = f"""
                INSERT INTO {table} ({columns})
                VALUES ({values_placeholders})
            """

            with self.conn.cursor() as cursor:
                cursor.execute(query, list(data.values()))
                self.conn.commit()

            logger.info(f"Inserted into {table}: {data.get('company_name')}")

        except Exception as e:
            logger.error(f"DB Insert Error: {e}")
            self.conn.rollback()

    # --------------------------
    # FETCH COMPANY
    # --------------------------
    def fetch_company(self, table: str, company_name: str):

        try:
            query = f"""
                SELECT * FROM {table}
                WHERE company_name = %s
            """

            with self.conn.cursor(cursor_factory=RealDictCursor) as cursor:
                cursor.execute(query, (company_name,))
                return cursor.fetchone()

        except Exception as e:
            logger.error(f"DB Fetch Error: {e}")
            return None