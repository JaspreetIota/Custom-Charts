from datetime import datetime


class CompanyProfile:

    def __init__(self, data: dict):

        self.company_name = data.get("company_name")
        self.wikipedia_title = data.get("wikipedia_title")

        # Core business
        self.core_business = data.get("core_business")
        self.core_business_confidence = data.get("core_business_confidence")

        # Wikipedia
        self.description = data.get("description")
        self.summary = data.get("summary")
        self.industry = data.get("industry")

        # Wikidata / SEC
        self.ticker = data.get("ticker")
        self.exchange = data.get("exchange")
        self.country = data.get("country")

        # Ownership
        self.ownership_type = data.get("ownership_type")
        self.parent_company = data.get("parent_company")

        # Website
        self.website_content = data.get("website_content")

        # Metadata
        self.created_at = datetime.utcnow()

    def to_dict(self):

        return self.__dict__