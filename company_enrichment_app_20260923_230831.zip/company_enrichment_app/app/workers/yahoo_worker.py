from app.services.google_news_service import GoogleNewsService


class NewsWorker:

    def __init__(self):
        self.service = GoogleNewsService()

    def run(
        self,
        company_name
    ):

        return self.service.get_news(
            company_name
        )