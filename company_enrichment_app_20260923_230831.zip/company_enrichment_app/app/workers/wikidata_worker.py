from services.wikidata_service import WikidataService

class WikidataWorker:

    def __init__(self):
        self.service = WikidataService()

    def run(self, wikipedia_title):
        return self.service.enrich(wikipedia_title)