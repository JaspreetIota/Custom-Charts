import urllib.parse
import feedparser

class GoogleNewsWorker:

    def get_news(self, query, max_articles=10):

        encoded = urllib.parse.quote(query)
        url = f"https://news.google.com/rss/search?q={encoded}"

        feed = feedparser.parse(url)

        news = []

        if not feed.entries:
            return []

        for entry in feed.entries[:max_articles]:
            news.append({
                "title": entry.title,
                "link": entry.link,
                "published": entry.get("published")
            })

        return news

    def run(self, company_name):
        news = self.get_news(company_name, 10)

        return {
            "google_news": news
        }