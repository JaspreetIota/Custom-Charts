from services.website_service import WebsiteService

class WebsiteWorker:

    def __init__(self):
        self.service = WebsiteService()

    def run(self, website_url):
        if not website_url:
            return {
                "about_page": None,
                "website_content": ""
            }

        return self.service.enrich(website_url)