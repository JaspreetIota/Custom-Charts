from services.sec_service import SECService

class SECWorker:

    def __init__(self):
        self.service = SECService()

    def run(self, company_name):
        return self.service.enrich(company_name)