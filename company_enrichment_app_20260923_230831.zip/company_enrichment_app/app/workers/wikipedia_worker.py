from services.wikipedia_service import WikipediaService

class WikipediaWorker:

    def __init__(self):
        self.service = WikipediaService()

    def run(self, company_name):
        page_title = self.service.search_company(company_name)

        if not page_title:
            return {
                "company_name": company_name,
                "error": "Not found"
            }

        summary = self.service.get_summary(page_title)
        infobox = self.service.get_infobox(page_title)

        return {
            "company_name": company_name,
            "wikipedia_title": page_title,
            "summary": summary,
            "infobox": infobox,
            "founded_year": self.service.extract_founded_year(infobox),
            "website": self.service.extract_website(infobox)
        }