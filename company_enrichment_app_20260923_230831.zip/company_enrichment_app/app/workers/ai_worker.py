from services.qwen_service import QwenService
from services.context_builder import build_fast_context

class AIWorker:

    def __init__(self):
        self.qwen = QwenService()

    def run(self, wiki_data, wikidata_data, sec_data, taxonomy_list):

        context = build_fast_context(
            wiki_data,
            wikidata_data,
            sec_data
        )

        return self.qwen.classify_core_business(
            context,
            taxonomy_list
        )