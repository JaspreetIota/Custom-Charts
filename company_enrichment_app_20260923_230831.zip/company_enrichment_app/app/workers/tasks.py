from app.workers.celery_app import celery_app
from app.orchestration.orchestrator import Orchestrator

orchestrator = Orchestrator()

@celery_app.task
def run_enrichment(job_id, company_name):
    return orchestrator.run_full_pipeline(job_id, company_name)