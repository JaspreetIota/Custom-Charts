class BaseEnrichmentException(Exception):
    """Base exception for entire system"""
    pass


class WikipediaException(BaseEnrichmentException):
    pass


class WikidataException(BaseEnrichmentException):
    pass


class SECException(BaseEnrichmentException):
    pass


class WebsiteException(BaseEnrichmentException):
    pass


class AIException(BaseEnrichmentException):
    pass


class PipelineException(BaseEnrichmentException):
    pass