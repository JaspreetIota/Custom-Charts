import os

# =========================
# API AUTH
# =========================

API_AUTH_ENABLED = os.getenv(
    "API_AUTH_ENABLED",
    "true"
).lower() == "true"

API_USERNAME = os.getenv(
    "API_USERNAME",
    "admin"
)

API_PASSWORD = os.getenv(
    "API_PASSWORD",
    "Enr!OpYUcCypzLNePzfrd05a1epo"
)

# =========================
# AI CONFIG
# =========================

QWEN_ENABLED = os.getenv(
    "QWEN_ENABLED",
    "true"
).lower() == "true"

QWEN_MODEL = os.getenv(
    "QWEN_MODEL",
    "qwen3:8b"
)

QWEN_BASE_URL = os.getenv(
    "QWEN_BASE_URL",
    "http://host.docker.internal:11434"
)

QWEN_TIMEOUT_SECONDS = int(
    os.getenv(
        "QWEN_TIMEOUT_SECONDS",
        5
    )
)
QWEN_ENTITY_CLASSIFICATION = os.getenv(
    "QWEN_ENTITY_CLASSIFICATION",
    "false"
).lower() == "true"

QWEN_GENERAL_INSIGHTS = os.getenv(
    "QWEN_GENERAL_INSIGHTS",
    "false"
).lower() == "true"
# =========================
# FEATURE FLAGS
# =========================

ENABLE_WEBSITE = os.getenv(
    "ENABLE_WEBSITE",
    "false"
).lower() == "true"

ENABLE_NEWS = os.getenv(
    "ENABLE_NEWS",
    "true"
).lower() == "true"

ENABLE_YAHOO = os.getenv(
    "ENABLE_YAHOO",
    "true"
).lower() == "true"

ENABLE_LOGOS = os.getenv(
    "ENABLE_LOGOS",
    "true"
).lower() == "true"

LOGO_DEV_TOKEN = os.getenv(
    "LOGO_DEV_TOKEN",
    "pk_NIpDpQNXQOKnO713UnP7Aw"
)

# =========================
# DATABASE / CACHE
# =========================

REDIS_HOST = os.getenv(
    "REDIS_HOST",
    "localhost"
)

REDIS_PORT = int(
    os.getenv(
        "REDIS_PORT",
        6379
    )
)

USE_REDIS = os.getenv(
    "USE_REDIS",
    "false"
).lower() == "true"

POSTGRES_URL = os.getenv(
    "POSTGRES_URL",
    "postgresql://postgres:postgres@localhost:5432/enrichment"
)

# =========================
# PERFORMANCE SETTINGS
# =========================

FILE_ENRICH_WORKERS = int(
    os.getenv(
        "FILE_ENRICH_WORKERS",
        6
    )
)

MAX_WEBSITE_CHARS = 15000
WIKIPEDIA_SUMMARY_LIMIT = 800

# =========================
# CACHE SETTINGS
# =========================

CACHE_TTL_SECONDS = 60 * 60 * 24 * 7
