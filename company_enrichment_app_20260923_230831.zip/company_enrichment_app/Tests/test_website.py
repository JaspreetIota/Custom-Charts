import sys
from pathlib import Path

project_root = (
    Path(__file__)
    .resolve()
    .parent
    .parent
)

sys.path.append(
    str(project_root)
)

from services.wikipedia_service import WikipediaService
from services.website_service import WebsiteService

wiki = WikipediaService()

website_service = WebsiteService()

company = "Lenovo"

print(
    f"\nSearching Company: {company}"
)

wiki_data = wiki.enrich(
    company
)

print("\nWikipedia Website:")
print(
    wiki_data["website"]
)

result = website_service.enrich(
    wiki_data["website"]
)

print("\nABOUT PAGE")
print("-" * 50)
print(
    result["about_page"]
)

print("\nCONTENT PREVIEW")
print("-" * 50)

print(
    result["website_content"][:2000]
)