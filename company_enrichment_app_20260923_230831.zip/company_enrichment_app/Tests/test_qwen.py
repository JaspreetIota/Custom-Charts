import sys
from pathlib import Path

project_root = (
    Path(__file__)
    .resolve()
    .parent
    .parent
)

sys.path.append(
    str(project_root)
)

from services.wikipedia_service import (
    WikipediaService
)

from services.wikidata_service import (
    WikidataService
)

from services.sec_service import (
    SECService
)

from services.ownership_service import (
    OwnershipService
)

from services.website_service import (
    WebsiteService
)

from services.qwen_service import (
    QwenService
)

company = "Lenovo"

wiki = WikipediaService()
wikidata = WikidataService()
sec = SECService()
ownership = OwnershipService()
website = WebsiteService()
qwen = QwenService()

wiki_data = wiki.enrich(company)

wikidata_data = wikidata.enrich(
    wiki_data["wikipedia_title"]
)

sec_data = sec.enrich(company)

ownership_data = ownership.enrich(
    wiki_data,
    wikidata_data,
    sec_data
)

website_data = website.enrich(
    wiki_data["website"]
)

result = qwen.classify(
    wiki_data,
    wikidata_data,
    sec_data,
    ownership_data,
    website_data
)

print("\nQWEN RESULT\n")
print(result)