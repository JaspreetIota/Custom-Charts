import sys
from pathlib import Path

project_root = Path(__file__).resolve().parent.parent
sys.path.append(str(project_root))

from services.wikipedia_service import WikipediaService
from services.wikidata_service import WikidataService
from services.sec_service import SECService
from services.ownership_service import OwnershipService

company = "Masimo"

wiki = WikipediaService()
wikidata = WikidataService()
sec = SECService()
ownership = OwnershipService()

wiki_data = wiki.enrich(company)

wikidata_data = wikidata.enrich(
    wiki_data["wikipedia_title"]
)

sec_data = sec.enrich(company)

result = ownership.enrich(
    wiki_data,
    wikidata_data,
    sec_data
)

print(result)