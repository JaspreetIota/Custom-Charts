import sys
from pathlib import Path

project_root = Path(__file__).resolve().parent.parent
sys.path.append(str(project_root))

from services.wikipedia_service import WikipediaService

wiki = WikipediaService()

result = wiki.enrich("Lenovo")

print(result)