import sys
from pathlib import Path

project_root = Path(__file__).resolve().parent.parent
sys.path.append(str(project_root))

from services.sec_service import SECService

sec = SECService()

for company in [
    "Masimo",
    "Apple",
    "Microsoft",
    "NVIDIA",
    "Lenovo"
]:

    print("\n" + "=" * 80)
    print(company)
    print("=" * 80)

    result = sec.enrich(company)

    print(result)