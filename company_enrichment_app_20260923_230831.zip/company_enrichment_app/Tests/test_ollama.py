import ollama

response = ollama.chat(
    model="qwen3:8b",
    messages=[
        {
            "role": "user",
            "content": "What company makes ThinkPad laptops? Reply in one sentence."
        }
    ]
)

print(response["message"]["content"])