import sys
from pathlib import Path

project_root = Path(__file__).resolve().parent.parent
sys.path.append(str(project_root))

from services.wikipedia_service import WikipediaService
from services.wikidata_service import WikidataService

wiki = WikipediaService()
wikidata = WikidataService()

# Step 1: Get Wikipedia data
wiki_result = wiki.enrich("Masimo")

print("\nWikipedia Result")
print(wiki_result)

# Step 2: Get Wikidata data using Wikipedia title
wikidata_result = wikidata.enrich(
    wiki_result["wikipedia_title"]
)

print("\nWikidata Result")
print(wikidata_result)