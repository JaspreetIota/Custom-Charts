# Company Enrichment System

## Features
- Wikipedia extraction
- Wikidata enrichment
- SEC financial mapping
- Website scraping
- AI-based classification (Qwen)
- Confidence scoring
- Redis caching
- PostgreSQL storage

## Run Locally

```bash
pip install -r requirements.txt
uvicorn app.main:app --reload