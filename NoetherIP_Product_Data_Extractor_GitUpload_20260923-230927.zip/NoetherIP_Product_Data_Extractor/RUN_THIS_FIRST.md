# NoetherIP Product Data Extractor - Portable Bundle

## What is included

- `api/` - FastAPI backend source code, requirements, `.env.example`, API docs and architecture notes.
- `ui/real-api-demo.html` - Live HTML demo that calls the FastAPI backend at `http://127.0.0.1:8000`.
- `ui/index.html` - Static product extractor prototype.

This bundle intentionally excludes `.venv`, `.env`, caches and local runtime files.

## Requirements on the new PC

- Python 3.11 or newer
- Internet connection for public APIs
- PowerShell on Windows

## Run the API

Open PowerShell:

```powershell
cd "PATH_TO_EXTRACTED_ZIP\NoetherIP_Product_Data_Extractor_Portable_20260718-221639\api"
copy .env.example .env
.\run-api.ps1
```

The API should start at:

```text
http://127.0.0.1:8000
```

Open API pages:

```text
http://127.0.0.1:8000/search
http://127.0.0.1:8000/companies/products
http://127.0.0.1:8000/enrich/name
http://127.0.0.1:8000/docs
```

## Open the live demo

After the API is running, open:

```text
ui\real-api-demo.html
```

The demo expects the API base to be:

```text
http://127.0.0.1:8000
```

## Optional keys

Edit `api\.env` if you get keys later:

```env
GITHUB_TOKEN=
BESTBUY_API_KEY=
GOOGLE_API_KEY=
GOOGLE_CX=
BARCODE_LOOKUP_KEY=
UPCITEMDB_USER_AGENT=NoetherIP-Product-Data-Extractor/0.1
```

The project still runs without keys using no-key/free sources.
