from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field


SourceCategory = Literal[
    "metadata",
    "manuals",
    "datasheet",
    "regulatory",
    "teardown",
    "code",
    "history",
    "entity",
]

DocumentType = Literal[
    "datasheet",
    "manual",
    "service_manual",
    "firmware_release_notes",
    "support_page",
    "teardown",
    "regulatory",
    "unknown",
]

SearchType = Literal[
    "product_name",
    "model_number",
    "part_number",
    "product_id",
    "fcc_id",
    "upc_gtin",
    "sku_mpn_asin",
    "marking",
    "product_url",
    "company",
]


class ProductQuery(BaseModel):
    query: str = Field(..., min_length=2, description="Product, component, chipset, model, company, or free-text query")
    search_type: SearchType | None = Field(default="product_name", description="How the user's primary search value should be interpreted.")
    product_name: str | None = None
    product_id: str | None = None
    brand: str | None = None
    manufacturer: str | None = None
    company_name: str | None = None
    model_number: str | None = None
    part_number: str | None = None
    serial_number: str | None = None
    sku: str | None = None
    asin: str | None = None
    mpn: str | None = None
    board_marking: str | None = None
    chip_marking: str | None = None
    device_id: str | None = None
    fcc_id: str | None = None
    upc: str | None = None
    gtin: str | None = None
    product_url: str | None = None
    vertical: str | None = "auto"
    max_results_per_source: int = Field(5, ge=1, le=25)
    include_sources: list[str] | None = None
    free_only: bool = Field(default=True, description="Use only free/no-key sources by default.")

    def search_text(self) -> str:
        parts = [
            self.product_name,
            self.query,
            self.model_number,
            self.part_number,
            self.mpn,
            self.product_id,
            self.sku,
            self.asin,
            self.board_marking,
            self.chip_marking,
            self.device_id,
            self.company_name,
            self.manufacturer,
            self.brand,
        ]
        seen: list[str] = []
        for part in parts:
            if not part:
                continue
            value = " ".join(str(part).split())
            lowered = value.lower()
            existing = " ".join(seen).lower()
            if value and lowered not in {item.lower() for item in seen} and lowered not in existing:
                seen.append(value)
        return " ".join(seen) or self.query

    def identifier_map(self) -> dict[str, str]:
        values = {
            "product_id": self.product_id,
            "model_number": self.model_number,
            "part_number": self.part_number,
            "serial_number": self.serial_number,
            "sku": self.sku,
            "asin": self.asin,
            "mpn": self.mpn,
            "board_marking": self.board_marking,
            "chip_marking": self.chip_marking,
            "device_id": self.device_id,
            "fcc_id": self.fcc_id,
            "upc": self.upc,
            "gtin": self.gtin,
        }
        return {key: value for key, value in values.items() if value}


class EvidenceItem(BaseModel):
    source: str
    category: SourceCategory
    title: str
    url: str | None = None
    snippet: str | None = None
    reliability: int = Field(default=50, ge=0, le=100)
    identifiers: dict[str, str] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)
    fetched_at: datetime = Field(default_factory=datetime.utcnow)


class NormalizedProduct(BaseModel):
    query: str
    brand: str | None = None
    manufacturer: str | None = None
    model_number: str | None = None
    product_id: str | None = None
    product_name: str | None = None
    part_number: str | None = None
    serial_number: str | None = None
    sku: str | None = None
    asin: str | None = None
    mpn: str | None = None
    board_marking: str | None = None
    chip_marking: str | None = None
    device_id: str | None = None
    category: str | None = None
    fcc_id: str | None = None
    upc_gtin: str | None = None
    product_url: str | None = None
    input_identifiers: dict[str, str] = Field(default_factory=dict)
    aliases: list[str] = Field(default_factory=list)
    source_count: int = 0
    confidence: int = Field(default=0, ge=0, le=100)


class ProductDataProfile(BaseModel):
    product_identity: dict[str, Any] = Field(default_factory=dict)
    official_docs: dict[str, Any] = Field(default_factory=dict)
    technical_specs: dict[str, Any] = Field(default_factory=dict)
    teardown_re: dict[str, Any] = Field(default_factory=dict)
    regulatory: dict[str, Any] = Field(default_factory=dict)
    evidence_provenance: list[dict[str, Any]] = Field(default_factory=list)
    history: dict[str, Any] = Field(default_factory=dict)


class FieldCoverage(BaseModel):
    group: str
    total_fields: int
    found_fields: list[str] = Field(default_factory=list)
    missing_fields: list[str] = Field(default_factory=list)
    coverage_percent: int = Field(default=0, ge=0, le=100)


class CoverageReport(BaseModel):
    overall_percent: int = Field(default=0, ge=0, le=100)
    groups: list[FieldCoverage] = Field(default_factory=list)
    free_next_actions: list[str] = Field(default_factory=list)
    optional_paid_recommendations: list[str] = Field(default_factory=list)
    data_quality_notes: list[str] = Field(default_factory=list)


class SourceRun(BaseModel):
    source: str
    status: Literal["ok", "skipped", "error"]
    message: str
    count: int = 0


class ExtractionResponse(BaseModel):
    product: NormalizedProduct
    data_profile: ProductDataProfile = Field(default_factory=ProductDataProfile)
    coverage: CoverageReport = Field(default_factory=CoverageReport)
    evidence: list[EvidenceItem]
    source_runs: list[SourceRun]
    next_steps: list[str]


class DocumentExtractRequest(BaseModel):
    url: str
    document_type: DocumentType = "unknown"
    product_query: str | None = None
    source_title: str | None = None


class DocumentExtractResponse(BaseModel):
    url: str
    final_url: str | None = None
    document_type: DocumentType
    status: Literal["ok", "error"]
    http_status: int | None = None
    content_type: str | None = None
    title: str | None = None
    text_preview: str | None = None
    extracted_fields: dict[str, Any] = Field(default_factory=dict)
    normalized_groups: ProductDataProfile = Field(default_factory=ProductDataProfile)
    links: list[str] = Field(default_factory=list)
    images: list[str] = Field(default_factory=list)
    downloaded_assets: list[dict[str, Any]] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)
    error: str | None = None


class CandidatePage(BaseModel):
    url: str
    title: str
    source_type: str
    document_type: DocumentType = "unknown"
    reliability: int = Field(default=50, ge=0, le=100)
    extractable: bool = True
    reason: str | None = None


class HarvestedIdentifier(BaseModel):
    field: str
    value: str
    source_url: str | None = None
    confidence: int = Field(default=50, ge=0, le=100)
    context: str | None = None


class NameEnrichmentRequest(BaseModel):
    query: str = Field(..., min_length=2)
    brand: str | None = None
    manufacturer: str | None = None
    max_candidates: int = Field(default=10, ge=1, le=30)
    max_extracts: int = Field(default=5, ge=0, le=12)
    free_only: bool = True
    run_second_pass: bool = True


class NameEnrichmentResponse(BaseModel):
    query: str
    candidates: list[CandidatePage] = Field(default_factory=list)
    extracted_documents: list[DocumentExtractResponse] = Field(default_factory=list)
    harvested_identifiers: list[HarvestedIdentifier] = Field(default_factory=list)
    second_pass_query: ProductQuery | None = None
    second_pass_result: ExtractionResponse | None = None
    notes: list[str] = Field(default_factory=list)


class CompanyProductCandidate(BaseModel):
    product_name: str
    brand: str | None = None
    manufacturer: str | None = None
    category: str | None = None
    model_number: str | None = None
    sku: str | None = None
    upc_gtin: str | None = None
    source: str
    source_url: str | None = None
    reliability: int = Field(default=50, ge=0, le=100)
    metadata: dict[str, Any] = Field(default_factory=dict)


class CompanyProductSearchRequest(BaseModel):
    company_name: str = Field(..., min_length=2)
    vertical: str | None = "auto"
    max_results_per_source: int = Field(default=10, ge=1, le=50)
    free_only: bool = True


class CompanyProductSearchResponse(BaseModel):
    company_name: str
    products: list[CompanyProductCandidate] = Field(default_factory=list)
    source_runs: list[SourceRun] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)


class ConnectorInfo(BaseModel):
    name: str
    key: str
    free_status: str
    category: SourceCategory
    methods: list[str]
    provides: list[str]
    requires_key: bool = False
    notes: str | None = None
