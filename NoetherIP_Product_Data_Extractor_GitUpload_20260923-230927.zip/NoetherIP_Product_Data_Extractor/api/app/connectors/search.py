from __future__ import annotations

import httpx

from app.connectors.base import BaseConnector, ConnectorResult
from app.models import ConnectorInfo, EvidenceItem, ProductQuery


class GoogleProgrammableSearchConnector(BaseConnector):
    key = "google_pse"
    name = "Google Programmable Search"

    def info(self) -> ConnectorInfo:
        return ConnectorInfo(
            name=self.name,
            key=self.key,
            free_status="Free limited",
            category="manuals",
            methods=["GET customsearch/v1"],
            provides=["manufacturer docs", "manual PDFs", "datasheets", "support pages", "firmware notes"],
            requires_key=True,
            notes="Requires GOOGLE_API_KEY and GOOGLE_CX.",
        )

    async def fetch(self, query: ProductQuery, client: httpx.AsyncClient) -> ConnectorResult:
        if not self.settings.google_api_key or not self.settings.google_cx:
            return self.skipped("GOOGLE_API_KEY and GOOGLE_CX not configured")
        try:
            q = f'{query.search_text()} manual OR datasheet OR "service manual" OR firmware'
            data = (
                await client.get(
                    "https://www.googleapis.com/customsearch/v1",
                    params={
                        "key": self.settings.google_api_key,
                        "cx": self.settings.google_cx,
                        "q": q,
                        "num": min(query.max_results_per_source, 10),
                    },
                )
            ).json()
            evidence = []
            for item in data.get("items", [])[: query.max_results_per_source]:
                category = "datasheet" if "datasheet" in (item.get("title", "") + item.get("snippet", "")).lower() else "manuals"
                evidence.append(
                    EvidenceItem(
                        source=self.name,
                        category=category,
                        title=item.get("title") or "Search result",
                        url=item.get("link"),
                        snippet=item.get("snippet"),
                        reliability=64,
                        metadata=item,
                    )
                )
            return self.ok(evidence, "Manual/datasheet discovery fetched")
        except Exception as exc:
            return self.error(f"Google Programmable Search failed: {exc}")


class ManufacturerDiscoveryConnector(BaseConnector):
    key = "manufacturer_discovery"
    name = "Manufacturer Document Discovery"

    def info(self) -> ConnectorInfo:
        return ConnectorInfo(
            name=self.name,
            key=self.key,
            free_status="Free web",
            category="manuals",
            methods=["manufacturer support URLs", "manual PDF discovery", "datasheet discovery"],
            provides=["official manuals", "datasheets", "support docs", "firmware notes", "changelogs"],
            notes="This connector emits deterministic search URLs. A production crawler should respect robots.txt and ToS.",
        )

    def _manufacturer_domain(self, query: ProductQuery) -> str | None:
        name = (query.manufacturer or query.company_name or query.brand or "").lower()
        domains = {
            "intel": "intel.com",
            "apple": "support.apple.com",
            "dell": "dell.com",
            "hp": "support.hp.com",
            "hewlett": "support.hp.com",
            "lenovo": "support.lenovo.com",
            "netgear": "netgear.com",
            "qualcomm": "qualcomm.com",
            "broadcom": "broadcom.com",
            "mediatek": "mediatek.com",
            "samsung": "samsung.com",
            "sony": "sony.com",
            "lg": "lg.com",
            "asus": "asus.com",
            "acer": "acer.com",
        }
        for key, domain in domains.items():
            if key in name:
                return domain
        return None

    def _has_high_confidence_identifier(self, query: ProductQuery) -> bool:
        return bool(
            query.model_number
            or query.part_number
            or query.product_id
            or query.fcc_id
            or query.upc
            or query.gtin
            or query.sku
            or query.mpn
            or query.asin
            or query.product_url
        )

    async def fetch(self, query: ProductQuery, client: httpx.AsyncClient) -> ConnectorResult:
        base = query.search_text()
        terms = [
            f"{base} datasheet",
            f"{base} user manual pdf",
            f"{base} service manual",
            f"{base} firmware release notes",
        ]
        evidence: list[EvidenceItem] = []
        for term in terms[: query.max_results_per_source]:
            evidence.append(
                EvidenceItem(
                    source=self.name,
                    category="manuals",
                    title=term,
                    url=f"https://www.google.com/search?q={self.q(term)}",
                    snippet="Discovery URL for official manufacturer documentation, manuals, datasheets or firmware notes.",
                    reliability=55,
                    identifiers={"discovery_query": term},
                )
            )

        domain = self._manufacturer_domain(query)
        if domain and self._has_high_confidence_identifier(query):
            official_terms = [
                f"site:{domain} {base} specifications",
                f"site:{domain} {base} manual pdf",
                f"site:{domain} {base} support",
                f"site:{domain} {base} firmware BIOS driver",
            ]
            for term in official_terms[: query.max_results_per_source]:
                evidence.append(
                    EvidenceItem(
                        source=f"{self.name} - Official Site Expansion",
                        category="manuals",
                        title=f"Official source search: {term}",
                        url=f"https://www.google.com/search?q={self.q(term)}",
                        snippet="High-confidence identifier detected, so the workflow narrows discovery to likely official manufacturer pages.",
                        reliability=72,
                        identifiers={"official_discovery_query": term, "manufacturer_domain": domain},
                    )
                )

        return self.ok(evidence[: query.max_results_per_source * 2], "Manufacturer and official discovery URLs prepared")
