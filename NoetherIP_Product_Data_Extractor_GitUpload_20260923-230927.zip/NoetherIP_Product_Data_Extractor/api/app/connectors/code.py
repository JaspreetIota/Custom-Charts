from __future__ import annotations

import httpx

from app.connectors.base import BaseConnector, ConnectorResult
from app.models import ConnectorInfo, EvidenceItem, ProductQuery


class GitHubConnector(BaseConnector):
    key = "github"
    name = "GitHub Code Search"

    def info(self) -> ConnectorInfo:
        return ConnectorInfo(
            name=self.name,
            key=self.key,
            free_status="Free tier",
            category="code",
            methods=["GET /search/repositories", "GET /search/code", "GET /repos/{owner}/{repo}/contents"],
            provides=["drivers", "firmware refs", "board files", "device trees", "SDKs", "PCI/USB IDs"],
            notes="Code search API works best with GITHUB_TOKEN; unauthenticated calls are rate-limited and may not allow code search.",
        )

    async def fetch(self, query: ProductQuery, client: httpx.AsyncClient) -> ConnectorResult:
        headers = {"Accept": "application/vnd.github+json"}
        if self.settings.github_token:
            headers["Authorization"] = f"Bearer {self.settings.github_token}"
        try:
            repo_resp = await client.get(
                "https://api.github.com/search/repositories",
                params={"q": query.search_text(), "per_page": min(query.max_results_per_source, 10)},
                headers=headers,
            )
            repo_data = repo_resp.json()
            evidence = []
            for repo in repo_data.get("items", [])[: query.max_results_per_source]:
                evidence.append(
                    EvidenceItem(
                        source=self.name,
                        category="code",
                        title=repo.get("full_name") or "GitHub repository",
                        url=repo.get("html_url"),
                        snippet=repo.get("description") or "Repository match that may contain firmware, driver or SDK evidence.",
                        reliability=62,
                        identifiers={"repo": repo.get("full_name", "")},
                        metadata={
                            "language": repo.get("language"),
                            "stars": repo.get("stargazers_count"),
                            "updated_at": repo.get("updated_at"),
                        },
                    )
                )
            return self.ok(evidence, "GitHub repository evidence fetched")
        except Exception as exc:
            return self.error(f"GitHub failed: {exc}")
