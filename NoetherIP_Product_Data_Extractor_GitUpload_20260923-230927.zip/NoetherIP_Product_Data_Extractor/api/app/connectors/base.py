from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any
from urllib.parse import quote_plus

import httpx

from app.models import ConnectorInfo, EvidenceItem, ProductQuery, SourceRun
from app.settings import Settings


class ConnectorResult:
    def __init__(self, source: str, evidence: list[EvidenceItem], run: SourceRun):
        self.source = source
        self.evidence = evidence
        self.run = run


class BaseConnector(ABC):
    key: str
    name: str

    def __init__(self, settings: Settings):
        self.settings = settings

    @abstractmethod
    def info(self) -> ConnectorInfo:
        raise NotImplementedError

    @abstractmethod
    async def fetch(self, query: ProductQuery, client: httpx.AsyncClient) -> ConnectorResult:
        raise NotImplementedError

    def skipped(self, message: str) -> ConnectorResult:
        return ConnectorResult(
            self.name,
            [],
            SourceRun(source=self.name, status="skipped", message=message, count=0),
        )

    def error(self, message: str) -> ConnectorResult:
        return ConnectorResult(
            self.name,
            [],
            SourceRun(source=self.name, status="error", message=message[:400], count=0),
        )

    def ok(self, evidence: list[EvidenceItem], message: str = "Fetched") -> ConnectorResult:
        return ConnectorResult(
            self.name,
            evidence,
            SourceRun(source=self.name, status="ok", message=message, count=len(evidence)),
        )

    @staticmethod
    def q(value: str) -> str:
        return quote_plus(value.strip())

    @staticmethod
    def safe_get(data: dict[str, Any], *keys: str) -> Any:
        current: Any = data
        for key in keys:
            if not isinstance(current, dict):
                return None
            current = current.get(key)
        return current
