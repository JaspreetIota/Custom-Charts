from __future__ import annotations

import re

import httpx

from app.connectors.base import BaseConnector, ConnectorResult
from app.models import ConnectorInfo, EvidenceItem, ProductQuery


AUTO_VERTICAL_MARKERS = {"auto", "automatic", "any", "all", "general", "unknown", ""}


class FCCConnector(BaseConnector):
    key = "fcc"
    name = "FCC Equipment Authorization"

    def info(self) -> ConnectorInfo:
        return ConnectorInfo(
            name=self.name,
            key=self.key,
            free_status="Free",
            category="regulatory",
            methods=["getFCCIDList", "FCC EAS open datasets", "FCC ID exhibit search"],
            provides=["FCC ID", "grantee", "product code", "grant date", "manuals", "internal photos", "test reports"],
            notes="Official API can resolve FCC IDs. Exhibit/manual extraction may need FCC page parsing.",
        )

    async def fetch(self, query: ProductQuery, client: httpx.AsyncClient) -> ConnectorResult:
        if not query.fcc_id:
            return self.skipped("No FCC ID provided")
        try:
            fcc_id = re.sub(r"\s+", "", query.fcc_id.upper())
            url = f"https://apps.fcc.gov/OETLabServices/getFCCIDList?fccId={self.q(fcc_id)}"
            resp = await client.get(url, headers={"Accept": "application/json"})
            content_type = resp.headers.get("content-type", "")
            metadata = {"raw": resp.text[:3000]}
            title = f"FCC equipment authorization for {fcc_id}"
            if "json" in content_type:
                metadata = resp.json()
            evidence = [
                EvidenceItem(
                    source=self.name,
                    category="regulatory",
                    title=title,
                    url=url,
                    snippet="FCC authorization lookup. Use FCC/FCCID exhibit pages for manuals, internal photos, labels and test reports.",
                    reliability=90,
                    identifiers={"fcc_id": fcc_id},
                    metadata=metadata,
                ),
                EvidenceItem(
                    source="FCCID.io / fcc.report discovery",
                    category="regulatory",
                    title=f"FCC exhibit discovery pages for {fcc_id}",
                    url=f"https://fccid.io/{fcc_id}",
                    snippet="Third-party FCC mirrors often expose user manuals, internal photos, external photos, labels and test reports.",
                    reliability=78,
                    identifiers={"fcc_id": fcc_id},
                    metadata={"alternate_url": f"https://fcc.report/FCC-ID/{fcc_id}"},
                ),
            ]
            return self.ok(evidence, "FCC authorization evidence prepared")
        except Exception as exc:
            return self.error(f"FCC failed: {exc}")


class OpenFDAConnector(BaseConnector):
    key = "openfda"
    name = "openFDA Device APIs"

    def info(self) -> ConnectorInfo:
        return ConnectorInfo(
            name=self.name,
            key=self.key,
            free_status="Free",
            category="regulatory",
            methods=["GET /device/510k.json", "classification", "recall", "pma", "registration/listing"],
            provides=["medical device names", "applicant", "product code", "classification", "recalls", "registration"],
            notes="Useful for medical device product identity; not detailed internal BOM.",
        )

    async def fetch(self, query: ProductQuery, client: httpx.AsyncClient) -> ConnectorResult:
        vertical = (query.vertical or "").strip().lower()
        if vertical not in AUTO_VERTICAL_MARKERS and "medical" not in vertical:
            return self.skipped("Vertical is not medical device")
        try:
            search = f'device_name:"{query.search_text()}"'
            data = (
                await client.get(
                    "https://api.fda.gov/device/510k.json",
                    params={"search": search, "limit": query.max_results_per_source},
                )
            ).json()
            evidence = []
            for item in data.get("results", [])[: query.max_results_per_source]:
                evidence.append(
                    EvidenceItem(
                        source=self.name,
                        category="regulatory",
                        title=item.get("device_name") or "FDA device record",
                        url="https://open.fda.gov/apis/device/510k/",
                        snippet=f"Applicant: {item.get('applicant')} · Product code: {item.get('product_code')}",
                        reliability=82,
                        identifiers={"k_number": item.get("k_number", ""), "product_code": item.get("product_code", "")},
                        metadata=item,
                    )
                )
            return self.ok(evidence, "openFDA device records fetched")
        except Exception as exc:
            return self.error(f"openFDA failed: {exc}")


class NHTSAConnector(BaseConnector):
    key = "nhtsa"
    name = "NHTSA vPIC"

    def info(self) -> ConnectorInfo:
        return ConnectorInfo(
            name=self.name,
            key=self.key,
            free_status="Free",
            category="metadata",
            methods=["GetModelsForMake", "GetManufacturerDetails", "DecodeVinValues", "GetParts"],
            provides=["vehicle makes", "models", "manufacturer details", "VIN decode", "equipment data"],
            notes="Useful for automotive identity; not chip-level BOM.",
        )

    async def fetch(self, query: ProductQuery, client: httpx.AsyncClient) -> ConnectorResult:
        vertical = (query.vertical or "").strip().lower()
        if vertical not in AUTO_VERTICAL_MARKERS and "auto" not in vertical:
            return self.skipped("Vertical is not automotive")
        try:
            make = query.manufacturer or query.company_name or query.brand or query.search_text().split()[0]
            url = f"https://vpic.nhtsa.dot.gov/api/vehicles/GetModelsForMake/{self.q(make)}?format=json"
            data = (await client.get(url)).json()
            evidence = []
            for item in data.get("Results", [])[: query.max_results_per_source]:
                evidence.append(
                    EvidenceItem(
                        source=self.name,
                        category="metadata",
                        title=f"{item.get('Make_Name')} {item.get('Model_Name')}",
                        url=url,
                        snippet="Vehicle model record from NHTSA vPIC.",
                        reliability=80,
                        identifiers={"make_id": str(item.get("Make_ID") or ""), "model_id": str(item.get("Model_ID") or "")},
                        metadata=item,
                    )
                )
            return self.ok(evidence, "NHTSA vehicle records fetched")
        except Exception as exc:
            return self.error(f"NHTSA failed: {exc}")
