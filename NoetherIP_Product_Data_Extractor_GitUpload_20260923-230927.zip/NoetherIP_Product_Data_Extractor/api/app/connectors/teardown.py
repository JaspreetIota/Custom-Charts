from __future__ import annotations

import csv
import io
import re
import zipfile
from urllib.parse import quote

import httpx

from app.connectors.base import BaseConnector, ConnectorResult
from app.models import ConnectorInfo, EvidenceItem, ProductQuery

OPENWRT_TOH_CACHE: list[dict[str, str]] | None = None


def _clean(value: object) -> str:
    text = str(value or "").strip()
    return "" if text.upper() in {"NULL", "-", "?", "¿", "Â¿"} else text


def _tokens(value: str) -> set[str]:
    return {token for token in re.split(r"[^a-z0-9]+", value.lower()) if token}


def _match_score(row: dict[str, str], query: ProductQuery) -> int:
    query_tokens = _tokens(query.search_text())
    if not query_tokens:
        return 0
    haystack = " ".join(
        _clean(row.get(field, ""))
        for field in ["brand", "model", "version", "forumsearch", "gitsearch", "comments", "page"]
    ).lower()
    row_tokens = _tokens(haystack)
    score = len(query_tokens & row_tokens) * 10
    brand = (query.brand or query.manufacturer or query.company_name or "").lower()
    model = (query.model_number or query.product_name or query.query or "").lower()
    if brand and brand in haystack:
        score += 25
    model_tokens = [token for token in _tokens(model) if token not in {"router", "wifi", "wi", "fi"}]
    if model and model in haystack:
        score += 35
    elif model_tokens and all(token in row_tokens for token in model_tokens):
        score += 20
    return score


async def _openwrt_rows(client: httpx.AsyncClient) -> list[dict[str, str]]:
    global OPENWRT_TOH_CACHE
    if OPENWRT_TOH_CACHE is not None:
        return OPENWRT_TOH_CACHE

    response = await client.get("https://openwrt.org/_media/toh_dump_tab_separated.zip")
    response.raise_for_status()
    with zipfile.ZipFile(io.BytesIO(response.content)) as archive:
        name = next((item for item in archive.namelist() if item.lower().endswith((".csv", ".tsv", ".txt"))), None)
        if not name:
            OPENWRT_TOH_CACHE = []
            return OPENWRT_TOH_CACHE
        text = archive.read(name).decode("utf-8", errors="replace")
    OPENWRT_TOH_CACHE = list(csv.DictReader(io.StringIO(text), delimiter="\t"))
    return OPENWRT_TOH_CACHE


def _ifixit_slug(value: str) -> str:
    return value.strip().replace(" ", "_")


def _ifixit_path(value: str) -> str:
    return quote(value.strip(), safe="")


def _image_url(image: object) -> str | None:
    if not isinstance(image, dict):
        return None
    for key in ["original", "large", "medium", "standard", "thumbnail"]:
        if image.get(key):
            return str(image[key])
    return None


def _spec_value(contents: str, label: str) -> str | None:
    pattern = rf"\*\*\*{re.escape(label)}\*\*\*:?\s*([^\n]+)"
    match = re.search(pattern, contents, flags=re.IGNORECASE)
    return _clean(match.group(1)) if match else None


def _model_numbers(contents: str) -> str | None:
    section = re.search(r"== Identification ==(?P<body>.*?)(?:\n==|\Z)", contents, flags=re.IGNORECASE | re.DOTALL)
    if not section:
        return None
    values = re.findall(r"\*\s*\*\*\*([A-Z0-9-]{3,})\*\*\*", section.group("body"))
    return ", ".join(dict.fromkeys(values)) or None


class IFixitConnector(BaseConnector):
    key = "ifixit"
    name = "iFixit"

    def info(self) -> ConnectorInfo:
        return ConnectorInfo(
            name=self.name,
            key=self.key,
            free_status="Mostly free GET",
            category="teardown",
            methods=["GET /guides", "GET /guides/{guideid}", "GET /categories", "GET /media/images/{id}"],
            provides=["teardown guides", "repair steps", "images", "parts", "device categories"],
            notes="Search support depends on iFixit endpoint behavior; guide/category endpoints are stable.",
        )

    async def _guide_detail(self, guide_id: str, client: httpx.AsyncClient) -> dict:
        if not guide_id:
            return {}
        try:
            response = await client.get(f"https://www.ifixit.com/api/2.0/guides/{self.q(guide_id)}")
            data = response.json()
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    def _extract_guide_assets(self, guide: dict) -> dict:
        steps = guide.get("steps") if isinstance(guide.get("steps"), list) else []
        tools = guide.get("tools") if isinstance(guide.get("tools"), list) else []
        parts = guide.get("parts") if isinstance(guide.get("parts"), list) else []
        images: list[str] = []
        step_summaries: list[str] = []
        for step in steps:
            title = step.get("title") or step.get("summary") or ""
            lines = []
            for line in step.get("lines") or []:
                if isinstance(line, dict) and line.get("text_raw"):
                    lines.append(line.get("text_raw"))
            summary = " ".join([title, " ".join(lines)]).strip()
            if summary:
                step_summaries.append(summary[:600])
            for media in step.get("media") or []:
                if isinstance(media, dict):
                    for candidate in [media.get("standard"), media.get("large"), media.get("thumbnail")]:
                        if candidate and candidate not in images:
                            images.append(candidate)
        return {
            "guide_id": str(guide.get("guideid") or guide.get("guideId") or guide.get("id") or ""),
            "difficulty": guide.get("difficulty"),
            "time_required": guide.get("time_required") or guide.get("timeRequired"),
            "step_count": len(steps),
            "guide_steps": step_summaries[:20],
            "image_count": len(images),
            "images": images[:50],
            "tools": [tool.get("text") or tool.get("name") or tool for tool in tools][:30],
            "parts": [part.get("text") or part.get("name") or part for part in parts][:30],
        }

    async def fetch(self, query: ProductQuery, client: httpx.AsyncClient) -> ConnectorResult:
        try:
            evidence = []
            search_terms = [
                query.product_name,
                query.model_number,
                query.query,
                query.search_text(),
            ]
            search_term = next((term for term in search_terms if term and term.strip()), query.search_text())
            search = (await client.get(f"https://www.ifixit.com/api/2.0/search/{_ifixit_path(search_term)}")).json()
            if isinstance(search, dict) and not search.get("results") and search_term != query.search_text():
                search = (await client.get(f"https://www.ifixit.com/api/2.0/search/{_ifixit_path(query.search_text())}")).json()
            results = search.get("results", []) if isinstance(search, dict) else []
            categories = [
                item for item in results
                if item.get("namespace") == "CATEGORY" or "/Device/" in str(item.get("url", ""))
            ]
            exact_categories = [
                item for item in categories
                if str(item.get("title") or item.get("display_title") or "").strip().lower() == search_term.strip().lower()
            ]
            if exact_categories:
                categories = exact_categories
            guides = [
                item for item in results
                if item.get("dataType") == "guide" or "/Guide/" in str(item.get("url", "")) or "/Teardown/" in str(item.get("url", ""))
            ]
            seeded_guides: list[dict] = []

            for category in categories[:2]:
                title = category.get("title") or category.get("display_title") or query.search_text()
                slug = category.get("url", "").rstrip("/").split("/")[-1] or _ifixit_slug(title)
                detail = (await client.get(f"https://www.ifixit.com/api/2.0/categories/{_ifixit_path(slug)}")).json()
                contents = str(detail.get("contents_raw") or "")
                category_guides = detail.get("guides") if isinstance(detail.get("guides"), list) else []
                teardown_guides = [guide for guide in category_guides if guide.get("type") == "teardown"]
                first_guides = teardown_guides[:2] + [guide for guide in category_guides if guide not in teardown_guides][:3]
                specs = {
                    "processor": _spec_value(contents, "Processor"),
                    "memory": _spec_value(contents, "RAM"),
                    "storage": _spec_value(contents, "Storage"),
                    "power": _spec_value(contents, "Battery"),
                    "dimensions": _spec_value(contents, "Dimensions"),
                    "os_support": _spec_value(contents, "Operating System"),
                }
                specs = {key: value for key, value in specs.items() if value}
                model_numbers = _model_numbers(contents)
                images = [_image_url(detail.get("image"))] if _image_url(detail.get("image")) else []
                images.extend(_image_url(guide.get("image")) for guide in first_guides if _image_url(guide.get("image")))
                evidence.append(
                    EvidenceItem(
                        source=self.name,
                        category="teardown",
                        title=f"iFixit device page: {title}",
                        url=detail.get("url") or category.get("url") or f"https://www.ifixit.com/Device/{slug}",
                        snippet=detail.get("description") or category.get("summary") or f"{len(category_guides)} iFixit guides found.",
                        reliability=86,
                        identifiers={"model": model_numbers or "", "device": title},
                        metadata={
                            "device": detail,
                            "technical_specs": specs,
                            "extracted_assets": {
                                "guide_steps": [guide.get("title") for guide in first_guides if guide.get("title")],
                                "image_count": len([image for image in images if image]),
                                "images": [image for image in dict.fromkeys(images) if image],
                                "tools": detail.get("tools") or [],
                                "parts": detail.get("parts") or [],
                                "repairability": re.search(r"\[repairability\|(\d+)\]", contents or "").group(1)
                                if re.search(r"\[repairability\|(\d+)\]", contents or "")
                                else None,
                            },
                            "guide_count": len(category_guides),
                        },
                    )
                )
                seeded_guides.extend(first_guides[: query.max_results_per_source])

            seen_guides: set[str] = set()
            if categories:
                category_names = {str(category.get("title") or category.get("display_title") or "").strip().lower() for category in categories}
                guides = [
                    guide for guide in guides
                    if str(guide.get("category") or "").strip().lower() in category_names
                    or any(name.replace(" ", "+") in str(guide.get("url", "")).lower() for name in category_names)
                ]
            guides = seeded_guides + guides
            for guide in guides[: query.max_results_per_source]:
                guide_id = str(guide.get("guideid") or guide.get("guideId") or guide.get("id") or "")
                guide_url = guide.get("url") or (f"https://www.ifixit.com/Guide/{guide_id}" if guide_id else None)
                guide_key = guide_id or str(guide_url)
                if not guide_key or guide_key in seen_guides:
                    continue
                seen_guides.add(guide_key)
                detail = await self._guide_detail(guide_id, client) if guide_id else {}
                merged = {**guide, **detail} if detail else guide
                assets = self._extract_guide_assets(merged)
                title = guide.get("title") or guide.get("display_title") or "iFixit guide"
                is_teardown = "teardown" in str(guide.get("type") or guide_url or title).lower()
                evidence.append(
                    EvidenceItem(
                        source=self.name,
                        category="teardown",
                        title=title,
                        url=guide_url,
                        snippet=guide.get("summary") or f"iFixit guide with {assets.get('step_count', 0)} steps and {assets.get('image_count', 0)} images.",
                        reliability=88 if is_teardown else 82,
                        identifiers={"guide_id": guide_id},
                        metadata={**merged, "extracted_assets": assets, "is_teardown": is_teardown},
                    )
                )
            if not evidence:
                term = f"{query.search_text()} site:ifixit.com/Guide OR site:ifixit.com/Device"
                evidence.append(
                    EvidenceItem(
                        source=f"{self.name} - Web Discovery",
                        category="teardown",
                        title=f"iFixit teardown/device discovery for {query.search_text()}",
                        url=f"https://www.google.com/search?q={self.q(term)}",
                        snippet="No iFixit API guide was returned, so this free fallback prepares a targeted iFixit web discovery query.",
                        reliability=58,
                        identifiers={"discovery_query": term},
                        metadata={"discovery_only": True},
                    )
                )
            return self.ok(evidence, "iFixit guides fetched")
        except Exception as exc:
            return self.error(f"iFixit failed: {exc}")


class OpenWrtConnector(BaseConnector):
    key = "openwrt"
    name = "OpenWrt Table of Hardware"

    def info(self) -> ConnectorInfo:
        return ConnectorInfo(
            name=self.name,
            key=self.key,
            free_status="Free",
            category="teardown",
            methods=["Hardware JSON dump", "Table of Hardware filters", "Device pages"],
            provides=["brand", "model", "SoC", "CPU", "flash", "RAM", "Wi-Fi chipset", "FCC ID"],
            notes="Excellent for routers/networking. JSON URL can change, so connector tries known endpoints.",
        )

    async def fetch(self, query: ProductQuery, client: httpx.AsyncClient) -> ConnectorResult:
        try:
            rows = await _openwrt_rows(client)
            ranked = sorted(
                ((row, _match_score(row, query)) for row in rows),
                key=lambda item: item[1],
                reverse=True,
            )
            matches = [(row, score) for row, score in ranked if score >= 20][: query.max_results_per_source]
            evidence: list[EvidenceItem] = []
            for row, score in matches:
                brand = _clean(row.get("brand"))
                model = _clean(row.get("model"))
                version = _clean(row.get("version"))
                page = _clean(row.get("page") or row.get("devicepage"))
                device_url = f"https://openwrt.org/{page.replace(':', '/')}" if page else f"https://toh.openwrt.org/?view=hardware&q={self.q(query.search_text())}"
                fcc_url = _clean(row.get("fccid"))
                fcc_parts = fcc_url.rstrip("/").split("/")[-2:] if "fcc.io/" in fcc_url else []
                fcc_value = "".join(fcc_parts) if fcc_parts else fcc_url
                ethernet = ", ".join(
                    value for value in [
                        f"{_clean(row.get('ethernet100mports'))}x100M" if _clean(row.get("ethernet100mports")) else "",
                        f"{_clean(row.get('ethernetgbitports') or row.get('ethernet1gports'))}x1G" if _clean(row.get("ethernetgbitports") or row.get("ethernet1gports")) else "",
                        f"{_clean(row.get('ethernet2_5gports'))}x2.5G" if _clean(row.get("ethernet2_5gports")) else "",
                    ]
                    if value
                )
                specs = {
                    "processor": _clean(row.get("cpu")),
                    "soc": _clean(row.get("target")),
                    "chipset": _clean(row.get("switch")),
                    "memory": f"{_clean(row.get('rammb'))} MB RAM" if _clean(row.get("rammb")) else "",
                    "storage": f"{_clean(row.get('flashmb'))} MB flash" if _clean(row.get("flashmb")) else "",
                    "wireless_chip": _clean(row.get("wlanhardware")),
                    "ports": ", ".join(value for value in [ethernet, _clean(row.get("usbports"))] if value),
                    "power": _clean(row.get("powersupply")),
                    "os_support": _clean(row.get("supportedcurrentrel") or row.get("supportedsincerel")),
                }
                specs = {key: value for key, value in specs.items() if value}
                docs = {
                    "support_url": _clean(row.get("oemdevicehomepageurl")),
                    "firmware_url": _clean(row.get("firmwareopenwrtinstallurl") or row.get("firmwareopenwrtupgradeurl") or row.get("firmwareoemstockurl")),
                }
                docs = {key: value for key, value in docs.items() if value}
                picture = _clean(row.get("picture"))
                images = [f"https://openwrt.org/_media/{picture.replace(':', '/')}" if picture else ""]
                title = " ".join(value for value in [brand, model, version] if value)
                evidence.append(
                    EvidenceItem(
                        source=self.name,
                        category="teardown",
                        title=f"OpenWrt hardware record: {title}",
                        url=device_url,
                        snippet=f"CPU: {specs.get('processor', 'unknown')}; RAM: {specs.get('memory', 'unknown')}; flash: {specs.get('storage', 'unknown')}; WLAN: {specs.get('wireless_chip', 'unknown')}.",
                        reliability=min(92, 72 + score),
                        identifiers={
                            "brand": brand,
                            "manufacturer": brand,
                            "model": model,
                            "fcc_id": fcc_value,
                        },
                        metadata={
                            "row": row,
                            "technical_specs": specs,
                            "official_docs": docs,
                            "regulatory": {"fcc_grant": fcc_url} if fcc_url else {},
                            "extracted_assets": {
                                "images": [image for image in images if image],
                                "components_seen": [
                                    value for value in [specs.get("processor"), specs.get("chipset"), specs.get("wireless_chip")] if value
                                ],
                                "board_markings": _clean(row.get("comments")) or "",
                            },
                            "match_score": score,
                        },
                    )
                )
            if evidence:
                return self.ok(evidence, "OpenWrt hardware records fetched")

            search_url = f"https://toh.openwrt.org/?view=hardware&q={self.q(query.search_text())}"
            return self.ok(
                [
                    EvidenceItem(
                        source=self.name,
                        category="teardown",
                        title=f"OpenWrt hardware lookup for {query.search_text()}",
                        url=search_url,
                        snippet="No matching OpenWrt hardware row was found; use the table search for manual review.",
                        reliability=55,
                        identifiers={"query": query.search_text()},
                        metadata={"discovery_only": True},
                    )
                ],
                "OpenWrt lookup prepared",
            )
        except Exception as exc:
            return self.error(f"OpenWrt failed: {exc}")
