from __future__ import annotations

import httpx

from app.connectors.base import BaseConnector, ConnectorResult
from app.models import ConnectorInfo, EvidenceItem, ProductQuery


class WaybackConnector(BaseConnector):
    key = "wayback"
    name = "Wayback Machine CDX"

    def info(self) -> ConnectorInfo:
        return ConnectorInfo(
            name=self.name,
            key=self.key,
            free_status="Free",
            category="history",
            methods=["GET /cdx/search/cdx", "availability API"],
            provides=["historical pages", "first-seen captures", "old support docs", "deleted manuals"],
            notes="Capture dates support launch/discontinuation inference, but are not product launch dates by themselves.",
        )

    async def fetch(self, query: ProductQuery, client: httpx.AsyncClient) -> ConnectorResult:
        if not query.product_url:
            return self.skipped("No product_url provided")
        try:
            data = (
                await client.get(
                    "https://web.archive.org/cdx/search/cdx",
                    params={
                        "url": query.product_url,
                        "output": "json",
                        "fl": "timestamp,original,statuscode,mimetype,digest",
                        "filter": "statuscode:200",
                        "collapse": "digest",
                        "limit": query.max_results_per_source,
                    },
                )
            ).json()
            rows = data[1:] if isinstance(data, list) and data else []
            evidence = []
            for row in rows:
                timestamp, original, status, mimetype, digest = (row + ["", "", "", "", ""])[:5]
                archive_url = f"https://web.archive.org/web/{timestamp}/{original}"
                evidence.append(
                    EvidenceItem(
                        source=self.name,
                        category="history",
                        title=f"Archived capture {timestamp}",
                        url=archive_url,
                        snippet=f"Historical capture of product/support page. MIME: {mimetype}",
                        reliability=70,
                        identifiers={"timestamp": timestamp, "digest": digest, "status": status},
                        metadata={"original": original, "mimetype": mimetype},
                    )
                )
            return self.ok(evidence, "Wayback captures fetched")
        except Exception as exc:
            return self.error(f"Wayback failed: {exc}")
