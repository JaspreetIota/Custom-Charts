from __future__ import annotations

import httpx

from app.connectors.base import BaseConnector, ConnectorResult
from app.models import ConnectorInfo, EvidenceItem, ProductQuery


class UPCItemDBConnector(BaseConnector):
    key = "upcitemdb"
    name = "UPCitemdb"

    def info(self) -> ConnectorInfo:
        return ConnectorInfo(
            name=self.name,
            key=self.key,
            free_status="Free limited",
            category="metadata",
            methods=["GET /prod/trial/lookup", "GET /prod/trial/search"],
            provides=["UPC/EAN lookup", "title", "brand", "category", "images", "offers"],
            notes="Trial endpoint is useful for MVP and low-volume tests.",
        )

    async def fetch(self, query: ProductQuery, client: httpx.AsyncClient) -> ConnectorResult:
        try:
            headers = {"User-Agent": self.settings.upcitemdb_user_agent}
            url = (
                f"https://api.upcitemdb.com/prod/trial/lookup?upc={self.q(query.upc or query.gtin)}"
                if query.upc or query.gtin
                else f"https://api.upcitemdb.com/prod/trial/search?s={self.q(query.search_text())}&match_mode=0&type=product"
            )
            data = (await client.get(url, headers=headers)).json()
            items = data.get("items") or []
            evidence = []
            for item in items[: query.max_results_per_source]:
                evidence.append(
                    EvidenceItem(
                        source=self.name,
                        category="metadata",
                        title=item.get("title") or item.get("description") or "UPC product match",
                        url=(item.get("offers") or [{}])[0].get("link"),
                        snippet=item.get("description") or item.get("brand"),
                        reliability=68,
                        identifiers={
                            "upc": str(item.get("upc") or ""),
                            "ean": str(item.get("ean") or ""),
                            "brand": str(item.get("brand") or ""),
                        },
                        metadata=item,
                    )
                )
            return self.ok(evidence, "UPC/product records fetched")
        except Exception as exc:
            return self.error(f"UPCitemdb failed: {exc}")


class WikidataConnector(BaseConnector):
    key = "wikidata"
    name = "Wikidata"

    def info(self) -> ConnectorInfo:
        return ConnectorInfo(
            name=self.name,
            key=self.key,
            free_status="Free",
            category="entity",
            methods=["SPARQL SELECT query"],
            provides=["entity identity", "manufacturer", "release date", "official website", "product categories"],
            notes="Useful enrichment source; coverage varies by product.",
        )

    async def fetch(self, query: ProductQuery, client: httpx.AsyncClient) -> ConnectorResult:
        try:
            term = query.search_text().replace('"', "")
            sparql = f"""
            SELECT ?item ?itemLabel ?manufacturerLabel ?website WHERE {{
              ?item rdfs:label ?itemLabel.
              FILTER(LANG(?itemLabel) = "en")
              FILTER(CONTAINS(LCASE(?itemLabel), LCASE("{term}")))
              OPTIONAL {{ ?item wdt:P176 ?manufacturer. }}
              OPTIONAL {{ ?item wdt:P856 ?website. }}
              SERVICE wikibase:label {{ bd:serviceParam wikibase:language "en". }}
            }} LIMIT {query.max_results_per_source}
            """
            resp = await client.get(
                "https://query.wikidata.org/sparql",
                params={"query": sparql, "format": "json"},
                headers={"User-Agent": "NoetherIPProductExtractor/0.1"},
            )
            data = resp.json()
            evidence = []
            for row in data.get("results", {}).get("bindings", []):
                item = row.get("item", {}).get("value")
                label = row.get("itemLabel", {}).get("value", "Wikidata entity")
                manufacturer = row.get("manufacturerLabel", {}).get("value", "")
                website = row.get("website", {}).get("value")
                evidence.append(
                    EvidenceItem(
                        source=self.name,
                        category="entity",
                        title=label,
                        url=item,
                        snippet=f"Manufacturer: {manufacturer}" if manufacturer else "Wikidata entity match",
                        reliability=58,
                        identifiers={"manufacturer": manufacturer, "website": website or ""},
                        metadata=row,
                    )
                )
            return self.ok(evidence, "Entity records fetched")
        except Exception as exc:
            return self.error(f"Wikidata failed: {exc}")


class BestBuyConnector(BaseConnector):
    key = "bestbuy"
    name = "Best Buy Products API"

    def info(self) -> ConnectorInfo:
        return ConnectorInfo(
            name=self.name,
            key=self.key,
            free_status="Free key",
            category="metadata",
            methods=["GET /v1/products(search=...)", "Products API", "Categories API"],
            provides=["SKU", "product title", "specs", "pricing", "availability", "descriptions", "images"],
            requires_key=True,
            notes="Requires BESTBUY_API_KEY.",
        )

    async def fetch(self, query: ProductQuery, client: httpx.AsyncClient) -> ConnectorResult:
        if not self.settings.bestbuy_api_key:
            return self.skipped("BESTBUY_API_KEY not configured")
        try:
            search = self.q(query.search_text())
            url = (
                "https://api.bestbuy.com/v1/products"
                f"((search={search}))?apiKey={self.settings.bestbuy_api_key}&format=json&pageSize={query.max_results_per_source}"
            )
            data = (await client.get(url)).json()
            evidence = []
            for p in data.get("products", [])[: query.max_results_per_source]:
                evidence.append(
                    EvidenceItem(
                        source=self.name,
                        category="metadata",
                        title=p.get("name") or "Best Buy product",
                        url=p.get("url"),
                        snippet=p.get("shortDescription") or p.get("longDescription"),
                        reliability=72,
                        identifiers={"sku": str(p.get("sku") or ""), "model": str(p.get("modelNumber") or "")},
                        metadata=p,
                    )
                )
            return self.ok(evidence, "Best Buy products fetched")
        except Exception as exc:
            return self.error(f"Best Buy failed: {exc}")
