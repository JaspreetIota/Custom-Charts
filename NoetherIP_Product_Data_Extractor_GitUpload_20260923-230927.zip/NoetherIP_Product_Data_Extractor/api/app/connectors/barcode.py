from __future__ import annotations

import httpx

from app.connectors.base import BaseConnector, ConnectorResult
from app.models import ConnectorInfo, EvidenceItem, ProductQuery


class BarcodeLookupConnector(BaseConnector):
    key = "barcode_lookup"
    name = "Barcode Lookup API"

    def info(self) -> ConnectorInfo:
        return ConnectorInfo(
            name=self.name,
            key=self.key,
            free_status="Trial / paid",
            category="metadata",
            methods=["barcode query", "partial barcode", "batch barcode", "MPN/ASIN/title/brand search"],
            provides=["product name", "category", "description", "images", "retail pricing", "brand"],
            requires_key=True,
            notes="Optional enrichment. Requires BARCODE_LOOKUP_KEY.",
        )

    async def fetch(self, query: ProductQuery, client: httpx.AsyncClient) -> ConnectorResult:
        if not self.settings.barcode_lookup_key:
            return self.skipped("BARCODE_LOOKUP_KEY not configured")
        try:
            params = {"key": self.settings.barcode_lookup_key, "formatted": "y"}
            if query.upc or query.gtin:
                params["barcode"] = query.upc or query.gtin
            else:
                params["title"] = query.search_text()
            data = (await client.get("https://api.barcodelookup.com/v3/products", params=params)).json()
            products = data.get("products") or []
            evidence = []
            for product in products[: query.max_results_per_source]:
                evidence.append(
                    EvidenceItem(
                        source=self.name,
                        category="metadata",
                        title=product.get("title") or "Barcode product match",
                        url=product.get("stores", [{}])[0].get("store_product_url") if product.get("stores") else None,
                        snippet=product.get("description") or product.get("brand"),
                        reliability=68,
                        identifiers={
                            "barcode_number": product.get("barcode_number", ""),
                            "mpn": product.get("mpn", ""),
                            "brand": product.get("brand", ""),
                        },
                        metadata=product,
                    )
                )
            return self.ok(evidence, "Barcode Lookup products fetched")
        except Exception as exc:
            return self.error(f"Barcode Lookup failed: {exc}")
