from __future__ import annotations

import asyncio
from collections import Counter

import httpx

from app.coverage import build_coverage_report, build_data_profile
from app.connectors.barcode import BarcodeLookupConnector
from app.connectors.base import BaseConnector, ConnectorResult
from app.connectors.code import GitHubConnector
from app.connectors.history import WaybackConnector
from app.connectors.metadata import BestBuyConnector, UPCItemDBConnector, WikidataConnector
from app.connectors.regulatory import FCCConnector, NHTSAConnector, OpenFDAConnector
from app.connectors.search import GoogleProgrammableSearchConnector, ManufacturerDiscoveryConnector
from app.connectors.teardown import IFixitConnector, OpenWrtConnector
from app.models import ConnectorInfo, EvidenceItem, ExtractionResponse, NormalizedProduct, ProductQuery, SourceRun
from app.settings import Settings


AUTO_VERTICAL_MARKERS = {"auto", "automatic", "any", "all", "general", "unknown", ""}
AUTOMOTIVE_TERMS = {
    "toyota",
    "honda",
    "ford",
    "chevrolet",
    "tesla",
    "bmw",
    "mercedes",
    "audi",
    "hyundai",
    "kia",
    "nissan",
    "camry",
    "corolla",
    "civic",
    "accord",
    "vehicle",
    "automotive",
    "car",
    "truck",
    "vin",
}
MEDICAL_TERMS = {
    "medtronic",
    "abbott",
    "boston scientific",
    "pacemaker",
    "defibrillator",
    "stent",
    "catheter",
    "implant",
    "medical",
    "medical device",
    "fda",
    "510k",
}


def build_connectors(settings: Settings) -> list[BaseConnector]:
    return [
        FCCConnector(settings),
        IFixitConnector(settings),
        OpenWrtConnector(settings),
        GitHubConnector(settings),
        WaybackConnector(settings),
        UPCItemDBConnector(settings),
        BestBuyConnector(settings),
        BarcodeLookupConnector(settings),
        GoogleProgrammableSearchConnector(settings),
        ManufacturerDiscoveryConnector(settings),
        NHTSAConnector(settings),
        OpenFDAConnector(settings),
        WikidataConnector(settings),
    ]


class ProductExtractionService:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.connectors = build_connectors(settings)

    def connector_info(self) -> list[ConnectorInfo]:
        return [connector.info() for connector in self.connectors]

    def _is_auto_vertical(self, query: ProductQuery) -> bool:
        return (query.vertical or "").strip().lower() in AUTO_VERTICAL_MARKERS

    def _infer_verticals(self, query: ProductQuery) -> set[str]:
        if not self._is_auto_vertical(query):
            return {query.vertical.lower() if query.vertical else "general"}
        text = query.search_text().lower()
        inferred = {"general"}
        if any(term in text for term in AUTOMOTIVE_TERMS):
            inferred.add("automotive")
        if any(term in text for term in MEDICAL_TERMS):
            inferred.add("medical device")
        return inferred

    def _connector_allowed(self, connector: BaseConnector, query: ProductQuery) -> bool:
        if not self._is_auto_vertical(query):
            return True
        inferred = self._infer_verticals(query)
        if connector.key == "nhtsa":
            return "automotive" in inferred
        if connector.key == "openfda":
            return "medical device" in inferred
        return True

    async def extract(self, query: ProductQuery) -> ExtractionResponse:
        selected = set(query.include_sources or [])
        connectors = [c for c in self.connectors if not selected or c.key in selected or c.name in selected]
        if query.free_only and not selected:
            connectors = [c for c in connectors if not c.info().requires_key]
        connectors = [c for c in connectors if selected or self._connector_allowed(c, query)]
        async with httpx.AsyncClient(timeout=self.settings.request_timeout_seconds, follow_redirects=True) as client:
            results = await asyncio.gather(*(self._safe_fetch(c, query, client) for c in connectors))

        evidence: list[EvidenceItem] = []
        runs: list[SourceRun] = []
        for result in results:
            evidence.extend(result.evidence)
            runs.append(result.run)

        product = self._normalize_product(query, evidence)
        data_profile = build_data_profile(product, evidence, runs)
        coverage = build_coverage_report(data_profile)
        return ExtractionResponse(
            product=product,
            data_profile=data_profile,
            coverage=coverage,
            evidence=evidence,
            source_runs=runs,
            next_steps=[
                "Review low-confidence evidence before using it for legal or licensing decisions.",
                "Use free document extraction on selected official/manual/datasheet/support URLs before considering paid APIs.",
                "Download PDFs/images from evidence URLs and store their hashes in object storage.",
                "Chunk manuals, FCC exhibits, teardown steps and firmware files for embeddings.",
                "Use this normalized product record later for patent-to-product or component cross-linking.",
            ],
        )

    async def _safe_fetch(self, connector: BaseConnector, query: ProductQuery, client: httpx.AsyncClient) -> ConnectorResult:
        try:
            return await connector.fetch(query, client)
        except Exception as exc:
            return connector.error(f"Unhandled connector error: {exc}")

    def _normalize_product(self, query: ProductQuery, evidence: list[EvidenceItem]) -> NormalizedProduct:
        identifiers: Counter[str] = Counter()
        aliases: set[str] = set()
        manufacturer = query.manufacturer or query.company_name or query.brand
        inferred_verticals = self._infer_verticals(query)
        category = None if self._is_auto_vertical(query) else query.vertical
        if not category:
            category = next((value for value in ["automotive", "medical device"] if value in inferred_verticals), "general")
        model_number = query.model_number
        product_name = query.product_name or query.query

        for item in evidence:
            for key, value in item.identifiers.items():
                if value:
                    identifiers[f"{key}:{value}"] += 1
                    if key in {"brand", "manufacturer"} and not manufacturer:
                        manufacturer = value
                    if key in {"model", "mpn"} and not model_number:
                        model_number = value
                    if key == "device" and not product_name:
                        product_name = value
            if item.title and len(item.title) < 120:
                aliases.add(item.title)
            if not category and item.category:
                category = item.category

        ok_sources = {e.source for e in evidence}
        reliability = sum(e.reliability for e in evidence) / len(evidence) if evidence else 0
        id_bonus = min(20, len(identifiers) * 3)
        confidence = min(95, int((reliability * 0.75) + id_bonus)) if evidence else 0

        return NormalizedProduct(
            query=query.query,
            brand=query.brand or manufacturer,
            manufacturer=manufacturer,
            model_number=model_number,
            product_id=query.product_id,
            product_name=product_name,
            part_number=query.part_number,
            serial_number=query.serial_number,
            sku=query.sku,
            asin=query.asin,
            mpn=query.mpn,
            board_marking=query.board_marking,
            chip_marking=query.chip_marking,
            device_id=query.device_id,
            category=category,
            fcc_id=query.fcc_id,
            upc_gtin=query.upc or query.gtin,
            product_url=query.product_url,
            input_identifiers=query.identifier_map(),
            aliases=sorted(list(aliases))[:12],
            source_count=len(ok_sources),
            confidence=confidence,
        )
