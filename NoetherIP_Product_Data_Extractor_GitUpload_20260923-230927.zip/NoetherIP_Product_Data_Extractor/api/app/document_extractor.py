from __future__ import annotations

import re
from io import BytesIO
from hashlib import sha256
from html import unescape
from urllib.parse import urljoin

import httpx

from app.models import DocumentExtractRequest, DocumentExtractResponse, ProductDataProfile


TAG_RE = re.compile(r"<[^>]+>")
SPACE_RE = re.compile(r"\s+")

try:
    from pypdf import PdfReader
except Exception:  # pragma: no cover - optional dependency
    PdfReader = None


def _clean_text(value: str) -> str:
    value = re.sub(r"(?is)<(script|style|noscript).*?</\1>", " ", value)
    value = TAG_RE.sub(" ", value)
    value = unescape(value)
    return SPACE_RE.sub(" ", value).strip()


def _first_match(pattern: str, text: str) -> str | None:
    match = re.search(pattern, text, re.IGNORECASE)
    if not match:
        return None
    for group in match.groups():
        if group:
            return group.strip()
    return match.group(0).strip()


def _title(html: str) -> str | None:
    return _first_match(r"<title[^>]*>(.*?)</title>", html)


def _meta(html: str, name: str) -> str | None:
    patterns = [
        rf'<meta[^>]+name=["\']{re.escape(name)}["\'][^>]+content=["\']([^"\']+)["\']',
        rf'<meta[^>]+property=["\']{re.escape(name)}["\'][^>]+content=["\']([^"\']+)["\']',
    ]
    for pattern in patterns:
        value = _first_match(pattern, html)
        if value:
            return unescape(value)
    return None


def _links(html: str, base_url: str) -> list[str]:
    found: list[str] = []
    for href in re.findall(r'href=["\']([^"\']+)["\']', html, flags=re.IGNORECASE):
        if href.startswith("#") or href.lower().startswith(("javascript:", "mailto:", "tel:")):
            continue
        url = urljoin(base_url, href)
        lowered = url.lower()
        if any(token in lowered for token in ["pdf", "manual", "datasheet", "spec", "driver", "firmware", "bios", "support"]):
            if url not in found:
                found.append(url)
    return found[:30]


def _images(html: str, base_url: str) -> list[str]:
    found: list[str] = []
    patterns = [
        r'<img[^>]+src=["\']([^"\']+)["\']',
        r'<meta[^>]+property=["\']og:image["\'][^>]+content=["\']([^"\']+)["\']',
    ]
    for pattern in patterns:
        for src in re.findall(pattern, html, flags=re.IGNORECASE):
            if src.startswith("data:"):
                continue
            url = urljoin(base_url, src)
            if url not in found:
                found.append(url)
    return found[:50]


def _classify_links(links: list[str]) -> dict[str, list[str]]:
    classified: dict[str, list[str]] = {
        "pdfs": [],
        "manuals": [],
        "datasheets": [],
        "specifications": [],
        "drivers": [],
        "firmware": [],
        "bios": [],
        "support": [],
    }
    for link in links:
        lowered = link.lower()
        if lowered.endswith(".pdf") or ".pdf" in lowered:
            classified["pdfs"].append(link)
        if "manual" in lowered:
            classified["manuals"].append(link)
        if "datasheet" in lowered or "data-sheet" in lowered:
            classified["datasheets"].append(link)
        if "spec" in lowered:
            classified["specifications"].append(link)
        if "driver" in lowered:
            classified["drivers"].append(link)
        if "firmware" in lowered:
            classified["firmware"].append(link)
        if "bios" in lowered or "uefi" in lowered:
            classified["bios"].append(link)
        if "support" in lowered:
            classified["support"].append(link)
    return {key: value for key, value in classified.items() if value}


def _pdf_text(content: bytes, max_pages: int = 8) -> tuple[str, dict[str, str]]:
    if PdfReader is None:
        return "", {"pdf_parser": "pypdf_not_installed"}
    try:
        reader = PdfReader(BytesIO(content))
        chunks: list[str] = []
        for page in reader.pages[:max_pages]:
            chunks.append(page.extract_text() or "")
        metadata = {str(k).lstrip("/"): str(v) for k, v in (reader.metadata or {}).items()}
        metadata["page_count"] = str(len(reader.pages))
        metadata["parsed_pages"] = str(min(len(reader.pages), max_pages))
        return _clean_text(" ".join(chunks)), metadata
    except Exception as exc:
        return "", {"pdf_parser_error": str(exc)[:240]}


def _extract_fields(text: str) -> dict[str, str]:
    fields: dict[str, str] = {}
    patterns = {
        "model_number": r"\b(?:model(?:\s+number)?|model no\.?)\b\s*[:#-]\s*([A-Z0-9][A-Z0-9._/-]{2,})",
        "part_number": r"\b(?:part(?:\s+number)?|p/n)\b\s*[:#-]\s*([A-Z0-9][A-Z0-9._/-]{2,})",
        "fcc_id": r"\bFCC\s*ID\b\s*[:#-]?\s*([A-Z0-9-]{4,})",
        "bios": r"\b(?:BIOS|UEFI)\s*(?:version)?\b\s*[:#-]\s*([A-Z0-9._/-]{2,})",
        "manual": r"\b((?:user|service|technical)\s+manual)\b",
        "datasheet": r"\b(datasheet|data\s+sheet)\b",
        "gpu_die": r"\b(AD10[0-9])\b",
        "cuda_cores": r"(?:\bCUDA\s+Cores\b|\bNVIDIA\s+CUDA\s+Cores\b)\s*[:#-]?\s*([0-9]{4,5})|\b([0-9]{4,5})\s+CUDA\s+Cores\b",
        "memory_size": r"\b([0-9]{1,3}\s*GB)\s+(?:GDDR|DDR|LPDDR)",
        "memory_type": r"\b(GDDR6X|GDDR6|GDDR7|DDR5|LPDDR5X?)\b",
        "vrm_controller": r"\b(uP[0-9]{4,}[A-Z]?)\b",
        "memory_chip_marking": r"\b((?:MT|D8)[A-Z0-9]{3,}[A-Z0-9._/-]*)\b",
        "drmos_part": r"\b(SIC[0-9]{3,}[A-Z]?)\b",
    }
    for key, pattern in patterns.items():
        value = _first_match(pattern, text)
        if value:
            fields[key] = value
    return fields


def _target_groups(url: str, document_type: str, text: str, fields: dict[str, str], links: list[str]) -> ProductDataProfile:
    lowered = " ".join([url, document_type, text[:5000], " ".join(links)]).lower()
    profile = ProductDataProfile()

    profile.product_identity.update(
        {
            "model_number": fields.get("model_number"),
            "part_number": fields.get("part_number"),
            "fcc_id": fields.get("fcc_id"),
        }
    )

    if document_type != "teardown":
        if document_type == "datasheet" or "datasheet" in lowered or "specification" in lowered or "specifications" in lowered:
            profile.official_docs["datasheet_url"] = url
        if document_type == "manual" or "manual" in lowered:
            profile.official_docs["manual_url"] = url
        if document_type == "service_manual" or "service manual" in lowered:
            profile.official_docs["service_manual_url"] = url
        if document_type == "firmware_release_notes" or "firmware" in lowered or "release notes" in lowered:
            profile.official_docs["firmware_url"] = url
        if "driver" in lowered or "drivers" in lowered:
            profile.official_docs["driver_url"] = url
        if "bios" in lowered or "uefi" in lowered:
            profile.official_docs["bios_url"] = url
        if document_type == "support_page" or "support" in lowered:
            profile.official_docs["support_url"] = url

    tech_tokens = {
        "processor": ["processor", "cpu", "core i", "xeon", "ryzen"],
        "soc": ["soc", "system on chip"],
        "chipset": ["chipset", "platform controller"],
        "memory": ["memory", "ram", "ddr", "sodimm", "lpddr"],
        "storage": ["storage", "ssd", "nvme", "sata", "emmc"],
        "wireless_chip": ["wi-fi", "wifi", "wireless", "bluetooth", "wlan"],
        "ports": ["usb", "hdmi", "ethernet", "thunderbolt", "displayport"],
        "power": ["power", "adapter", "watt", "voltage"],
        "dimensions": ["dimensions", "height", "width", "depth"],
        "os_support": ["os support", "operating system", "windows", "linux", "ubuntu"],
    }
    for field, tokens in tech_tokens.items():
        if any(token in lowered for token in tokens):
            profile.technical_specs[field] = "mentioned_in_document"

    if document_type == "teardown" or "teardown" in lowered or "ifixit" in lowered or "disassembly" in lowered:
        profile.teardown_re["teardown_url"] = url
        profile.teardown_re["guide_steps"] = "mentioned_in_document"
    if "tool" in lowered:
        profile.teardown_re["tools"] = "mentioned_in_document"
    if "component" in lowered or "chip" in lowered or "board" in lowered:
        profile.teardown_re["components_seen"] = "mentioned_in_document"
    if "board marking" in lowered or "silkscreen" in lowered:
        profile.teardown_re["board_markings"] = "mentioned_in_document"
    if "chip marking" in lowered:
        profile.teardown_re["chip_markings"] = "mentioned_in_document"

    if document_type == "regulatory" or "fcc" in lowered:
        profile.regulatory["fcc_grant"] = url
    if "internal photo" in lowered:
        profile.regulatory["internal_photos"] = url
    if "external photo" in lowered:
        profile.regulatory["external_photos"] = url
    if "test report" in lowered:
        profile.regulatory["test_report"] = url
    if "label" in lowered:
        profile.regulatory["label"] = url

    profile.evidence_provenance.append(
        {
            "source": "document_extractor",
            "source_url": url,
            "source_type": document_type,
            "reliability": 78,
        }
    )
    return profile


async def extract_document(request: DocumentExtractRequest, timeout_seconds: float = 20.0) -> DocumentExtractResponse:
    try:
        async with httpx.AsyncClient(timeout=timeout_seconds, follow_redirects=True) as client:
            response = await client.get(request.url, headers={"User-Agent": "NoetherIPProductExtractor/0.1"})
        content_type = response.headers.get("content-type", "")
        final_url = str(response.url)
        content = response.content

        if "pdf" in content_type.lower() or final_url.lower().endswith(".pdf"):
            title = request.source_title or final_url.rsplit("/", 1)[-1]
            pdf_text, pdf_metadata = _pdf_text(content)
            fields = {
                "file_type": "pdf",
                "size_bytes": len(content),
                "filename": final_url.rsplit("/", 1)[-1],
                "content_hash": sha256(content).hexdigest(),
                **_extract_fields(pdf_text),
            }
            return DocumentExtractResponse(
                url=request.url,
                final_url=final_url,
                document_type=request.document_type,
                status="ok",
                http_status=response.status_code,
                content_type=content_type,
                title=title,
                text_preview=pdf_text[:2500] if pdf_text else "PDF detected. Install pypdf to extract text; OCR can be added for scanned PDFs.",
                extracted_fields=fields,
                normalized_groups=_target_groups(final_url, request.document_type, f"{title} {pdf_text}", fields, []),
                downloaded_assets=[
                    {
                        "asset_type": "pdf",
                        "url": final_url,
                        "filename": fields["filename"],
                        "size_bytes": len(content),
                        "content_hash": fields["content_hash"],
                    }
                ],
                metadata={"product_query": request.product_query, "source_title": request.source_title, **pdf_metadata},
            )

        html = response.text
        text = _clean_text(html)
        title = _title(html) or request.source_title
        fields = _extract_fields(text)
        fields.update(
            {
                key: value
                for key, value in {
                    "meta_description": _meta(html, "description") or _meta(html, "og:description"),
                    "og_title": _meta(html, "og:title"),
                }.items()
                if value
            }
        )
        links = _links(html, final_url)
        images = _images(html, final_url)
        fields["content_hash"] = sha256(response.content).hexdigest()
        fields["classified_links"] = _classify_links(links)
        if images:
            fields["image_count"] = len(images)
        return DocumentExtractResponse(
            url=request.url,
            final_url=final_url,
            document_type=request.document_type,
            status="ok",
            http_status=response.status_code,
            content_type=content_type,
            title=title,
            text_preview=text[:2500],
            extracted_fields=fields,
            normalized_groups=_target_groups(final_url, request.document_type, text, fields, links),
            links=links,
            images=images,
            downloaded_assets=[
                {
                    "asset_type": "html",
                    "url": final_url,
                    "size_bytes": len(response.content),
                    "content_hash": fields["content_hash"],
                }
            ],
            metadata={"product_query": request.product_query, "source_title": request.source_title},
        )
    except Exception as exc:
        return DocumentExtractResponse(
            url=request.url,
            document_type=request.document_type,
            status="error",
            error=str(exc)[:500],
        )
