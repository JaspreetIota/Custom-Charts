from __future__ import annotations

from typing import Any

from app.models import CoverageReport, EvidenceItem, FieldCoverage, NormalizedProduct, ProductDataProfile, SourceRun


TARGET_FIELDS: dict[str, list[str]] = {
    "product_identity": [
        "product_name",
        "brand",
        "manufacturer",
        "model_number",
        "part_number",
        "sku",
        "mpn",
        "asin",
        "upc_gtin",
        "fcc_id",
    ],
    "official_docs": [
        "datasheet_url",
        "manual_url",
        "service_manual_url",
        "support_url",
        "firmware_url",
        "driver_url",
        "bios_url",
    ],
    "technical_specs": [
        "processor",
        "soc",
        "chipset",
        "memory",
        "storage",
        "wireless_chip",
        "ports",
        "power",
        "dimensions",
        "os_support",
    ],
    "teardown_re": [
        "teardown_url",
        "guide_steps",
        "images",
        "tools",
        "components_seen",
        "board_markings",
        "chip_markings",
    ],
    "regulatory": [
        "fcc_grant",
        "internal_photos",
        "external_photos",
        "test_report",
        "label",
        "grant_date",
    ],
    "history": [
        "first_seen",
        "last_seen",
        "launch_inference",
        "discontinued_inference",
        "archived_urls",
    ],
}


DOC_PATTERNS: dict[str, list[str]] = {
    "datasheet_url": ["datasheet", "data sheet", "specification", "specifications", "product brief"],
    "manual_url": ["user manual", "manual pdf", "manual"],
    "service_manual_url": ["service manual", "maintenance manual"],
    "support_url": ["support", "helpdesk", "downloadcenter"],
    "firmware_url": ["firmware", "release notes"],
    "driver_url": ["driver", "drivers"],
    "bios_url": ["bios", "uefi"],
}

TECH_PATTERNS: dict[str, list[str]] = {
    "processor": ["processor", "cpu", "core i", "ryzen", "xeon"],
    "soc": ["soc", "system on chip"],
    "chipset": ["chipset", "platform controller"],
    "memory": ["memory", "ram", "ddr", "sodimm", "lpddr"],
    "storage": ["storage", "ssd", "nvme", "sata", "emmc"],
    "wireless_chip": ["wi-fi", "wifi", "wireless", "bluetooth", "wlan"],
    "ports": ["usb", "hdmi", "ethernet", "thunderbolt", "displayport", "i/o ports", "ports:"],
    "power": ["power", "adapter", "watt", "voltage"],
    "dimensions": ["dimensions", "height", "width", "depth"],
    "os_support": ["os support", "operating system", "windows", "linux", "ubuntu"],
}


def _truthy(value: Any) -> bool:
    return value not in (None, "", [], {}, "null")


def _text(item: EvidenceItem) -> str:
    return " ".join(
        str(part or "")
        for part in [
            item.title,
            item.url,
            item.snippet,
            " ".join(f"{k} {v}" for k, v in item.identifiers.items()),
        ]
    ).lower()


def _put_once(group: dict[str, Any], field: str, value: Any) -> None:
    if _truthy(value) and not _truthy(group.get(field)):
        group[field] = value


def _is_discovery_url(url: str | None) -> bool:
    if not url:
        return True
    lowered = url.lower()
    return "google.com/search" in lowered or "bing.com/search" in lowered or "search.yahoo" in lowered


def _append_candidate(group: dict[str, Any], field: str, value: Any) -> None:
    if not _truthy(value):
        return
    group.setdefault(field, [])
    if value not in group[field]:
        group[field].append(value)


def build_data_profile(product: NormalizedProduct, evidence: list[EvidenceItem], runs: list[SourceRun]) -> ProductDataProfile:
    profile = ProductDataProfile()

    profile.product_identity.update(
        {
            "product_name": product.product_name,
            "brand": product.brand,
            "manufacturer": product.manufacturer,
            "model_number": product.model_number,
            "part_number": product.part_number,
            "sku": product.sku,
            "mpn": product.mpn,
            "asin": product.asin,
            "upc_gtin": product.upc_gtin,
            "fcc_id": product.fcc_id,
        }
    )

    for item in evidence:
        text = _text(item)
        url = item.url
        for field, value in (item.metadata.get("official_docs") or {}).items():
            _put_once(profile.official_docs, field, value)
        for field, value in (item.metadata.get("technical_specs") or {}).items():
            _put_once(profile.technical_specs, field, value)
        for field, value in (item.metadata.get("regulatory") or {}).items():
            _put_once(profile.regulatory, field, value)

        if url:
            for field, tokens in DOC_PATTERNS.items():
                if any(token in text for token in tokens):
                    if _is_discovery_url(url):
                        _append_candidate(profile.official_docs, f"candidate_{field}s", url)
                    else:
                        _put_once(profile.official_docs, field, url)

        for key, value in item.identifiers.items():
            normalized_key = {
                "model": "model_number",
                "device": "product_name",
                "mpn": "mpn",
                "sku": "sku",
                "asin": "asin",
                "upc": "upc_gtin",
                "ean": "upc_gtin",
                "fcc_id": "fcc_id",
                "brand": "brand",
                "manufacturer": "manufacturer",
            }.get(key)
            if normalized_key:
                _put_once(profile.product_identity, normalized_key, value)

        is_generic_capability = "can expose" in text or "lookup prepared" in text or "discovery url" in text
        for field, tokens in TECH_PATTERNS.items():
            if not is_generic_capability and any(token in text for token in tokens):
                _put_once(profile.technical_specs, field, item.snippet or item.title)

        if item.category == "teardown" or "teardown" in text or "ifixit" in text:
            assets = item.metadata.get("extracted_assets") or {}
            if item.metadata.get("discovery_only") or _is_discovery_url(url):
                _append_candidate(profile.teardown_re, "candidate_teardown_urls", url)
            else:
                _put_once(profile.teardown_re, "teardown_url", url)
            if not item.metadata.get("discovery_only") and ("guide" in text or "ifixit" in text):
                _put_once(profile.teardown_re, "guide_steps", assets.get("guide_steps") or "available_from_source")
            if "image" in text or "photo" in text:
                _put_once(profile.teardown_re, "images", assets.get("images") or "available_from_source")
            if assets.get("tools"):
                _put_once(profile.teardown_re, "tools", assets.get("tools"))
            if assets.get("parts"):
                _put_once(profile.teardown_re, "components_seen", assets.get("parts"))
            if assets.get("components_seen"):
                _put_once(profile.teardown_re, "components_seen", assets.get("components_seen"))
            if assets.get("board_markings"):
                _put_once(profile.teardown_re, "board_markings", assets.get("board_markings"))
            if assets.get("chip_markings"):
                _put_once(profile.teardown_re, "chip_markings", assets.get("chip_markings"))
            if not item.metadata.get("discovery_only") and ("component" in text or "soc" in text or "chip" in text):
                _put_once(profile.teardown_re, "components_seen", item.snippet or item.title)

        if item.category == "regulatory":
            _put_once(profile.regulatory, "fcc_grant", url)
            if "internal photo" in text:
                _put_once(profile.regulatory, "internal_photos", url)
            if "external photo" in text:
                _put_once(profile.regulatory, "external_photos", url)
            if "test report" in text:
                _put_once(profile.regulatory, "test_report", url)
            if "label" in text:
                _put_once(profile.regulatory, "label", url)

        if item.category == "history" or "wayback" in text or "archive" in text:
            _put_once(profile.history, "archived_urls", [url] if url else [])
            _put_once(profile.history, "first_seen", item.metadata.get("first_seen"))
            _put_once(profile.history, "last_seen", item.metadata.get("last_seen"))

        profile.evidence_provenance.append(
            {
                "source": item.source,
                "source_url": item.url,
                "source_type": item.category,
                "reliability": item.reliability,
                "retrieved_at": item.fetched_at.isoformat(),
                "content_hash": item.metadata.get("content_hash"),
                "raw_file_path": item.metadata.get("raw_file_path"),
            }
        )

    ok_runs = [run.source for run in runs if run.status == "ok"]
    if ok_runs:
        profile.evidence_provenance.append({"source": "source_runs", "successful_sources": ok_runs})

    return profile


def build_coverage_report(profile: ProductDataProfile) -> CoverageReport:
    groups: list[FieldCoverage] = []
    total = 0
    found = 0

    for group_name, fields in TARGET_FIELDS.items():
        data = getattr(profile, group_name)
        found_fields = [field for field in fields if _truthy(data.get(field))]
        missing_fields = [field for field in fields if field not in found_fields]
        total += len(fields)
        found += len(found_fields)
        groups.append(
            FieldCoverage(
                group=group_name,
                total_fields=len(fields),
                found_fields=found_fields,
                missing_fields=missing_fields,
                coverage_percent=int((len(found_fields) / len(fields)) * 100) if fields else 0,
            )
        )

    missing_all = {field for group in groups for field in group.missing_fields}
    free_next_actions: list[str] = []
    optional_paid: list[str] = []

    if {"datasheet_url", "manual_url", "support_url", "firmware_url", "driver_url", "bios_url"} & missing_all:
        free_next_actions.append("Try official manufacturer support pages and paste selected URLs into /documents/extract.")
        free_next_actions.append("Use Wayback after a support/product URL is known to infer historical availability.")
        optional_paid.append("If official links remain missing, enable Google Programmable Search for direct result URLs.")
    if {"teardown_url", "guide_steps", "components_seen"} & missing_all:
        free_next_actions.append("Check iFixit/device teardown pages and public repair guides; extract selected guide URLs.")
    if {"fcc_grant", "internal_photos", "test_report", "label"} & missing_all:
        free_next_actions.append("Search for FCC ID from labels/manuals; FCC evidence becomes strong once FCC ID is known.")
    if {"sku", "mpn", "asin", "upc_gtin"} & missing_all:
        free_next_actions.append("Use UPCitemdb free quota and public retailer/manufacturer pages for product identifiers.")
        optional_paid.append("If identity remains weak, consider Barcode Lookup or Best Buy API later.")
    if {"processor", "chipset", "memory", "storage", "ports"} & missing_all:
        free_next_actions.append("Extract official specification/support pages and manuals to populate technical specs.")

    notes = []
    if found == 0:
        notes.append("No target fields were filled; this product likely needs direct URL/document extraction.")
    elif found / total < 0.35:
        notes.append("Coverage is low; use free document extraction on official links before considering paid APIs.")
    elif found / total < 0.65:
        notes.append("Coverage is partial; free sources found useful evidence but direct document parsing is still needed.")
    else:
        notes.append("Coverage is strong enough for a free-first pass; review provenance before relying on it.")

    return CoverageReport(
        overall_percent=int((found / total) * 100) if total else 0,
        groups=groups,
        free_next_actions=list(dict.fromkeys(free_next_actions)),
        optional_paid_recommendations=list(dict.fromkeys(optional_paid)),
        data_quality_notes=notes,
    )
