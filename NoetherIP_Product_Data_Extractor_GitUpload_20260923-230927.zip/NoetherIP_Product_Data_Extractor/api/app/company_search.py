from __future__ import annotations

import asyncio
from collections import defaultdict

import httpx

from app.models import CompanyProductCandidate, CompanyProductSearchRequest, CompanyProductSearchResponse, SourceRun
from app.settings import Settings


def _dedupe_key(product: CompanyProductCandidate) -> str:
    return " ".join(
        [
            product.product_name,
            product.brand or "",
            product.model_number or "",
            product.sku or "",
            product.upc_gtin or "",
        ]
    ).lower().strip()


def _add(products: list[CompanyProductCandidate], candidate: CompanyProductCandidate) -> None:
    key = _dedupe_key(candidate)
    if not key:
        return
    for index, existing in enumerate(products):
        if _dedupe_key(existing) == key:
            if candidate.reliability > existing.reliability:
                products[index] = candidate
            return
    products.append(candidate)


async def _upcitemdb(company: str, request: CompanyProductSearchRequest, settings: Settings, client: httpx.AsyncClient) -> tuple[list[CompanyProductCandidate], SourceRun]:
    try:
        url = "https://api.upcitemdb.com/prod/trial/search"
        data = (
            await client.get(
                url,
                params={"s": company, "match_mode": 0, "type": "product"},
                headers={"User-Agent": settings.upcitemdb_user_agent},
            )
        ).json()
        products: list[CompanyProductCandidate] = []
        for item in (data.get("items") or [])[: request.max_results_per_source]:
            product = CompanyProductCandidate(
                product_name=item.get("title") or item.get("description") or "UPC product",
                brand=item.get("brand") or company,
                manufacturer=company,
                category=item.get("category"),
                upc_gtin=str(item.get("upc") or item.get("ean") or "") or None,
                source="UPCitemdb",
                source_url=(item.get("offers") or [{}])[0].get("link"),
                reliability=66,
                metadata=item,
            )
            _add(products, product)
        return products, SourceRun(source="UPCitemdb company search", status="ok", message="Company product records fetched", count=len(products))
    except Exception as exc:
        return [], SourceRun(source="UPCitemdb company search", status="error", message=f"UPCitemdb failed: {exc}", count=0)


async def _nhtsa(company: str, request: CompanyProductSearchRequest, client: httpx.AsyncClient) -> tuple[list[CompanyProductCandidate], SourceRun]:
    try:
        url = f"https://vpic.nhtsa.dot.gov/api/vehicles/GetModelsForMake/{company}?format=json"
        data = (await client.get(url)).json()
        products = [
            CompanyProductCandidate(
                product_name=f"{item.get('Make_Name')} {item.get('Model_Name')}",
                brand=item.get("Make_Name") or company,
                manufacturer=item.get("Make_Name") or company,
                category="automotive",
                model_number=str(item.get("Model_ID") or "") or None,
                source="NHTSA vPIC",
                source_url=url,
                reliability=80,
                metadata=item,
            )
            for item in (data.get("Results") or [])[: request.max_results_per_source]
            if item.get("Model_Name")
        ]
        return products, SourceRun(source="NHTSA company/make search", status="ok", message="Vehicle models fetched", count=len(products))
    except Exception as exc:
        return [], SourceRun(source="NHTSA company/make search", status="error", message=f"NHTSA failed: {exc}", count=0)


async def _openfda(company: str, request: CompanyProductSearchRequest, client: httpx.AsyncClient) -> tuple[list[CompanyProductCandidate], SourceRun]:
    try:
        data = (
            await client.get(
                "https://api.fda.gov/device/510k.json",
                params={"search": f'applicant:"{company}"', "limit": request.max_results_per_source},
            )
        ).json()
        products = [
            CompanyProductCandidate(
                product_name=item.get("device_name") or "FDA medical device",
                brand=company,
                manufacturer=item.get("applicant") or company,
                category="medical device",
                model_number=item.get("k_number"),
                source="openFDA Device 510(k)",
                source_url="https://open.fda.gov/apis/device/510k/",
                reliability=82,
                metadata=item,
            )
            for item in (data.get("results") or [])[: request.max_results_per_source]
            if item.get("device_name")
        ]
        return products, SourceRun(source="openFDA company/applicant search", status="ok", message="Medical device records fetched", count=len(products))
    except Exception as exc:
        return [], SourceRun(source="openFDA company/applicant search", status="error", message=f"openFDA failed: {exc}", count=0)


async def _wikidata(company: str, request: CompanyProductSearchRequest, client: httpx.AsyncClient) -> tuple[list[CompanyProductCandidate], SourceRun]:
    try:
        safe = company.replace('"', "")
        sparql = f"""
        SELECT ?item ?itemLabel ?manufacturerLabel ?website WHERE {{
          ?item wdt:P176 ?manufacturer.
          ?manufacturer rdfs:label ?manufacturerLabel.
          ?item rdfs:label ?itemLabel.
          FILTER(LANG(?manufacturerLabel) = "en")
          FILTER(LANG(?itemLabel) = "en")
          FILTER(CONTAINS(LCASE(?manufacturerLabel), LCASE("{safe}")))
          OPTIONAL {{ ?item wdt:P856 ?website. }}
          SERVICE wikibase:label {{ bd:serviceParam wikibase:language "en". }}
        }} LIMIT {request.max_results_per_source}
        """
        data = (
            await client.get(
                "https://query.wikidata.org/sparql",
                params={"query": sparql, "format": "json"},
                headers={"User-Agent": "NoetherIPProductExtractor/0.1"},
            )
        ).json()
        products: list[CompanyProductCandidate] = []
        for row in data.get("results", {}).get("bindings", []):
            label = row.get("itemLabel", {}).get("value")
            if not label:
                continue
            products.append(
                CompanyProductCandidate(
                    product_name=label,
                    brand=company,
                    manufacturer=row.get("manufacturerLabel", {}).get("value") or company,
                    source="Wikidata",
                    source_url=row.get("item", {}).get("value") or row.get("website", {}).get("value"),
                    reliability=60,
                    metadata=row,
                )
            )
        return products, SourceRun(source="Wikidata manufacturer product search", status="ok", message="Wikidata product entities fetched", count=len(products))
    except Exception as exc:
        return [], SourceRun(source="Wikidata manufacturer product search", status="error", message=f"Wikidata failed: {exc}", count=0)


async def _google_pse(company: str, request: CompanyProductSearchRequest, settings: Settings, client: httpx.AsyncClient) -> tuple[list[CompanyProductCandidate], SourceRun]:
    if not settings.google_api_key or not settings.google_cx:
        return [], SourceRun(source="Google Programmable Search company products", status="skipped", message="GOOGLE_API_KEY and GOOGLE_CX not configured", count=0)
    try:
        data = (
            await client.get(
                "https://www.googleapis.com/customsearch/v1",
                params={
                    "key": settings.google_api_key,
                    "cx": settings.google_cx,
                    "q": f"{company} products models official",
                    "num": min(request.max_results_per_source, 10),
                },
            )
        ).json()
        products = [
            CompanyProductCandidate(
                product_name=item.get("title") or "Search result",
                brand=company,
                manufacturer=company,
                source="Google Programmable Search",
                source_url=item.get("link"),
                reliability=62,
                metadata=item,
            )
            for item in (data.get("items") or [])[: request.max_results_per_source]
        ]
        return products, SourceRun(source="Google Programmable Search company products", status="ok", message="Company product pages fetched", count=len(products))
    except Exception as exc:
        return [], SourceRun(source="Google Programmable Search company products", status="error", message=f"Google PSE failed: {exc}", count=0)


def _official_catalog_seeds(company: str, request: CompanyProductSearchRequest) -> tuple[list[CompanyProductCandidate], SourceRun]:
    key = company.lower()
    catalog: dict[str, list[tuple[str, str, str]]] = {
        "nvidia": [
            ("NVIDIA GeForce RTX 50 Series", "graphics card / GPU", "https://www.nvidia.com/en-us/geforce/graphics-cards/50-series/"),
            ("NVIDIA GeForce RTX 40 Series", "graphics card / GPU", "https://www.nvidia.com/en-us/geforce/graphics-cards/40-series/"),
            ("NVIDIA GeForce RTX 4080", "graphics card / GPU", "https://www.nvidia.com/en-us/geforce/graphics-cards/40-series/rtx-4080-family/"),
            ("NVIDIA RTX PRO", "professional GPU", "https://www.nvidia.com/en-us/design-visualization/rtx-pro/"),
            ("NVIDIA Jetson Orin", "edge AI module", "https://www.nvidia.com/en-us/autonomous-machines/embedded-systems/"),
            ("NVIDIA DGX Spark", "AI workstation", "https://www.nvidia.com/en-us/products/workstations/dgx-spark/"),
            ("NVIDIA SHIELD TV", "streaming device", "https://www.nvidia.com/en-us/shield/"),
        ],
        "intel": [
            ("Intel Core processors", "processor", "https://www.intel.com/content/www/us/en/products/details/processors/core.html"),
            ("Intel Xeon processors", "processor", "https://www.intel.com/content/www/us/en/products/details/processors/xeon.html"),
            ("Intel Arc graphics", "graphics / GPU", "https://www.intel.com/content/www/us/en/products/details/discrete-gpus/arc.html"),
            ("Intel Wi-Fi products", "wireless module", "https://www.intel.com/content/www/us/en/products/details/wireless.html"),
            ("Intel Ethernet products", "networking", "https://www.intel.com/content/www/us/en/products/details/ethernet.html"),
            ("Intel NUC", "mini PC", "https://www.intel.com/content/www/us/en/products/details/nuc.html"),
        ],
        "apple": [
            ("Apple iPhone", "smartphone", "https://www.apple.com/iphone/"),
            ("Apple iPad", "tablet", "https://www.apple.com/ipad/"),
            ("Apple MacBook Pro", "laptop", "https://www.apple.com/macbook-pro/"),
            ("Apple MacBook Air", "laptop", "https://www.apple.com/macbook-air/"),
            ("Apple Watch", "wearable", "https://www.apple.com/watch/"),
            ("Apple Vision Pro", "mixed reality headset", "https://www.apple.com/apple-vision-pro/"),
        ],
    }
    products: list[CompanyProductCandidate] = []
    for company_key, rows in catalog.items():
        if company_key not in key:
            continue
        for name, category, url in rows[: request.max_results_per_source]:
            products.append(
                CompanyProductCandidate(
                    product_name=name,
                    brand=company,
                    manufacturer=company,
                    category=category,
                    source="Official catalog seed",
                    source_url=url,
                    reliability=74,
                    metadata={"seeded": True, "note": "Official manufacturer product-family page. Use enrichment to resolve exact model/details."},
                )
            )
    return products, SourceRun(source="Official catalog seeds", status="ok", message="Known official product-family seeds prepared", count=len(products))


async def search_company_products(request: CompanyProductSearchRequest, settings: Settings) -> CompanyProductSearchResponse:
    company = request.company_name.strip()
    async with httpx.AsyncClient(timeout=settings.request_timeout_seconds, follow_redirects=True) as client:
        source_results = await _run_sources(company, request, settings, client)

    products: list[CompanyProductCandidate] = []
    runs: list[SourceRun] = []
    for source_products, run in source_results:
        runs.append(run)
        for product in source_products:
            _add(products, product)

    by_name: defaultdict[str, int] = defaultdict(int)
    for product in products:
        by_name[product.product_name.lower()] += 1

    products.sort(key=lambda item: (item.reliability, by_name[item.product_name.lower()]), reverse=True)
    notes = [
        "Company search returns a product candidate list first. Select one product to run name-only raw enrichment or full extraction.",
        "Free sources have uneven company coverage. UPCitemdb is useful for retail products, NHTSA for vehicle makes, openFDA for medical-device applicants, and Wikidata for notable products.",
        "Google Programmable Search and Best Buy can improve broad company catalog coverage when keys are configured.",
    ]
    return CompanyProductSearchResponse(company_name=company, products=products, source_runs=runs, notes=notes)


async def _run_sources(company: str, request: CompanyProductSearchRequest, settings: Settings, client: httpx.AsyncClient):
    return await asyncio.gather(
        _async_seed(company, request),
        _upcitemdb(company, request, settings, client),
        _nhtsa(company, request, client),
        _openfda(company, request, client),
        _wikidata(company, request, client),
        _google_pse(company, request, settings, client),
    )


async def _async_seed(company: str, request: CompanyProductSearchRequest) -> tuple[list[CompanyProductCandidate], SourceRun]:
    return _official_catalog_seeds(company, request)
