from __future__ import annotations

import re
from urllib.parse import quote_plus

import httpx

from app.document_extractor import extract_document
from app.models import (
    CandidatePage,
    DocumentExtractRequest,
    DocumentExtractResponse,
    HarvestedIdentifier,
    NameEnrichmentRequest,
    NameEnrichmentResponse,
    ProductQuery,
)
from app.service import ProductExtractionService
from app.settings import Settings


TOKEN_RE = re.compile(r"\s+")


def _clean(value: str) -> str:
    return TOKEN_RE.sub(" ", value).strip()


def _brand_text(request: NameEnrichmentRequest) -> str:
    return " ".join([request.brand or "", request.manufacturer or "", request.query]).lower()


def _search_url(query: str) -> str:
    return f"https://www.google.com/search?q={quote_plus(query)}"


def _add_candidate(
    candidates: list[CandidatePage],
    url: str,
    title: str,
    source_type: str,
    document_type: str = "unknown",
    reliability: int = 50,
    extractable: bool = True,
    reason: str | None = None,
) -> None:
    if any(existing.url == url for existing in candidates):
        return
    candidates.append(
        CandidatePage(
            url=url,
            title=title,
            source_type=source_type,
            document_type=document_type,  # type: ignore[arg-type]
            reliability=reliability,
            extractable=extractable,
            reason=reason,
        )
    )


def build_name_candidates(request: NameEnrichmentRequest) -> list[CandidatePage]:
    query = _clean(request.query)
    lowered = _brand_text(request)
    candidates: list[CandidatePage] = []

    if "nvidia" in lowered or "geforce" in lowered or "rtx" in lowered:
        if "4080" in lowered:
            _add_candidate(
                candidates,
                "https://www.nvidia.com/en-us/geforce/graphics-cards/40-series/rtx-4080-family/",
                "NVIDIA GeForce RTX 4080 family official product page",
                "official_product_page",
                "support_page",
                92,
                True,
                "Known NVIDIA RTX 4080 official product family page.",
            )
            _add_candidate(
                candidates,
                "https://nvidia.custhelp.com/app/answers/detail/a_id/4756/",
                "NVIDIA graphics card user guides",
                "official_manual_index",
                "manual",
                86,
                True,
                "Official NVIDIA support page that lists GeForce user guide PDFs.",
            )
            _add_candidate(
                candidates,
                "https://nvidia.custhelp.com/app/answers/detail/a_id/5396/~/geforce-rtx-40-series-%26-power-specifications",
                "NVIDIA GeForce RTX 40 Series power specifications",
                "official_support_page",
                "support_page",
                84,
                True,
                "Official NVIDIA support page for RTX 40 power details.",
            )
            _add_candidate(
                candidates,
                "https://www.techpowerup.com/review/asus-geforce-rtx-4080-strix-oc/3.html",
                "TechPowerUp ASUS GeForce RTX 4080 STRIX OC pictures and teardown",
                "teardown_review",
                "teardown",
                76,
                True,
                "Third-party teardown with board, connector and cooling details.",
            )
            _add_candidate(
                candidates,
                "https://www.techpowerup.com/gpu-specs/geforce-rtx-4080.c3888",
                "TechPowerUp GeForce RTX 4080 GPU specs",
                "third_party_specs",
                "datasheet",
                72,
                True,
                "Third-party specs database page; useful when official specs are dynamic.",
            )
        _add_candidate(
            candidates,
            "https://www.nvidia.com/en-us/drivers/",
            "NVIDIA driver downloads",
            "official_driver_page",
            "support_page",
            78,
            True,
            "Official driver landing page.",
        )

    if "intel" in lowered:
        _add_candidate(
            candidates,
            f"https://www.intel.com/content/www/us/en/search.html?ws=text#q={quote_plus(query)}",
            f"Intel official search for {query}",
            "official_site_search",
            "support_page",
            70,
            False,
            "Search-result page; needs Google PSE or user selection to resolve direct product/document URL.",
        )

    discovery_terms = [
        f"{query} official specifications",
        f"{query} datasheet pdf",
        f"{query} user manual pdf",
        f"{query} service manual",
        f"{query} teardown PCB analysis",
        f"{query} FCC ID internal photos",
        f"{query} driver BIOS firmware",
    ]
    for term in discovery_terms:
        _add_candidate(
            candidates,
            _search_url(term),
            term,
            "search_discovery",
            "unknown",
            55,
            False,
            "Discovery URL. Resolve through Google Programmable Search or user selection before extraction.",
        )

    return sorted(candidates, key=lambda item: item.reliability, reverse=True)[: request.max_candidates]


def _context(text: str, start: int, end: int, window: int = 80) -> str:
    return _clean(text[max(0, start - window) : min(len(text), end + window)])


def _harvest_from_text(text: str, source_url: str | None) -> list[HarvestedIdentifier]:
    patterns: dict[str, tuple[str, int]] = {
        "fcc_id": (r"\bFCC\s*ID\b\s*[:#-]?\s*([A-Z0-9-]{4,})", 86),
        "upc_gtin": (r"\b(?:UPC|GTIN|EAN)\b\s*[:#-]?\s*([0-9]{8,14})", 78),
        "asin": (r"\bASIN\b\s*[:#-]?\s*([A-Z0-9]{10})", 78),
        "model_number": (r"\b(?:model(?:\s+number)?|model no\.?)\b\s*[:#-]\s*([A-Z0-9][A-Z0-9._/-]{2,})", 72),
        "part_number": (r"\b(?:part(?:\s+number)?|p/n)\b\s*[:#-]\s*([A-Z0-9][A-Z0-9._/-]{2,})", 72),
        "gpu_die": (r"\b(AD10[0-9])\b", 72),
        "memory_chip_marking": (r"\b((?:MT|D8)[A-Z0-9]{3,}[A-Z0-9._/-]*)\b", 68),
        "vrm_controller": (r"\b(uP[0-9]{4,}[A-Z]?)\b", 66),
        "drmos_part": (r"\b(SIC[0-9]{3,}[A-Z]?)\b", 66),
        "cuda_cores": (r"(?:\bCUDA\s+Cores\b|\bNVIDIA\s+CUDA\s+Cores\b)\s*[:#-]?\s*([0-9]{4,5})|\b([0-9]{4,5})\s+CUDA\s+Cores\b", 82),
        "memory_size": (r"\b([0-9]{1,3}\s*GB)\s+(?:GDDR|DDR|LPDDR)", 80),
        "memory_type": (r"\b(GDDR6X|GDDR6|GDDR7|DDR5|LPDDR5X?)\b", 74),
        "power": (r"\b([0-9]{2,4}\s*W)\b", 58),
        "display_ports": (r"\b([0-9]x?\s*DisplayPort\s*[0-9.]*[a-z]?)\b", 60),
        "hdmi_ports": (r"\b([0-9]x?\s*HDMI\s*[0-9.]*[a-z]?)\b", 60),
        "dimensions": (r"\b([0-9]{2,3}(?:\.[0-9])?\s*(?:x|×)\s*[0-9]{2,3}(?:\.[0-9])?\s*(?:x|×)?\s*[0-9]{0,3}(?:\.[0-9])?\s*(?:cm|mm))\b", 62),
    }
    harvested: list[HarvestedIdentifier] = []
    seen: set[tuple[str, str]] = set()
    for field, (pattern, confidence) in patterns.items():
        for match in re.finditer(pattern, text, flags=re.IGNORECASE):
            value = _clean(next((group for group in match.groups() if group), match.group(0)))
            key = (field, value.lower())
            if key in seen:
                continue
            seen.add(key)
            harvested.append(
                HarvestedIdentifier(
                    field=field,
                    value=value,
                    source_url=source_url,
                    confidence=confidence,
                    context=_context(text, match.start(), match.end()),
                )
            )
            if len([item for item in harvested if item.field == field]) >= 5:
                break
    return harvested


def harvest_identifiers(documents: list[DocumentExtractResponse]) -> list[HarvestedIdentifier]:
    harvested: list[HarvestedIdentifier] = []
    seen: set[tuple[str, str, str | None]] = set()
    direct_fields = {
        "model_number": 76,
        "part_number": 76,
        "fcc_id": 88,
        "upc_gtin": 80,
        "asin": 80,
        "gpu_die": 78,
        "cuda_cores": 84,
        "memory_size": 82,
        "memory_type": 78,
        "vrm_controller": 74,
        "memory_chip_marking": 72,
        "drmos_part": 72,
        "bios": 70,
    }
    for doc in documents:
        source_url = doc.final_url or doc.url
        doc_title = (doc.title or "").lower()
        query_lower = " ".join([doc.metadata.get("product_query") or "", doc.url]).lower()
        ambiguous_family_page = "super" in doc_title and "super" not in query_lower
        for field, confidence in direct_fields.items():
            value = (doc.extracted_fields or {}).get(field)
            if value in (None, "", [], {}):
                continue
            field_confidence = max(35, confidence - 22) if ambiguous_family_page and field in {"cuda_cores", "memory_size", "memory_type"} else confidence
            key = (field, str(value).lower(), source_url)
            if key in seen:
                continue
            seen.add(key)
            harvested.append(
                HarvestedIdentifier(
                    field=field,
                    value=str(value),
                    source_url=source_url,
                    confidence=field_confidence,
                    context=f"extracted_fields.{field}" + ("; ambiguous family page includes sibling variant" if ambiguous_family_page else ""),
                )
            )
        text = " ".join(
            [
                doc.title or "",
                doc.text_preview or "",
                " ".join(doc.links or []),
                str(doc.extracted_fields or ""),
            ]
        )
        for item in _harvest_from_text(text, source_url):
            key = (item.field, item.value.lower(), item.source_url)
            if key not in seen:
                seen.add(key)
                harvested.append(item)
    return sorted(harvested, key=lambda item: item.confidence, reverse=True)


def _first_identifier(items: list[HarvestedIdentifier], field: str) -> str | None:
    for item in items:
        if item.field == field:
            return item.value
    return None


def build_second_pass_query(request: NameEnrichmentRequest, harvested: list[HarvestedIdentifier], candidates: list[CandidatePage]) -> ProductQuery:
    official_url = next((item.url for item in candidates if item.extractable and item.source_type.startswith("official")), None)
    return ProductQuery(
        query=request.query,
        product_name=request.query,
        brand=request.brand,
        manufacturer=request.manufacturer or request.brand,
        company_name=request.manufacturer or request.brand,
        model_number=_first_identifier(harvested, "model_number"),
        part_number=_first_identifier(harvested, "part_number"),
        fcc_id=_first_identifier(harvested, "fcc_id"),
        upc=_first_identifier(harvested, "upc_gtin"),
        gtin=_first_identifier(harvested, "upc_gtin"),
        product_url=official_url,
        vertical="auto",
        max_results_per_source=5,
        free_only=request.free_only,
    )


async def enrich_from_name(request: NameEnrichmentRequest, settings: Settings) -> NameEnrichmentResponse:
    candidates = build_name_candidates(request)
    extractable = [candidate for candidate in candidates if candidate.extractable][: request.max_extracts]
    documents: list[DocumentExtractResponse] = []
    for candidate in extractable:
        documents.append(
            await extract_document(
                DocumentExtractRequest(
                    url=candidate.url,
                    document_type=candidate.document_type,
                    product_query=request.query,
                    source_title=candidate.title,
                ),
                timeout_seconds=settings.request_timeout_seconds,
            )
        )

    harvested = harvest_identifiers(documents)
    second_pass_query = build_second_pass_query(request, harvested, candidates)
    second_pass_result = None
    if request.run_second_pass:
        second_pass_result = await ProductExtractionService(settings).extract(second_pass_query)

    notes = [
        "Direct pages are extracted immediately; search discovery URLs are retained as candidates until a search API or user resolves them.",
        "Harvested identifiers are used to re-query free APIs such as FCC, Wayback, UPCitemdb, GitHub and source-specific connectors.",
        "Raw extracted documents remain separate from normalized records so users can choose what to trust.",
    ]
    if not settings.google_api_key or not settings.google_cx:
        notes.append("GOOGLE_API_KEY and GOOGLE_CX are not configured, so search-result candidates cannot be resolved automatically.")

    return NameEnrichmentResponse(
        query=request.query,
        candidates=candidates,
        extracted_documents=documents,
        harvested_identifiers=harvested,
        second_pass_query=second_pass_query,
        second_pass_result=second_pass_result,
        notes=notes,
    )
