from __future__ import annotations

from functools import lru_cache
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    github_token: str | None = None
    bestbuy_api_key: str | None = None
    google_api_key: str | None = None
    google_cx: str | None = None
    barcode_lookup_key: str | None = None
    upcitemdb_user_agent: str = "NoetherIP-Product-Data-Extractor/0.1"
    request_timeout_seconds: float = Field(default=14.0, ge=2.0, le=60.0)

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


@lru_cache
def get_settings() -> Settings:
    return Settings()
