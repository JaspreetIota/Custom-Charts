from __future__ import annotations

import json
from datetime import datetime
from html import escape
from time import perf_counter
from typing import Any
from urllib.parse import urlencode
from uuid import uuid4

import httpx
from fastapi import BackgroundTasks, FastAPI, Query
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.middleware.cors import CORSMiddleware

from app.document_extractor import extract_document
from app.company_search import search_company_products
from app.models import CompanyProductSearchRequest, CompanyProductSearchResponse, ConnectorInfo, DocumentExtractRequest, DocumentExtractResponse, ExtractionResponse, NameEnrichmentRequest, NameEnrichmentResponse, ProductQuery
from app.name_enrichment import enrich_from_name
from app.service import ProductExtractionService
from app.settings import get_settings

app = FastAPI(
    title="NoetherIP Product Data Extractor API",
    description="Extract product metadata, manuals/datasheets discovery, regulatory evidence, teardowns, firmware references and historical product traces from free/free-tier APIs.",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


def service() -> ProductExtractionService:
    return ProductExtractionService(get_settings())


JOBS: dict[str, dict[str, Any]] = {}

CONNECTOR_CHECKS: dict[str, dict[str, Any]] = {
    "fcc": {
        "name": "FCC Equipment Authorization",
        "url": "https://apps.fcc.gov/OETLabServices/getFCCIDList?fccId=ABC123",
    },
    "ifixit": {
        "name": "iFixit",
        "url": "https://www.ifixit.com/api/2.0/categories",
    },
    "openwrt": {
        "name": "OpenWrt Table of Hardware",
        "url": "https://openwrt.org/",
    },
    "github": {
        "name": "GitHub Code Search",
        "url": "https://api.github.com/rate_limit",
    },
    "wayback": {
        "name": "Wayback Machine CDX",
        "url": "https://archive.org/wayback/available?url=example.com",
    },
    "upcitemdb": {
        "name": "UPCitemdb",
        "url": "https://api.upcitemdb.com/prod/trial/search?s=test&match_mode=0&type=product",
    },
    "nhtsa": {
        "name": "NHTSA vPIC",
        "url": "https://vpic.nhtsa.dot.gov/api/vehicles/GetAllMakes?format=json",
    },
    "openfda": {
        "name": "openFDA Device APIs",
        "url": "https://api.fda.gov/device/510k.json?limit=1",
    },
    "wikidata": {
        "name": "Wikidata",
        "url": "https://query.wikidata.org/sparql?query=ASK%20%7B%20%7D&format=json",
    },
}


def _clean(value: str | None) -> str | None:
    if value is None:
        return None
    value = value.strip()
    return value or None


def _truthy_html(value: Any) -> bool:
    return value not in [None, "", [], {}, "null"]


def _display_value(value: Any) -> str:
    if isinstance(value, list):
        if not value:
            return ""
        return "<ul class='value-list'>" + "".join(f"<li>{_display_value(item)}</li>" for item in value) + "</ul>"
    if isinstance(value, dict):
        if not value:
            return ""
        return "<dl class='mini-dl'>" + "".join(
            f"<dt>{escape(str(k))}</dt><dd>{_display_value(v)}</dd>"
            for k, v in value.items()
            if _truthy_html(v)
        ) + "</dl>"
    text = str(value)
    if text.startswith(("http://", "https://")):
        return f"<a href='{escape(text)}'>{escape(text)}</a>"
    return escape(text)


def _kv_grid(data: dict[str, Any], empty: str = "No confirmed fields yet.") -> str:
    items = [(k, v) for k, v in data.items() if _truthy_html(v)]
    if not items:
        return f"<p class='empty'>{escape(empty)}</p>"
    return "<div class='field-grid'>" + "".join(
        f"<div class='field'><b>{escape(str(k).replace('_', ' ').title())}</b><span>{_display_value(v)}</span></div>"
        for k, v in items
    ) + "</div>"


def _status_class(status: str) -> str:
    status = (status or "").lower()
    if status in {"ok", "completed"}:
        return "ok"
    if status == "error":
        return "bad"
    if status in {"skipped", "queued", "running", "missing_key", "reachable"}:
        return "warn"
    return "info"


def _query_from_search(
    search_type: str,
    value: str,
    company_name: str | None = None,
    model_number: str | None = None,
    part_number: str | None = None,
    product_id: str | None = None,
    fcc_id: str | None = None,
    upc_gtin: str | None = None,
    sku_mpn_asin: str | None = None,
    marking: str | None = None,
    product_url: str | None = None,
    vertical: str | None = "auto",
    free_only: bool = True,
    max_results_per_source: int = 5,
) -> ProductQuery:
    value = value.strip()
    payload: dict[str, Any] = {
        "query": value,
        "search_type": search_type,
        "company_name": _clean(company_name),
        "manufacturer": _clean(company_name),
        "brand": _clean(company_name),
        "model_number": _clean(model_number),
        "part_number": _clean(part_number),
        "product_id": _clean(product_id),
        "fcc_id": _clean(fcc_id),
        "product_url": _clean(product_url),
        "vertical": _clean(vertical) or "auto",
        "free_only": free_only,
        "max_results_per_source": max_results_per_source,
    }
    if upc_gtin:
        payload["upc"] = _clean(upc_gtin)
        payload["gtin"] = _clean(upc_gtin)
    if sku_mpn_asin:
        payload["sku"] = _clean(sku_mpn_asin)
        payload["mpn"] = _clean(sku_mpn_asin)
        payload["asin"] = _clean(sku_mpn_asin)
    if marking:
        payload["board_marking"] = _clean(marking)
        payload["chip_marking"] = _clean(marking)

    if search_type == "product_name":
        payload["product_name"] = value
    elif search_type == "model_number":
        payload["model_number"] = value
    elif search_type == "part_number":
        payload["part_number"] = value
    elif search_type == "product_id":
        payload["product_id"] = value
    elif search_type == "fcc_id":
        payload["fcc_id"] = value
    elif search_type == "upc_gtin":
        payload["upc"] = value
        payload["gtin"] = value
    elif search_type == "sku_mpn_asin":
        payload["sku"] = value
        payload["mpn"] = value
        payload["asin"] = value
    elif search_type == "marking":
        payload["board_marking"] = value
        payload["chip_marking"] = value
    elif search_type == "product_url":
        payload["product_url"] = value
    elif search_type == "company":
        payload["company_name"] = value
        payload["manufacturer"] = value
        payload["brand"] = value
    return ProductQuery(**payload)


async def _run_job(job_id: str) -> None:
    JOBS[job_id]["status"] = "running"
    JOBS[job_id]["started_at"] = datetime.utcnow().isoformat()
    try:
        query = ProductQuery(**JOBS[job_id]["query"])
        result = await service().extract(query)
        JOBS[job_id]["status"] = "completed"
        JOBS[job_id]["completed_at"] = datetime.utcnow().isoformat()
        JOBS[job_id]["result"] = result.model_dump(mode="json")
    except Exception as exc:
        JOBS[job_id]["status"] = "error"
        JOBS[job_id]["completed_at"] = datetime.utcnow().isoformat()
        JOBS[job_id]["error"] = str(exc)


async def _check_url(client: httpx.AsyncClient, key: str, check: dict[str, Any]) -> dict[str, Any]:
    started = perf_counter()
    try:
        response = await client.get(check["url"], headers={"User-Agent": "NoetherIPProductExtractor/0.1"})
        elapsed_ms = int((perf_counter() - started) * 1000)
        status = "ok" if response.status_code < 400 else "reachable" if response.status_code < 500 else "error"
        return {
            "key": key,
            "name": check["name"],
            "status": status,
            "http_status": response.status_code,
            "elapsed_ms": elapsed_ms,
            "url": check["url"],
        }
    except Exception as exc:
        elapsed_ms = int((perf_counter() - started) * 1000)
        return {
            "key": key,
            "name": check["name"],
            "status": "error",
            "http_status": None,
            "elapsed_ms": elapsed_ms,
            "url": check["url"],
            "message": str(exc)[:240],
        }


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok", "service": "NoetherIP Product Data Extractor API"}


@app.get("/connectors", response_model=list[ConnectorInfo])
async def connectors() -> list[ConnectorInfo]:
    return service().connector_info()


@app.get("/connectors/check")
async def connector_checks() -> dict[str, Any]:
    settings = get_settings()
    configured_keys = {
        "github_token": bool(settings.github_token),
        "bestbuy_api_key": bool(settings.bestbuy_api_key),
        "google_programmable_search": bool(settings.google_api_key and settings.google_cx),
        "barcode_lookup_key": bool(settings.barcode_lookup_key),
    }
    async with httpx.AsyncClient(timeout=5.0, follow_redirects=True) as client:
        checks = [
            await _check_url(client, key, check)
            for key, check in CONNECTOR_CHECKS.items()
        ]
    checks.extend(
        [
            {
                "key": "manufacturer_discovery",
                "name": "Manufacturer Document Discovery",
                "status": "ok",
                "http_status": None,
                "elapsed_ms": 0,
                "url": None,
                "message": "Local deterministic discovery connector; no external API health check required.",
            },
            {
                "key": "bestbuy",
                "name": "Best Buy Products API",
                "status": "configured" if configured_keys["bestbuy_api_key"] else "missing_key",
                "http_status": None,
                "elapsed_ms": 0,
                "url": "https://api.bestbuy.com/v1/products",
            },
            {
                "key": "google_pse",
                "name": "Google Programmable Search",
                "status": "configured" if configured_keys["google_programmable_search"] else "missing_key",
                "http_status": None,
                "elapsed_ms": 0,
                "url": "https://www.googleapis.com/customsearch/v1",
            },
            {
                "key": "barcode_lookup",
                "name": "Barcode Lookup API",
                "status": "configured" if configured_keys["barcode_lookup_key"] else "missing_key",
                "http_status": None,
                "elapsed_ms": 0,
                "url": "https://api.barcodelookup.com/v3/products",
            },
        ]
    )
    return {
        "checked_at": datetime.utcnow().isoformat(),
        "configured_keys": configured_keys,
        "checks": checks,
    }


@app.post("/extract", response_model=ExtractionResponse)
async def extract(query: ProductQuery) -> ExtractionResponse:
    return await service().extract(query)


@app.post("/documents/extract", response_model=DocumentExtractResponse)
async def extract_document_api(request: DocumentExtractRequest) -> DocumentExtractResponse:
    return await extract_document(request, timeout_seconds=get_settings().request_timeout_seconds)


@app.post("/enrich/name", response_model=NameEnrichmentResponse)
async def enrich_name_api(request: NameEnrichmentRequest) -> NameEnrichmentResponse:
    return await enrich_from_name(request, get_settings())


@app.post("/companies/products", response_model=CompanyProductSearchResponse)
async def company_products_api(request: CompanyProductSearchRequest) -> CompanyProductSearchResponse:
    return await search_company_products(request, get_settings())


@app.get("/companies/products", response_class=HTMLResponse)
async def company_products_page(
    company_name: str | None = None,
    vertical: str = "auto",
    max_results_per_source: int = Query(10, ge=1, le=50),
) -> str:
    result = None
    if company_name:
        result = await search_company_products(
            CompanyProductSearchRequest(
                company_name=company_name,
                vertical=vertical,
                max_results_per_source=max_results_per_source,
            ),
            get_settings(),
        )
    result_html = ""
    if result:
        product_rows = "".join(
            f"<tr><td>{escape(item.product_name)}</td><td>{escape(item.brand or '')}</td><td>{escape(item.category or '')}</td><td>{escape(item.source)}</td><td>{item.reliability}</td><td><a href='{escape(item.source_url or '#')}'>{escape(item.source_url or '')}</a><br><a href='/enrich/name?query={escape(item.product_name)}&brand={escape(item.brand or result.company_name)}&manufacturer={escape(item.manufacturer or result.company_name)}'>Run enrichment</a></td></tr>"
            for item in result.products
        ) or "<tr><td colspan='6'>No product candidates found.</td></tr>"
        run_rows = "".join(
            f"<tr><td>{escape(run.source)}</td><td>{escape(run.status)}</td><td>{run.count}</td><td>{escape(run.message)}</td></tr>"
            for run in result.source_runs
        )
        notes = "".join(f"<li>{escape(note)}</li>" for note in result.notes)
        result_html = f"""
        <div class="card"><h2>Product Candidates For {escape(result.company_name)}</h2><table><thead><tr><th>Product</th><th>Brand</th><th>Category</th><th>Source</th><th>Reliability</th><th>Action / URL</th></tr></thead><tbody>{product_rows}</tbody></table></div>
        <div class="card"><h2>Source Runs</h2><table><thead><tr><th>Source</th><th>Status</th><th>Count</th><th>Message</th></tr></thead><tbody>{run_rows}</tbody></table></div>
        <div class="card"><h2>Notes</h2><ul>{notes}</ul></div>
        """
    return f"""
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>NoetherIP Company Product Search</title>
<style>
body{{margin:0;background:#f7f7f4;color:#141412;font:14px/1.45 Inter,system-ui,sans-serif}}main{{max-width:1200px;margin:0 auto;padding:30px}}
.card{{background:#fff;border:1px solid #e4e4de;border-radius:12px;padding:16px;margin-bottom:16px}}.grid{{display:grid;grid-template-columns:2fr 1fr 1fr;gap:10px}}
label{{display:block;color:#777;font:700 11px ui-monospace,Consolas,monospace;text-transform:uppercase;margin-bottom:6px}}input,select{{width:100%;box-sizing:border-box;border:1px solid #ddd;border-radius:9px;padding:11px}}
button{{border:0;background:#ff6a1a;color:#fff;border-radius:8px;padding:12px 16px;font-weight:800}}table{{width:100%;border-collapse:collapse;font-size:12.5px}}th,td{{border-bottom:1px solid #e4e4de;padding:10px;text-align:left;vertical-align:top}}th{{font-size:10px;text-transform:uppercase;color:#777}}a{{color:#141412;font-weight:700}}@media(max-width:900px){{.grid{{grid-template-columns:1fr}}}}
</style></head><body><main>
<h1>Company / Manufacturer Product Search</h1>
<p>Search a company first, then pick one product for name-only enrichment or full extraction.</p>
<form class="card" method="get" action="/companies/products">
  <div class="grid">
    <div><label>Company / manufacturer</label><input name="company_name" required value="{escape(company_name or 'Nvidia')}"></div>
    <div><label>Category handling</label><select name="vertical"><option value="auto">Auto</option><option value="electronics">Electronics</option><option value="automotive">Automotive</option><option value="medical device">Medical device</option></select></div>
    <div><label>Max per source</label><input type="number" min="1" max="50" name="max_results_per_source" value="{max_results_per_source}"></div>
  </div>
  <p><button type="submit">Find Company Products</button></p>
</form>
{result_html}
<p><a href="/search">Product search</a> | <a href="/enrich/name">Name enrichment</a> | <a href="/docs">API docs</a></p>
</main></body></html>
"""


@app.get("/enrich/name", response_class=HTMLResponse)
async def enrich_name_page(
    query: str | None = None,
    brand: str | None = None,
    manufacturer: str | None = None,
    max_candidates: int = Query(10, ge=1, le=30),
    max_extracts: int = Query(5, ge=0, le=12),
    run_second_pass: bool = True,
) -> str:
    result = None
    if query:
        result = await enrich_from_name(
            NameEnrichmentRequest(
                query=query,
                brand=brand,
                manufacturer=manufacturer,
                max_candidates=max_candidates,
                max_extracts=max_extracts,
                run_second_pass=run_second_pass,
            ),
            get_settings(),
        )

    result_html = ""
    if result:
        candidate_rows = "".join(
            f"<tr><td>{escape(item.source_type)}</td><td>{escape(item.document_type)}</td><td>{item.reliability}</td><td>{'yes' if item.extractable else 'no'}</td><td><a href='{escape(item.url)}'>{escape(item.title)}</a><br><small>{escape(item.reason or '')}</small></td></tr>"
            for item in result.candidates
        )
        id_rows = "".join(
            f"<tr><td>{escape(item.field)}</td><td>{escape(item.value)}</td><td>{item.confidence}</td><td><a href='{escape(item.source_url or '#')}'>{escape(item.source_url or '')}</a><br><small>{escape(item.context or '')}</small></td></tr>"
            for item in result.harvested_identifiers
        ) or "<tr><td colspan='4'>No identifiers harvested yet.</td></tr>"
        doc_rows = ""
        for doc in result.extracted_documents:
            doc_rows += (
                f"<tr><td>{escape(doc.status)}</td><td>{doc.http_status or ''}</td><td>{escape(doc.document_type)}</td>"
                f"<td><a href='{escape(doc.final_url or doc.url)}'>{escape(doc.title or doc.url)}</a><br><small>{escape(doc.content_type or '')}</small></td>"
                f"<td>{len(doc.links)}</td><td>{len(doc.images)}</td><td>{escape(str((doc.extracted_fields or {}).get('content_hash','')))}</td></tr>"
            )
        second = result.second_pass_result
        second_rows = ""
        second_evidence_rows = ""
        second_product = ""
        second_profile = ""
        if second:
            second_rows = "".join(
                f"<tr><td>{escape(run.source)}</td><td>{escape(run.status)}</td><td>{escape(run.message)}</td><td>{run.count}</td></tr>"
                for run in second.source_runs
            )
            second_evidence_rows = "".join(
                f"<tr><td>{escape(item.source)}</td><td>{escape(item.category)}</td><td><a href='{escape(item.url or '#')}'>{escape(item.title)}</a><br><small>{escape(item.snippet or '')}</small></td><td>{item.reliability}</td></tr>"
                for item in second.evidence
            )
            second_product = "".join(
                f"<div class='kv'><b>{escape(str(k))}</b><span>{escape(str(v))}</span></div>"
                for k, v in second.product.model_dump(mode="json").items()
                if v not in [None, "", [], {}]
            )
            second_profile = "".join(
                f"<h3>{escape(str(group).replace('_',' ').title())}</h3><div class='grid'>"
                + "".join(f"<div class='kv'><b>{escape(str(k))}</b><span>{escape(str(v))}</span></div>" for k, v in values.items() if v not in [None, '', [], {}])
                + "</div>"
                for group, values in second.data_profile.model_dump(mode="json").items()
                if isinstance(values, dict) and any(v not in [None, "", [], {}] for v in values.values())
            )
        notes = "".join(f"<li>{escape(note)}</li>" for note in result.notes)
        result_html = f"""
        <div class="card"><h2>Where The Data Goes</h2><div class="grid"><div class="kv"><b>Raw candidates</b><span>{len(result.candidates)} URLs in enrichment response</span></div><div class="kv"><b>Extracted raw docs</b><span>{len(result.extracted_documents)} page/PDF records</span></div><div class="kv"><b>Harvested fields</b><span>{len(result.harvested_identifiers)} candidate identifiers/spec values</span></div><div class="kv"><b>Second-pass evidence</b><span>{len(second.evidence) if second else 0} API evidence records</span></div></div><p><small>Second-pass counts live in source_runs. The fetched data records live in second_pass_result.evidence; normalized values live in second_pass_result.product and second_pass_result.data_profile.</small></p></div>
        <div class="card"><h2>Candidates</h2><table><thead><tr><th>Source type</th><th>Doc type</th><th>Reliability</th><th>Extracted</th><th>URL</th></tr></thead><tbody>{candidate_rows}</tbody></table></div>
        <div class="card"><h2>Extracted Raw Pages/Documents</h2><table><thead><tr><th>Status</th><th>HTTP</th><th>Type</th><th>Document</th><th>Links</th><th>Images</th><th>Hash</th></tr></thead><tbody>{doc_rows or "<tr><td colspan='7'>No extraction requested.</td></tr>"}</tbody></table></div>
        <div class="card"><h2>Harvested Identifiers / Raw Data Points</h2><table><thead><tr><th>Field</th><th>Value</th><th>Confidence</th><th>Source context</th></tr></thead><tbody>{id_rows}</tbody></table></div>
        <div class="card"><h2>Second-Pass API Query</h2><pre>{escape(str(result.second_pass_query.model_dump(mode="json") if result.second_pass_query else {}))}</pre><h3>Second-Pass API Runs</h3><table><thead><tr><th>Source</th><th>Status</th><th>Message</th><th>Count</th></tr></thead><tbody>{second_rows or "<tr><td colspan='4'>Second pass disabled or no result.</td></tr>"}</tbody></table><h3>Second-Pass Evidence Records</h3><table><thead><tr><th>Source</th><th>Type</th><th>Evidence</th><th>Reliability</th></tr></thead><tbody>{second_evidence_rows or "<tr><td colspan='4'>No second-pass evidence records.</td></tr>"}</tbody></table><h3>Second-Pass Normalized Product</h3><div class="grid">{second_product or "<p>No normalized product yet.</p>"}</div><h3>Second-Pass Data Profile</h3>{second_profile or "<p>No profile fields yet.</p>"}</div>
        <div class="card"><h2>Notes</h2><ul>{notes}</ul></div>
        """
    return f"""
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>NoetherIP Name Enrichment</title>
<style>
body{{margin:0;background:#f7f7f4;color:#141412;font:14px/1.45 Inter,system-ui,sans-serif}}main{{max-width:1200px;margin:0 auto;padding:30px}}
.card{{background:#fff;border:1px solid #e4e4de;border-radius:12px;padding:16px;margin-bottom:16px}}.grid{{display:grid;grid-template-columns:2fr 1fr 1fr 1fr 1fr;gap:10px}}
label{{display:block;color:#777;font:700 11px ui-monospace,Consolas,monospace;text-transform:uppercase;margin-bottom:6px}}input{{width:100%;box-sizing:border-box;border:1px solid #ddd;border-radius:9px;padding:11px}}
button{{border:0;background:#ff6a1a;color:#fff;border-radius:8px;padding:12px 16px;font-weight:800}}table{{width:100%;border-collapse:collapse;font-size:12.5px}}th,td{{border-bottom:1px solid #e4e4de;padding:10px;text-align:left;vertical-align:top}}th{{font-size:10px;text-transform:uppercase;color:#777}}a{{color:#141412;font-weight:700}}small{{color:#666}}pre{{white-space:pre-wrap;background:#141412;color:#fff;border-radius:10px;padding:12px;max-height:260px;overflow:auto}}
@media(max-width:900px){{.grid{{grid-template-columns:1fr}}}}
</style></head><body><main>
<h1>Name-Only Raw Enrichment</h1>
<p>Discovers direct pages and search candidates, extracts raw documents, harvests identifiers, then re-queries free APIs with richer inputs.</p>
<form class="card" method="get" action="/enrich/name">
  <div class="grid">
    <div><label>Product name</label><input name="query" required value="{escape(query or 'Nvidia GeForce RTX 4080')}"></div>
    <div><label>Brand</label><input name="brand" value="{escape(brand or 'Nvidia')}"></div>
    <div><label>Manufacturer</label><input name="manufacturer" value="{escape(manufacturer or '')}"></div>
    <div><label>Max candidates</label><input type="number" min="1" max="30" name="max_candidates" value="{max_candidates}"></div>
    <div><label>Max extracts</label><input type="number" min="0" max="12" name="max_extracts" value="{max_extracts}"></div>
  </div>
  <p><label><input type="checkbox" name="run_second_pass" value="true" {'checked' if run_second_pass else ''} style="width:auto"> Run second-pass APIs using harvested identifiers</label></p>
  <button type="submit">Run Name Enrichment</button>
</form>
{result_html}
<p><a href="/search">Product search</a> | <a href="/docs">API docs</a></p>
</main></body></html>
"""


@app.get("/documents/extract", response_class=HTMLResponse)
async def extract_document_page(
    url: str | None = None,
    document_type: str = "unknown",
    product_query: str | None = None,
    source_title: str | None = None,
) -> str:
    result = None
    if url:
        result = await extract_document(
            DocumentExtractRequest(
                url=url,
                document_type=document_type,  # type: ignore[arg-type]
                product_query=product_query,
                source_title=source_title,
            ),
            timeout_seconds=get_settings().request_timeout_seconds,
        )
    result_html = ""
    if result:
        links = "".join(f"<li><a href='{escape(link)}'>{escape(link)}</a></li>" for link in result.links)
        images = "".join(f"<li><a href='{escape(image)}'>{escape(image)}</a></li>" for image in result.images)
        assets = "".join(
            f"<div class='kv'><b>{escape(str(asset.get('asset_type','asset')))}</b><span>{escape(str(asset.get('url','')))}<br>{escape(str(asset.get('content_hash','')))}</span></div>"
            for asset in result.downloaded_assets
        )
        fields = "".join(f"<div class='kv'><b>{escape(str(k))}</b><span>{escape(str(v))}</span></div>" for k, v in result.extracted_fields.items())
        result_html = f"""
        <div class="card">
          <h2>Document Result <span class="badge">{escape(result.status)}</span></h2>
          <p><b>Final URL:</b> <a href="{escape(result.final_url or result.url)}">{escape(result.final_url or result.url)}</a></p>
          <p><b>Content type:</b> {escape(result.content_type or '')} | <b>HTTP:</b> {result.http_status or ''}</p>
          <h3>{escape(result.title or 'Untitled document')}</h3>
          <div class="grid">{fields or "<p>No structured fields found yet.</p>"}</div>
          <h3>Text Preview</h3>
          <pre>{escape(result.text_preview or result.error or '')}</pre>
          <h3>Downloaded Assets</h3>
          <div class="grid">{assets or "<p>No assets downloaded.</p>"}</div>
          <h3>Useful Links Found</h3>
          <ul>{links or "<li>No manual/datasheet/support links found on this page.</li>"}</ul>
          <h3>Images Found</h3>
          <ul>{images or "<li>No image URLs found on this page.</li>"}</ul>
        </div>
        """
    return f"""
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>NoetherIP Document Extractor</title>
<style>
body{{margin:0;background:#f7f7f4;color:#141412;font:14px/1.45 Inter,system-ui,sans-serif}}main{{max-width:1100px;margin:0 auto;padding:30px}}
.card{{background:#fff;border:1px solid #e4e4de;border-radius:12px;padding:16px;margin-bottom:16px}}.grid{{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}}
label{{display:block;color:#777;font:700 11px ui-monospace,Consolas,monospace;text-transform:uppercase;margin-bottom:6px}}input,select{{width:100%;box-sizing:border-box;border:1px solid #ddd;border-radius:9px;padding:11px}}
button{{border:0;background:#ff6a1a;color:white;border-radius:8px;padding:12px 16px;font-weight:800}}pre{{white-space:pre-wrap;background:#141412;color:#fff;border-radius:10px;padding:14px;max-height:360px;overflow:auto}}
.kv{{background:#fafaf7;border:1px solid #e4e4de;border-radius:9px;padding:10px}}.kv b{{display:block}}.kv span{{color:#666}}.badge{{display:inline-block;background:#fff1e8;color:#ff6a1a;border-radius:999px;padding:4px 8px}}
@media(max-width:820px){{.grid{{grid-template-columns:1fr}}}}
</style></head><body><main>
<h1>NoetherIP Document Extractor</h1>
<p>Paste a direct official datasheet/manual/support URL. Search result pages should be opened by the user or resolved through Google Programmable Search before extraction.</p>
<form class="card" method="get" action="/documents/extract">
  <div class="grid">
    <div><label>Document type</label><select name="document_type"><option>unknown</option><option>datasheet</option><option>manual</option><option>service_manual</option><option>firmware_release_notes</option><option>support_page</option><option>teardown</option><option>regulatory</option></select></div>
    <div><label>Product query</label><input name="product_query" value="{escape(product_query or '')}" placeholder="Intel NUC8i7BEH"></div>
    <div><label>Source title</label><input name="source_title" value="{escape(source_title or '')}" placeholder="Official support page"></div>
  </div>
  <p><label>URL</label><input name="url" value="{escape(url or '')}" required placeholder="https://manufacturer.com/support/product"></p>
  <button type="submit">Extract Document</button>
</form>
{result_html}
<p><a href="/search">Back to product search</a> | <a href="/docs">API docs</a></p>
</main></body></html>
"""


@app.get("/search", response_class=HTMLResponse)
async def search_page() -> str:
    return """
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>NoetherIP Product Search</title>
  <style>
    body{margin:0;background:#f7f7f4;color:#141412;font:14px/1.45 Inter,system-ui,sans-serif}
    main{max-width:1120px;margin:0 auto;padding:34px}
    h1{font-size:32px;margin:0 0 6px}p{color:#6d6d67;margin:0 0 18px}.card{background:#fff;border:1px solid #e4e4de;border-radius:12px;padding:18px;margin-bottom:16px}
    .grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.wide{grid-column:span 2}
    label{display:block;color:#777770;font:700 11px ui-monospace,Consolas,monospace;text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px}
    input,select{width:100%;box-sizing:border-box;border:1px solid #e4e4de;border-radius:9px;padding:11px;background:#fff}
    button{border:0;background:#ff6a1a;color:#fff;border-radius:8px;padding:12px 16px;font-weight:800;cursor:pointer}
    .hint{font-size:12px;color:#777770}.links a{display:inline-block;margin-right:12px;color:#141412;font-weight:700}
    @media(max-width:820px){.grid{grid-template-columns:1fr}.wide{grid-column:auto}}
  </style>
</head>
<body>
<main>
  <h1>NoetherIP Product Search</h1>
  <p>Search by any product clue. The backend creates a job ID and extracts results from free/no-key sources by default.</p>
  <form class="card" method="get" action="/search/start">
    <div class="grid">
      <div>
        <label>Search type</label>
        <select name="search_type">
          <option value="product_name">Product name / keyword</option>
          <option value="model_number">Model number</option>
          <option value="part_number">Part number</option>
          <option value="product_id">Product ID</option>
          <option value="fcc_id">FCC ID</option>
          <option value="upc_gtin">UPC / GTIN</option>
          <option value="sku_mpn_asin">SKU / MPN / ASIN</option>
          <option value="marking">Board / chip marking</option>
          <option value="product_url">Product URL</option>
          <option value="company">Company / manufacturer</option>
        </select>
      </div>
      <div class="wide">
        <label>Search value</label>
        <input name="value" required minlength="2" value="Intel AX211 Wi-Fi module">
      </div>
      <div><label>Company / brand</label><input name="company_name" placeholder="Intel, Apple, Dell"></div>
      <div><label>Model number</label><input name="model_number" placeholder="AX211NGW"></div>
      <div><label>Part number</label><input name="part_number" placeholder="official part number"></div>
      <div><label>Product ID</label><input name="product_id" placeholder="catalog/internal product ID"></div>
      <div><label>FCC ID</label><input name="fcc_id" placeholder="PD9AX211NG"></div>
      <div><label>UPC / GTIN</label><input name="upc_gtin" placeholder="012345678905"></div>
      <div><label>SKU / MPN / ASIN</label><input name="sku_mpn_asin" placeholder="SKU, MPN, or ASIN"></div>
      <div><label>Board / chip marking</label><input name="marking" placeholder="PCB/chip marking"></div>
      <div class="wide"><label>Product URL</label><input name="product_url" placeholder="https://manufacturer.com/product"></div>
      <div><label>Category handling</label><select name="vertical"><option value="auto">Auto / infer from product</option><option value="electronics">Electronics / hardware</option><option value="router networking">Router / networking</option><option value="medical device">Medical device</option><option value="automotive">Automotive</option><option value="software">Software</option></select></div>
      <div><label>Max per source</label><input type="number" name="max_results_per_source" min="1" max="25" value="5"></div>
      <div><label>Source mode</label><select name="free_only"><option value="true">Free/no-key only</option><option value="false">Include configured key sources</option></select></div>
    </div>
    <p class="hint" style="margin-top:12px">For exact searches, put the main value in Search value and optionally add other known identifiers.</p>
    <button type="submit">Create Extraction Job</button>
  </form>
  <div class="card links">
    <a href="/docs">Swagger API docs</a>
    <a href="/connectors">Connector catalog JSON</a>
    <a href="/connectors/check">Connector health</a>
    <a href="/jobs">Recent jobs JSON</a>
  </div>
</main>
</body>
</html>
"""


@app.get("/search/start")
async def start_search_job(
    background_tasks: BackgroundTasks,
    search_type: str = Query("product_name"),
    value: str = Query(..., min_length=2),
    company_name: str | None = None,
    model_number: str | None = None,
    part_number: str | None = None,
    product_id: str | None = None,
    fcc_id: str | None = None,
    upc_gtin: str | None = None,
    sku_mpn_asin: str | None = None,
    marking: str | None = None,
    product_url: str | None = None,
    vertical: str = "auto",
    free_only: bool = True,
    max_results_per_source: int = Query(5, ge=1, le=25),
) -> RedirectResponse:
    query = _query_from_search(
        search_type=search_type,
        value=value,
        company_name=company_name,
        model_number=model_number,
        part_number=part_number,
        product_id=product_id,
        fcc_id=fcc_id,
        upc_gtin=upc_gtin,
        sku_mpn_asin=sku_mpn_asin,
        marking=marking,
        product_url=product_url,
        vertical=vertical,
        free_only=free_only,
        max_results_per_source=max_results_per_source,
    )
    job_id = uuid4().hex
    JOBS[job_id] = {
        "job_id": job_id,
        "status": "queued",
        "created_at": datetime.utcnow().isoformat(),
        "query": query.model_dump(mode="json"),
    }
    background_tasks.add_task(_run_job, job_id)
    return RedirectResponse(f"/jobs/{job_id}/view", status_code=303)


@app.get("/jobs")
async def list_jobs() -> list[dict[str, Any]]:
    return [
        {
            "job_id": job_id,
            "status": job["status"],
            "created_at": job.get("created_at"),
            "query": job.get("query", {}),
            "view": f"/jobs/{job_id}/view",
            "json": f"/jobs/{job_id}",
        }
        for job_id, job in reversed(list(JOBS.items()))
    ]


@app.get("/jobs/{job_id}")
async def get_job(job_id: str) -> dict[str, Any]:
    return JOBS.get(job_id) or {"job_id": job_id, "status": "not_found"}


@app.get("/jobs/{job_id}/view", response_class=HTMLResponse)
async def view_job(job_id: str) -> str:
    job = JOBS.get(job_id)
    if not job:
        return f"<h1>Job not found</h1><p>No job exists for <code>{escape(job_id)}</code>.</p><p><a href='/search'>Back to search</a></p>"
    query = job.get("query", {})
    result = job.get("result")
    product = (result or {}).get("product", {})
    coverage = (result or {}).get("coverage", {})
    data_profile = (result or {}).get("data_profile", {})
    evidence = (result or {}).get("evidence", [])
    runs = (result or {}).get("source_runs", [])
    ok_runs = [run for run in runs if run.get("status") == "ok"]
    confidence = product.get("confidence", 0) if product else 0
    coverage_rows = "".join(
        f"<tr><td><b>{escape(str(group.get('group','')).replace('_',' ').title())}</b></td>"
        f"<td><div class='meter'><span style='width:{int(group.get('coverage_percent', 0))}%'></span></div><b>{group.get('coverage_percent',0)}%</b></td>"
        f"<td>{_display_value(group.get('found_fields', []))}</td><td>{_display_value(group.get('missing_fields', []))}</td></tr>"
        for group in coverage.get("groups", [])
    ) or "<tr><td colspan='4'>Waiting for coverage result...</td></tr>"
    free_actions = "".join(f"<li>{escape(action)}</li>" for action in coverage.get("free_next_actions", []))
    paid_actions = "".join(f"<li>{escape(action)}</li>" for action in coverage.get("optional_paid_recommendations", []))
    profile_cards = ""
    for group, values in data_profile.items():
        if group == "evidence_provenance":
            continue
        if isinstance(values, dict) and any(_truthy_html(v) for v in values.values()):
            profile_cards += (
                f"<section class='panel'><div class='section-head'><h2>{escape(str(group).replace('_',' ').title())}</h2>"
                f"<span class='count'>{sum(1 for v in values.values() if _truthy_html(v))} fields</span></div>"
                f"{_kv_grid(values)}</section>"
            )
    if not profile_cards:
        profile_cards = "<section class='panel'><p class='empty'>Waiting for normalized profile fields...</p></section>"
    provenance = data_profile.get("evidence_provenance", []) if isinstance(data_profile, dict) else []
    provenance_rows = "".join(
        f"<tr><td>{escape(str(item.get('source','')))}</td><td>{escape(str(item.get('source_type','')))}</td>"
        f"<td>{_display_value(item.get('source_url'))}</td><td>{escape(str(item.get('reliability','')))}</td><td>{escape(str(item.get('retrieved_at','')))}</td></tr>"
        for item in provenance
        if isinstance(item, dict) and item.get("source") != "source_runs"
    ) or "<tr><td colspan='5'>No provenance records yet.</td></tr>"
    evidence_rows = ""
    for item in evidence:
        url = item.get("url") or "#"
        category = item.get("category")
        document_type = {
            "datasheet": "datasheet",
            "manuals": "manual",
            "teardown": "teardown",
            "regulatory": "regulatory",
        }.get(category, "unknown")
        doc_params = urlencode(
            {
                "url": url,
                "document_type": document_type,
                "product_query": product.get("product_name") or query.get("query") or "",
                "source_title": item.get("title") or "",
            }
        )
        metadata = item.get("metadata") or {}
        identifiers = item.get("identifiers") or {}
        raw_json = escape(json.dumps(item, indent=2, ensure_ascii=False, default=str))
        evidence_rows += f"""
        <article class="evidence-card">
          <div class="evidence-top">
            <div>
              <div class="chips"><span class="chip">{escape(item.get('category','unknown'))}</span><span class="chip source">{escape(item.get('source','unknown'))}</span></div>
              <h3><a href="{escape(url)}">{escape(item.get('title','Untitled evidence'))}</a></h3>
            </div>
            <div class="score">{escape(str(item.get('reliability','')))}<span>reliability</span></div>
          </div>
          <p>{escape(item.get('snippet') or '')}</p>
          <div class="evidence-grid">
            <div><h4>Identifiers</h4>{_kv_grid(identifiers, "No identifiers on this record.")}</div>
            <div><h4>Structured Metadata</h4>{_kv_grid(metadata, "No structured metadata on this record.")}</div>
          </div>
          <div class="evidence-actions">
            <a href="/documents/extract?{escape(doc_params)}">Extract this document/page</a>
            <details><summary>Raw evidence JSON</summary><pre>{raw_json}</pre></details>
          </div>
        </article>
        """
    evidence_rows = evidence_rows or "<p class='empty'>No evidence yet. Refresh if the job is still running.</p>"
    run_rows = "".join(
        f"<tr><td>{escape(run.get('source',''))}</td><td><span class='badge {_status_class(run.get('status',''))}'>{escape(run.get('status',''))}</span></td><td>{escape(run.get('message',''))}</td><td>{run.get('count',0)}</td></tr>"
        for run in runs
    ) or "<tr><td colspan='4'>No connector runs yet.</td></tr>"
    raw_result = escape(json.dumps(result or job, indent=2, ensure_ascii=False, default=str))
    refresh = "<meta http-equiv='refresh' content='3'>" if job.get("status") in {"queued", "running"} else ""
    return f"""
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">{refresh}
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>NoetherIP Job {escape(job_id)}</title>
  <style>
    :root{{--ink:#141412;--muted:#696963;--bg:#f6f6f1;--panel:#fff;--line:#deded5;--soft:#fafaf7;--accent:#ff6a1a;--ok:#1f8449;--warn:#a86712;--bad:#b73333;--mono:ui-monospace,Consolas,monospace}}
    *{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--ink);font:14px/1.45 Inter,system-ui,sans-serif}}main{{max-width:1280px;margin:0 auto;padding:28px 34px 54px}}
    header{{display:flex;justify-content:space-between;gap:18px;align-items:flex-start;margin-bottom:16px}}h1{{font-size:34px;line-height:1.08;margin:0 0 8px}}h2{{margin:0;font-size:18px}}h3{{margin:8px 0 6px;font-size:15px}}h4{{margin:0 0 8px;font-size:12px;color:var(--muted);text-transform:uppercase;font-family:var(--mono)}}p{{color:var(--muted)}}a{{color:var(--ink);font-weight:800;word-break:break-word}}
    .nav a{{display:inline-block;margin-right:10px}}.badge,.chip{{display:inline-flex;border-radius:999px;padding:5px 9px;font:800 10px var(--mono);text-transform:uppercase;letter-spacing:.04em}}.badge.info,.chip{{background:#fff1e8;color:var(--accent)}}.badge.ok{{background:#e8f6ed;color:var(--ok)}}.badge.warn{{background:#fff4df;color:var(--warn)}}.badge.bad{{background:#fdeaea;color:var(--bad)}}.chip.source{{background:#eeeeea;color:#555}}
    .metrics{{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:18px 0}}.metric{{background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:14px}}.metric b{{display:block;font-size:26px;line-height:1.05}}.metric span{{color:var(--muted);font-size:12px}}
    .panel{{background:var(--panel);border:1px solid var(--line);border-radius:8px;padding:16px;margin-bottom:14px}}.section-head{{display:flex;justify-content:space-between;gap:12px;align-items:center;margin-bottom:12px}}.count{{font:800 11px var(--mono);color:var(--muted);text-transform:uppercase}}
    .field-grid{{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}}.field{{background:var(--soft);border:1px solid var(--line);border-radius:8px;padding:10px;min-width:0}}.field b{{display:block;font-size:11px;color:#555;margin-bottom:5px}}.field span{{display:block;color:#292925;word-break:break-word}}.empty{{color:var(--muted);margin:0}}
    .value-list{{margin:0;padding-left:18px}}.mini-dl{{margin:0}}.mini-dl dt{{font:800 11px var(--mono);color:#666;margin-top:8px}}.mini-dl dd{{margin:2px 0 0;word-break:break-word}}
    table{{width:100%;border-collapse:collapse;font-size:12.5px}}th,td{{border-bottom:1px solid var(--line);padding:10px;text-align:left;vertical-align:top}}th{{font:800 10px var(--mono);text-transform:uppercase;color:var(--muted);background:var(--soft)}}.meter{{width:120px;height:8px;background:#ecece6;border-radius:999px;overflow:hidden;display:inline-block;margin-right:8px}}.meter span{{display:block;height:100%;background:var(--accent)}}
    .actions-grid{{display:grid;grid-template-columns:1fr 1fr;gap:12px}}.evidence-card{{border:1px solid var(--line);background:var(--panel);border-radius:8px;padding:14px;margin-bottom:12px}}.evidence-top{{display:flex;justify-content:space-between;gap:16px}}.chips{{display:flex;gap:6px;flex-wrap:wrap}}.score{{min-width:72px;text-align:center;border:1px solid var(--line);border-radius:8px;padding:8px;font-size:22px;font-weight:900}}.score span{{display:block;font:800 10px var(--mono);color:var(--muted);text-transform:uppercase}}.evidence-grid{{display:grid;grid-template-columns:1fr 2fr;gap:12px;margin-top:10px}}.evidence-actions{{display:flex;gap:14px;flex-wrap:wrap;align-items:flex-start;margin-top:10px}}details{{width:100%}}summary{{cursor:pointer;font-weight:800}}pre{{white-space:pre-wrap;background:#151512;color:#eee;border-radius:8px;padding:12px;max-height:340px;overflow:auto;font:12px var(--mono)}}
    @media(max-width:980px){{header,.evidence-top{{display:block}}.metrics,.field-grid,.actions-grid,.evidence-grid{{grid-template-columns:1fr 1fr}}}}@media(max-width:680px){{main{{padding:18px}}.metrics,.field-grid,.actions-grid,.evidence-grid{{grid-template-columns:1fr}}}}
  </style>
</head>
<body><main>
  <header>
    <div>
      <h1>Extraction Job <span class="badge {_status_class(job.get("status",""))}">{escape(job.get("status",""))}</span></h1>
      <p>Structured product record with confirmed fields, candidate evidence, connector runs, provenance, and raw JSON retained for audit.</p>
    </div>
    <div class="nav"><a href="/search">New search</a><a href="/documents/extract">Document extractor</a><a href="/jobs/{escape(job_id)}">JSON result</a><a href="/docs">API docs</a></div>
  </header>
  <div class="metrics">
    <div class="metric"><b>{coverage.get("overall_percent", 0)}%</b><span>Overall coverage</span></div>
    <div class="metric"><b>{len(evidence)}</b><span>Evidence records</span></div>
    <div class="metric"><b>{len(ok_runs)}</b><span>Successful sources</span></div>
    <div class="metric"><b>{confidence}</b><span>Product confidence</span></div>
  </div>
  <section class="panel"><div class="section-head"><h2>Submitted Query</h2><span class="count">Input</span></div>{_kv_grid(query, "Waiting for submitted query...")}</section>
  <section class="panel"><div class="section-head"><h2>Normalized Product</h2><span class="count">Best current record</span></div>{_kv_grid(product, "Waiting for extraction result...")}</section>
  <section class="panel"><div class="section-head"><h2>Target Data Profile</h2><span class="count">Grouped fields</span></div></section>
  {profile_cards}
  <section class="panel"><div class="section-head"><h2>Data Coverage</h2><span class="count">{coverage.get("overall_percent", 0)}% complete</span></div><table><thead><tr><th>Group</th><th>Coverage</th><th>Found</th><th>Missing</th></tr></thead><tbody>{coverage_rows}</tbody></table></section>
  <section class="panel"><div class="section-head"><h2>Next Actions</h2><span class="count">Free first</span></div><div class="actions-grid"><div><h4>Free next actions</h4><ul>{free_actions or "<li>No free next actions yet.</li>"}</ul></div><div><h4>Optional paid/key recommendations</h4><ul>{paid_actions or "<li>No paid/key recommendation needed yet.</li>"}</ul></div></div></section>
  <section class="panel"><div class="section-head"><h2>Evidence Records</h2><span class="count">{len(evidence)} items</span></div>{evidence_rows}</section>
  <section class="panel"><div class="section-head"><h2>Connector Runs</h2><span class="count">{len(runs)} sources</span></div><table><thead><tr><th>Source</th><th>Status</th><th>Message</th><th>Count</th></tr></thead><tbody>{run_rows}</tbody></table></section>
  <section class="panel"><div class="section-head"><h2>Evidence Provenance</h2><span class="count">Audit trail</span></div><table><thead><tr><th>Source</th><th>Type</th><th>URL</th><th>Reliability</th><th>Retrieved</th></tr></thead><tbody>{provenance_rows}</tbody></table></section>
  <section class="panel"><details><summary>Full raw result JSON</summary><pre>{raw_result}</pre></details></section>
</main></body></html>
"""


@app.get("/")
async def root() -> dict[str, str]:
    return {
        "name": "NoetherIP Product Data Extractor API",
        "search": "/search",
        "docs": "/docs",
        "connectors": "/connectors",
        "connector_checks": "/connectors/check",
        "company_products": "/companies/products",
        "name_enrichment": "/enrich/name",
        "extract": "POST /extract",
        "jobs": "/jobs",
    }
