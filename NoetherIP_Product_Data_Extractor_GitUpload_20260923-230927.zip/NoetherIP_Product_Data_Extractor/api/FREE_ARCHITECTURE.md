# NoetherIP Product Data Extraction Architecture

## Scope

This module only extracts product data. It does not perform patent claim matching yet.

The architecture is free-first and accepts broad search inputs:

- product name
- product ID
- model number
- part number
- serial number
- SKU
- ASIN
- MPN
- FCC ID
- UPC / GTIN
- board marking
- chip marking
- device ID
- company / brand / manufacturer
- product URL
- free-text description

## Data Pipeline

```mermaid
flowchart TD
  A[Product search input] --> B[Input classifier and query normalizer]
  B --> C[Identifier resolver]
  B --> D[Free source orchestrator]
  D --> E[FCC / regulatory]
  D --> F[Manual and datasheet discovery]
  D --> G[Teardown and RE evidence]
  D --> H[Code and firmware references]
  D --> I[Product metadata APIs]
  D --> J[Historical web captures]
  E --> K[Evidence normalizer]
  F --> K
  G --> K
  H --> K
  I --> K
  J --> K
  K --> L[Normalized product record]
  K --> M[Evidence table]
  K --> N[Raw document download queue]
  N --> O[PDF / HTML / image parser]
  O --> P[Metadata extraction]
  O --> Q[Embedding chunks]
  L --> R[Future product graph]
  M --> R
  P --> R
  Q --> R
```

## Free Source Plan

| Source | Free status | Search method | Product details available |
| --- | --- | --- | --- |
| FCC Equipment Authorization | Free | FCC ID lookup and FCC exhibit discovery | FCC ID, grantee, product code, grant dates, manuals, labels, internal/external photos, RF test reports |
| iFixit API | Mostly free GET | Guide/category lookup | Teardowns, repair steps, images, tools, parts, device categories |
| OpenWrt Table of Hardware | Free | Hardware table/search dump | Brand, model, SoC, CPU, flash, RAM, Wi-Fi chipset, FCC ID, device pages |
| GitHub public APIs | Free tier | Repository/code search | Firmware references, drivers, SDKs, board files, device trees, PCI/USB IDs |
| Wayback CDX | Free | Historical URL capture lookup | Old manuals, support pages, launch/discontinuation evidence, previous specs |
| UPCitemdb trial | Free limited | UPC lookup or title search | UPC/EAN, title, brand, category, images, offers |
| NHTSA vPIC | Free | Make/model/VIN APIs | Vehicle manufacturer, model, parts/equipment identity |
| openFDA Device APIs | Free | Device-name/product-code search | Medical device name, applicant, product code, classification, recalls, registration |
| Wikidata SPARQL | Free | Entity search | Manufacturer, release date if available, official website, product categories |
| Manufacturer discovery | Free web | Search URL generation and compliant crawler later | Manuals, datasheets, service manuals, firmware notes, support pages |

## Storage Architecture For Next Build

| Layer | Recommended database/storage | Purpose |
| --- | --- | --- |
| Product metadata | PostgreSQL | Product, manufacturer, identifiers, aliases, categories, confidence |
| Evidence records | PostgreSQL | Source URLs, reliability, snippets, timestamps, provenance |
| Product/component graph | Neo4j or PostgreSQL with edge tables | Product-to-component, product-to-manual, product-to-FCC, product-to-firmware relationships |
| Raw files | S3-compatible object storage or local MinIO | PDFs, manuals, images, FCC exhibits, HTML captures |
| Search index | OpenSearch or Meilisearch | Fast text/filter search over product metadata and document titles |
| Embeddings | pgvector first, Pinecone/Weaviate later if scale needs it | Semantic search over manuals, datasheets, teardowns, firmware notes |
| Job queue | Redis Queue, Celery, or Dramatiq | Crawling, downloads, parsing, OCR, embedding generation |

## API Shape

Primary endpoint:

```http
POST /extract
```

Example request:

```json
{
  "query": "Intel AX211 Wi-Fi module",
  "product_name": "Intel Wi-Fi 6E AX211",
  "company_name": "Intel",
  "manufacturer": "Intel Corporation",
  "model_number": "AX211NGW",
  "part_number": "AX211NGW",
  "fcc_id": "PD9AX211NG",
  "product_url": "https://www.intel.com/content/www/us/en/products/sku/204836/intel-wifi-6e-ax211-gig/specifications.html",
  "vertical": "electronics",
  "free_only": true,
  "max_results_per_source": 5
}
```

Expected response:

- normalized product record
- input identifiers preserved
- evidence list with URLs, snippets, reliability, identifiers, metadata
- connector run status
- next recommended ingestion steps

## Manager Pitch

Current product-data research is fragmented. Analysts search manuals, FCC filings, teardown sites, GitHub, archived support pages, and barcode/product APIs manually. This architecture turns those scattered public sources into one evidence-backed product intelligence layer.

The differentiation is not just search. NoetherIP stores product identifiers, evidence URLs, source reliability, raw documents, parsed metadata, and embedding-ready chunks. That creates the foundation for later patent-to-product mapping and component cross-linking without rebuilding the ingestion layer.

Easy revenue path:

- sell as product intelligence add-on before full patent matching is ready
- reduce analyst research time for product evidence collection
- generate reusable evidence packs for licensing, litigation prep, portfolio mining, and reverse-engineering teams
- use free sources first to keep MVP cost low
- add enterprise value later with ktMINE, paid product catalogs, internal teardown data, and claim charts
