$ErrorActionPreference = "Stop"
Set-Location -LiteralPath $PSScriptRoot
$python = (Get-Command python -ErrorAction SilentlyContinue)
if (-not $python) { $python = (Get-Command py -ErrorAction SilentlyContinue) }
if (-not $python) {
  throw "Python was not found on PATH. Install Python 3.11+ or run this with your Python executable."
}
if (!(Test-Path ".venv")) {
  & $python.Source -m venv .venv
}
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
