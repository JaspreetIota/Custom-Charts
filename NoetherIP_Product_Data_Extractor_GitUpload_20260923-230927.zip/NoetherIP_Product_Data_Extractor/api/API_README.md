# NoetherIP Product Data Extractor API

FastAPI backend architecture for extracting product details from free/free-tier sources before patent matching.

It focuses on:

- product identity and metadata
- manuals and datasheet discovery
- regulatory evidence such as FCC/openFDA/NHTSA
- teardown and reverse-engineering evidence
- code/firmware references
- historical product/support pages
- normalized evidence chunks ready for embeddings later
- free-first field coverage and missing-data reporting

The current architecture is intentionally free-first. By default, `/extract` only runs no-key public sources. Free-key sources such as Google Programmable Search, Best Buy, and Barcode Lookup stay available as optional extensions when keys are configured and `free_only` is set to `false` or a specific source is selected.

## Target Data Contract

Every extraction attempts to fill the same target schema:

| Group | Data points |
| --- | --- |
| Product identity | `product_name`, `brand`, `manufacturer`, `model_number`, `part_number`, `sku`, `mpn`, `asin`, `upc_gtin`, `fcc_id` |
| Official docs | `datasheet_url`, `manual_url`, `service_manual_url`, `support_url`, `firmware_url`, `driver_url`, `bios_url` |
| Technical specs | `processor`, `soc`, `chipset`, `memory`, `storage`, `wireless_chip`, `ports`, `power`, `dimensions`, `os_support` |
| RE/teardown | `teardown_url`, `guide_steps`, `images`, `tools`, `components_seen`, `board_markings`, `chip_markings` |
| Regulatory | `fcc_grant`, `internal_photos`, `external_photos`, `test_report`, `label`, `grant_date` |
| Evidence/provenance | `source`, `source_url`, `source_type`, `reliability`, `retrieved_at`, `content_hash`, `raw_file_path` |
| History | `first_seen`, `last_seen`, `launch_inference`, `discontinued_inference`, `archived_urls` |

The API response includes:

- `data_profile`: normalized target data grouped by the table above
- `coverage`: found fields, missing fields, overall coverage, free next actions and optional paid/key recommendations
- `evidence`: raw source-backed evidence
- `source_runs`: connector status

## Search Inputs Supported

The extractor can start from incomplete product clues, including:

- product name, generic query, company name, brand, manufacturer
- model number, product ID, part number, serial number, SKU, ASIN, MPN
- board marking, chip marking, device ID
- FCC ID, UPC, GTIN
- product/support/manual URL

These fields are combined into a normalized search string for APIs and discovery connectors, while exact identifiers are preserved separately for evidence scoring and future graph links.

Category/vertical is optional. Use `vertical: "auto"` to let the backend infer whether the product looks automotive, medical, networking, electronics, or general. Vertical-specific sources such as NHTSA and openFDA only run when the query appears relevant, or when the user explicitly chooses that vertical.

For product-name-only searches, use `/enrich/name` before relying on normalized coverage. It keeps candidate URLs, extracted raw documents, harvested identifiers and second-pass API results separate, so ambiguous family pages and third-party teardown values can be reviewed before promotion into a clean product record.

## Quick Start

```powershell
cd "C:\Users\jaspr\Documents\Codex\2026-07-10\give-me-realistic-ideas-related-to\outputs\product-data-extractor-api"
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env
uvicorn app.main:app --reload --port 8000
```

Open:

- Search UI: `http://127.0.0.1:8000/search`
- API docs: `http://127.0.0.1:8000/docs`
- Connector catalog: `http://127.0.0.1:8000/connectors`
- Connector health: `http://127.0.0.1:8000/connectors/check`
- Company/manufacturer product list: `http://127.0.0.1:8000/companies/products`
- Name-only raw enrichment: `http://127.0.0.1:8000/enrich/name`
- Document extractor: `http://127.0.0.1:8000/documents/extract`
- Recent jobs: `http://127.0.0.1:8000/jobs`

## Browser Search Flow

For non-JSON use, open:

```text
http://127.0.0.1:8000/search
```

The search page supports:

- product name / keyword
- model number
- part number
- product ID
- FCC ID
- UPC / GTIN
- SKU / MPN / ASIN
- board / chip marking
- product URL
- company / manufacturer

Submitting the form creates a job and redirects to:

```text
/jobs/{job_id}/view
```

Machine-readable job status/result is available at:

```text
/jobs/{job_id}
```

For the MVP, jobs are stored in memory. Restarting the API clears them. Production should move jobs to PostgreSQL/Redis and run extraction workers through a queue.

## Connector Health

Use this endpoint before demos or batch runs:

```text
http://127.0.0.1:8000/connectors/check
```

It reports:

- reachable free/no-key APIs such as FCC, iFixit, OpenWrt, GitHub, Wayback, UPCitemdb, NHTSA, openFDA and Wikidata
- optional key source configuration status for Best Buy, Google Programmable Search and Barcode Lookup
- response status and latency for each checked connector

The manufacturer discovery connector is local/deterministic, so it is reported as available without an external health call.

## Company / Manufacturer Product Search

For company-first searches, call:

```http
POST /companies/products
```

```json
{
  "company_name": "Nvidia",
  "vertical": "auto",
  "max_results_per_source": 10,
  "free_only": true
}
```

This returns a product candidate list from free sources such as UPCitemdb, NHTSA, openFDA, Wikidata, optional Google Programmable Search, and official catalog seed URLs where available. The user should select one product from that list, then run `/enrich/name` or `/extract` for the specific product.

## Name-Only Raw Enrichment

For products where only a name is known, call:

```http
POST /enrich/name
```

```json
{
  "query": "Nvidia GeForce RTX 4080",
  "brand": "Nvidia",
  "manufacturer": "Nvidia",
  "max_candidates": 10,
  "max_extracts": 5,
  "free_only": true,
  "run_second_pass": true
}
```

The pipeline runs:

1. Candidate discovery from known official/source templates and search-discovery URLs.
2. Direct extraction for extractable official/support/teardown pages.
3. Identifier/spec harvesting from extracted raw text and structured fields.
4. Second-pass free API calls using harvested `product_url`, `fcc_id`, `upc_gtin`, model/part numbers and other clues.

Search-result URLs remain candidates unless a search API such as Google Programmable Search resolves them to direct pages. This prevents the system from treating a Google result page as a confirmed datasheet or manual.

## Discovery To Document Extraction

The product search returns evidence and discovery links first. When a strong result points to an official datasheet, manual, service manual, firmware page, support page or teardown page, use:

```text
http://127.0.0.1:8000/documents/extract
```

or JSON:

```http
POST /documents/extract
```

```json
{
  "url": "https://manufacturer.com/support/product-page",
  "document_type": "manual",
  "product_query": "Intel NUC8i7BEH",
  "source_title": "Official support page"
}
```

The document extractor currently fetches direct URLs and extracts:

- final URL after redirects
- content type and status
- HTML title/meta description
- text preview
- likely model, part number, FCC ID, BIOS/manual/datasheet mentions
- useful links to PDFs, manuals, datasheets, specs, drivers, firmware and support pages
- image URLs from HTML pages
- downloaded asset records for HTML/PDF with size and content hash
- PDF metadata such as filename, size and content hash
- PDF text preview when `pypdf` is installed

Install/refresh dependencies after this update:

```powershell
pip install -r requirements.txt
```

Google search result URLs are treated as discovery pages. For production, direct result extraction should come from Google Programmable Search API or user-selected official links, not scraping the Google results page directly.

## Example Request

```powershell
Invoke-RestMethod -Method Post `
  -Uri "http://127.0.0.1:8000/extract" `
  -ContentType "application/json" `
  -Body '{
    "query": "Intel AX211 Wi-Fi module",
    "product_name": "Intel Wi-Fi 6E AX211",
    "brand": "Intel",
    "manufacturer": "Intel Corporation",
    "model_number": "AX211NGW",
    "part_number": "AX211NGW",
    "fcc_id": "PD9AX211NG",
    "product_url": "https://www.intel.com/content/www/us/en/products/sku/204836/intel-wifi-6e-ax211-gig/specifications.html",
    "vertical": "electronics",
    "free_only": true,
    "max_results_per_source": 5
  }'
```

## Free Architecture

```mermaid
flowchart LR
  A[User search: product name, ID, model, company, FCC, UPC, URL, markings] --> B[Query normalizer]
  B --> C[Free evidence collectors]
  C --> D[Metadata normalizer]
  D --> E[Evidence records with source reliability]
  E --> F[Object store for PDFs, manuals, photos, pages]
  E --> G[Relational product metadata]
  E --> H[Vector chunks for manuals, datasheets, teardowns]
  G --> I[Future patent-to-product mapping]
  H --> I
```

Core free/no-key collectors:

- FCC Equipment Authorization for FCC IDs, grants, manuals, photos, labels, and test-report discovery.
- iFixit for teardown/repair guide evidence.
- OpenWrt Table of Hardware discovery for routers, SoCs, RAM, flash, Wi-Fi chipsets, and FCC IDs.
- GitHub public search for repositories, drivers, firmware references, SDKs, board files, device trees, PCI/USB IDs.
- Wayback CDX for historical product/support/manual pages.
- UPCitemdb trial endpoints for low-volume UPC/EAN/product metadata.
- NHTSA vPIC for automotive product identity.
- openFDA device APIs for medical-device records.
- Wikidata SPARQL for entity/manufacturer/release/website enrichment.
- Manufacturer document discovery URLs for official manuals, datasheets, service manuals, firmware notes, and support pages.

## Connectors Included

No key required:

- FCC Equipment Authorization lookup
- iFixit guide/teardown lookup
- OpenWrt Table of Hardware discovery
- GitHub repository search, with optional token
- Wayback Machine CDX
- UPCitemdb trial API
- NHTSA vPIC
- openFDA device APIs
- Wikidata SPARQL
- manufacturer document discovery URLs

Optional key-based:

- Best Buy Products API via `BESTBUY_API_KEY`
- Google Programmable Search via `GOOGLE_API_KEY` and `GOOGLE_CX`
- Barcode Lookup via `BARCODE_LOOKUP_KEY`
- GitHub token via `GITHUB_TOKEN` for better rate limits

## Important Notes

Some free/public sources limit rate, block heavy scraping, require attribution, or require a server-side proxy for production. This backend is designed to call APIs server-side and normalize evidence, but production use should add:

- persistent storage
- PDF/image downloader
- document hashing
- OCR/parser workers
- robots.txt / ToS checks
- queueing and retries
- API key vault
- embeddings and vector index
